-- --------------------------------------------------------
-- Host:                         103.187.146.194
-- Server version:               10.5.12-MariaDB - Source distribution
-- Server OS:                    Linux
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for moslemdb
CREATE DATABASE IF NOT EXISTS `moslemdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `moslemdb`;

-- Dumping structure for table moslemdb.Absensis
CREATE TABLE IF NOT EXISTS `Absensis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  `RefId` bigint(20) NOT NULL,
  `PhotoUrl` varchar(300) DEFAULT NULL,
  `JumlahOrang` int(11) DEFAULT 1,
  `Tipe` int(11) DEFAULT 0,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Absensis: ~1 rows (approximately)
DELETE FROM `Absensis`;
/*!40000 ALTER TABLE `Absensis` DISABLE KEYS */;
INSERT INTO `Absensis` (`Id`, `Tanggal`, `Nama`, `RefId`, `PhotoUrl`, `JumlahOrang`, `Tipe`) VALUES
	(1, '2023-05-24 10:32:26.602810', 'admin', 2, NULL, 1, 0);
/*!40000 ALTER TABLE `Absensis` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Acaras
CREATE TABLE IF NOT EXISTS `Acaras` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TanggalMulai` datetime(6) NOT NULL,
  `TanggalSelesai` datetime(6) NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Acaras: ~0 rows (approximately)
DELETE FROM `Acaras`;
/*!40000 ALTER TABLE `Acaras` DISABLE KEYS */;
/*!40000 ALTER TABLE `Acaras` ENABLE KEYS */;

-- Dumping structure for table moslemdb.AkunInfaqSodakohs
CREATE TABLE IF NOT EXISTS `AkunInfaqSodakohs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `Uraian` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `PersenDariSetoran` double NOT NULL,
  `TargetJatahan` double NOT NULL,
  `Tipe` int(11) NOT NULL,
  `Grup` int(11) NOT NULL,
  `Rutin` tinyint(1) NOT NULL,
  `Level` int(11) NOT NULL,
  `MasukKeIsrun` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.AkunInfaqSodakohs: ~0 rows (approximately)
DELETE FROM `AkunInfaqSodakohs`;
/*!40000 ALTER TABLE `AkunInfaqSodakohs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AkunInfaqSodakohs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.AkunSodakohKhususs
CREATE TABLE IF NOT EXISTS `AkunSodakohKhususs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `TargetNilai` double NOT NULL,
  `DariTanggal` datetime(6) NOT NULL,
  `SampaiTanggal` datetime(6) NOT NULL,
  `PenanggungJawab` longtext DEFAULT NULL,
  `Target` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.AkunSodakohKhususs: ~0 rows (approximately)
DELETE FROM `AkunSodakohKhususs`;
/*!40000 ALTER TABLE `AkunSodakohKhususs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AkunSodakohKhususs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.AkunTabunganJamaahs
CREATE TABLE IF NOT EXISTS `AkunTabunganJamaahs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `DariTanggal` datetime(6) NOT NULL,
  `SampaiTanggal` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.AkunTabunganJamaahs: ~2 rows (approximately)
DELETE FROM `AkunTabunganJamaahs`;
/*!40000 ALTER TABLE `AkunTabunganJamaahs` DISABLE KEYS */;
INSERT INTO `AkunTabunganJamaahs` (`Id`, `Nama`, `Keterangan`, `DariTanggal`, `SampaiTanggal`) VALUES
	(1, 'Qurban 2020', 'test', '0001-01-01 00:00:00.000000', '0001-01-31 00:00:00.000000'),
	(2, 'Qurban 2021', 'Testing', '2021-01-01 00:00:00.000000', '2022-01-01 00:00:00.000000'),
	(3, 'Tabungan Haji', NULL, '2022-06-01 17:30:17.773947', '2023-06-01 17:30:17.774004');
/*!40000 ALTER TABLE `AkunTabunganJamaahs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Anekdots
CREATE TABLE IF NOT EXISTS `Anekdots` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Permasalahan` longtext DEFAULT NULL,
  `Solusi` longtext DEFAULT NULL,
  `Pendidik` longtext DEFAULT NULL,
  `KelasId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Anekdots_KelasId` (`KelasId`),
  CONSTRAINT `FK_Anekdots_Kelass_KelasId` FOREIGN KEY (`KelasId`) REFERENCES `Kelass` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Anekdots: ~0 rows (approximately)
DELETE FROM `Anekdots`;
/*!40000 ALTER TABLE `Anekdots` DISABLE KEYS */;
/*!40000 ALTER TABLE `Anekdots` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Asets
CREATE TABLE IF NOT EXISTS `Asets` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `KodeBarang` varchar(50) NOT NULL,
  `NamaBarang` varchar(500) NOT NULL,
  `Jumlah` int(11) NOT NULL,
  `Keterangan` varchar(500) DEFAULT NULL,
  `Lokasi` varchar(500) DEFAULT NULL,
  `CaraPerolehan` varchar(200) DEFAULT NULL,
  `TanggalPerolehan` datetime DEFAULT NULL,
  `Kondisi` varchar(50) NOT NULL,
  `NoSertifikat` varchar(150) DEFAULT NULL,
  `Merek` varchar(100) DEFAULT NULL,
  `Ukuran` varchar(150) DEFAULT NULL,
  `CreatedBy` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Asets: ~0 rows (approximately)
DELETE FROM `Asets`;
/*!40000 ALTER TABLE `Asets` DISABLE KEYS */;
/*!40000 ALTER TABLE `Asets` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Asnabs
CREATE TABLE IF NOT EXISTS `Asnabs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `FaktorPengali` double NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Asnabs: ~4 rows (approximately)
DELETE FROM `Asnabs`;
/*!40000 ALTER TABLE `Asnabs` DISABLE KEYS */;
INSERT INTO `Asnabs` (`Id`, `Nama`, `FaktorPengali`) VALUES
	(1, 'Fakir', 1),
	(2, 'Miskin', 2),
	(3, 'Ghorim', 3),
	(4, 'Ibnu Sabil', 1);
/*!40000 ALTER TABLE `Asnabs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Babs
CREATE TABLE IF NOT EXISTS `Babs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Babs: ~14 rows (approximately)
DELETE FROM `Babs`;
/*!40000 ALTER TABLE `Babs` DISABLE KEYS */;
INSERT INTO `Babs` (`Id`, `No`, `Nama`) VALUES
	(1, 1, 'Adab'),
	(2, 2, 'Asmaul-Husna'),
	(3, 3, 'Hafalan Doa'),
	(4, 4, 'Kedisiplinan'),
	(5, 5, 'Makna hadist'),
	(6, 6, 'Makna Qur\'an + Review Hafalan'),
	(7, 7, 'Materi Tambahan (Dari guru masing-masing)'),
	(8, 8, 'Surat-surat Pendek'),
	(9, 9, 'Tadarus'),
	(10, 10, 'Tajwid'),
	(11, 11, 'Tilawati'),
	(12, 12, 'Tatakrama'),
	(13, 13, 'Hafalan Surat'),
	(14, 14, 'Hafalan Dalil');
/*!40000 ALTER TABLE `Babs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.BuktiTransfers
CREATE TABLE IF NOT EXISTS `BuktiTransfers` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tujuan` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `NamaPengirim` longtext DEFAULT NULL,
  `NoRekening` longtext DEFAULT NULL,
  `NamaRekening` longtext DEFAULT NULL,
  `NamaBank` longtext DEFAULT NULL,
  `NomorHp` longtext DEFAULT NULL,
  `LampiranUrl` longtext DEFAULT NULL,
  `Jumlah` decimal(18,8) DEFAULT NULL,
  `Tanggal` datetime DEFAULT NULL,
  `DibuatOleh` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.BuktiTransfers: ~0 rows (approximately)
DELETE FROM `BuktiTransfers`;
/*!40000 ALTER TABLE `BuktiTransfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `BuktiTransfers` ENABLE KEYS */;

-- Dumping structure for table moslemdb.CashflowQurbans
CREATE TABLE IF NOT EXISTS `CashflowQurbans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Nama` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `Tipe` int(11) NOT NULL,
  `Kategori` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `HargaSatuan` double NOT NULL,
  `Quantity` double NOT NULL,
  `Total` double NOT NULL,
  `Keterangan` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `DibayarOleh` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `DiterimaOleh` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  `Satuan` longtext CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table moslemdb.CashflowQurbans: ~0 rows (approximately)
DELETE FROM `CashflowQurbans`;
/*!40000 ALTER TABLE `CashflowQurbans` DISABLE KEYS */;
/*!40000 ALTER TABLE `CashflowQurbans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.ChatMessages
CREATE TABLE IF NOT EXISTS `ChatMessages` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ThreadId` bigint(20) NOT NULL,
  `UserName` longtext DEFAULT NULL,
  `Tanggal` datetime(6) NOT NULL,
  `Message` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.ChatMessages: ~2 rows (approximately)
DELETE FROM `ChatMessages`;
/*!40000 ALTER TABLE `ChatMessages` DISABLE KEYS */;
INSERT INTO `ChatMessages` (`Id`, `ThreadId`, `UserName`, `Tanggal`, `Message`) VALUES
	(1, 1, 'admin', '2023-05-23 08:34:47.477637', 'test'),
	(2, 1, 'admin', '2023-05-23 08:34:50.675805', 'ya');
/*!40000 ALTER TABLE `ChatMessages` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Cicilans
CREATE TABLE IF NOT EXISTS `Cicilans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Jumlah` double NOT NULL,
  `DibayarOleh` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `PinjamanId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Cicilans_PinjamanId` (`PinjamanId`),
  CONSTRAINT `FK_Cicilans_Pinjamans_PinjamanId` FOREIGN KEY (`PinjamanId`) REFERENCES `Pinjamans` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Cicilans: ~0 rows (approximately)
DELETE FROM `Cicilans`;
/*!40000 ALTER TABLE `Cicilans` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cicilans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Dapukans
CREATE TABLE IF NOT EXISTS `Dapukans` (
  `Id` bigint(20) NOT NULL DEFAULT 0,
  `Nama` varchar(250) NOT NULL DEFAULT '0',
  `OrderNo` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Dapukans: ~13 rows (approximately)
DELETE FROM `Dapukans`;
/*!40000 ALTER TABLE `Dapukans` DISABLE KEYS */;
INSERT INTO `Dapukans` (`Id`, `Nama`, `OrderNo`) VALUES
	(0, 'Khutbah', 13),
	(1, 'Ketua DKM', 1),
	(2, 'Wakil DKM', 2),
	(3, 'Pengajar', 3),
	(4, 'Muadzin', 4),
	(5, 'Keuangan', 5),
	(6, 'Aset', 6),
	(7, 'Kebersihan', 7),
	(8, 'Koperasi', 8),
	(9, 'Jenazah', 9),
	(10, 'Pengelola Sekolah', 10),
	(11, 'Pengelola Haji dan Umroh', 11),
	(12, 'Tim Dhuafa', 12);
/*!40000 ALTER TABLE `Dapukans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.DataBLs
CREATE TABLE IF NOT EXISTS `DataBLs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Urut` int(11) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  `BERAT` double NOT NULL,
  `BUNGKUS` double NOT NULL,
  `KP` longtext DEFAULT NULL,
  `KETERANGAN` longtext DEFAULT NULL,
  `Tahun` int(11) NOT NULL,
  `Jenis` int(11) NOT NULL,
  `SudahSiap` tinyint(1) NOT NULL,
  `SudahDiterima` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=345 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.DataBLs: ~0 rows (approximately)
DELETE FROM `DataBLs`;
/*!40000 ALTER TABLE `DataBLs` DISABLE KEYS */;
/*!40000 ALTER TABLE `DataBLs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.DataPembagians
CREATE TABLE IF NOT EXISTS `DataPembagians` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `KK` longtext DEFAULT NULL,
  `Nama` longtext DEFAULT NULL,
  `Status` longtext DEFAULT NULL,
  `Golongan` longtext DEFAULT NULL,
  `KP` longtext DEFAULT NULL,
  `Pembagian` double NOT NULL,
  `BL` double NOT NULL,
  `KAKI` double NOT NULL,
  `KEPALA` double NOT NULL,
  `TULANG` double NOT NULL,
  `JEROHAN` double NOT NULL,
  `APRESIASI` double NOT NULL,
  `Tahun` int(11) NOT NULL,
  `NoUrut` int(11) NOT NULL,
  `Kantong` longtext DEFAULT NULL,
  `SudahSiap` tinyint(1) NOT NULL,
  `SudahDiterima` tinyint(1) NOT NULL,
  `Sapi` longtext DEFAULT NULL,
  `HewanQurbanId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_DataPembagians_HewanQurbanId` (`HewanQurbanId`),
  CONSTRAINT `FK_DataPembagians_HewanQurbans_HewanQurbanId` FOREIGN KEY (`HewanQurbanId`) REFERENCES `HewanQurbans` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2216 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.DataPembagians: ~0 rows (approximately)
DELETE FROM `DataPembagians`;
/*!40000 ALTER TABLE `DataPembagians` DISABLE KEYS */;
/*!40000 ALTER TABLE `DataPembagians` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Dokumens
CREATE TABLE IF NOT EXISTS `Dokumens` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Nama` longtext NOT NULL,
  `Kategori` longtext NOT NULL,
  `Keterangan` longtext NOT NULL,
  `FileUrl` longtext DEFAULT NULL,
  `CreatedBy` longtext NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Dokumens: ~0 rows (approximately)
DELETE FROM `Dokumens`;
/*!40000 ALTER TABLE `Dokumens` DISABLE KEYS */;
/*!40000 ALTER TABLE `Dokumens` ENABLE KEYS */;

-- Dumping structure for table moslemdb.EvaluasiKelass
CREATE TABLE IF NOT EXISTS `EvaluasiKelass` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Nilai` int(11) NOT NULL,
  `NilaiMutu` longtext DEFAULT NULL,
  `JamaahId` bigint(20) NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `KeteranganDari` longtext DEFAULT NULL,
  `MateriPerKelasId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_EvaluasiKelass_JamaahId` (`JamaahId`),
  KEY `IX_EvaluasiKelass_MateriPerKelasId` (`MateriPerKelasId`),
  CONSTRAINT `FK_EvaluasiKelass_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_EvaluasiKelass_MateriPerKelass_MateriPerKelasId` FOREIGN KEY (`MateriPerKelasId`) REFERENCES `MateriPerKelass` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.EvaluasiKelass: ~0 rows (approximately)
DELETE FROM `EvaluasiKelass`;
/*!40000 ALTER TABLE `EvaluasiKelass` DISABLE KEYS */;
/*!40000 ALTER TABLE `EvaluasiKelass` ENABLE KEYS */;

-- Dumping structure for table moslemdb.HargaBerasZakats
CREATE TABLE IF NOT EXISTS `HargaBerasZakats` (
  `Tahun` int(11) NOT NULL AUTO_INCREMENT,
  `HargaJualBeras` bigint(20) NOT NULL,
  PRIMARY KEY (`Tahun`)
) ENGINE=InnoDB AUTO_INCREMENT=2024 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.HargaBerasZakats: ~2 rows (approximately)
DELETE FROM `HargaBerasZakats`;
/*!40000 ALTER TABLE `HargaBerasZakats` DISABLE KEYS */;
INSERT INTO `HargaBerasZakats` (`Tahun`, `HargaJualBeras`) VALUES
	(2021, 35000),
	(2022, 40000),
	(2023, 40000);
/*!40000 ALTER TABLE `HargaBerasZakats` ENABLE KEYS */;

-- Dumping structure for table moslemdb.HeaderPenerimaanInfaqSodakohs
CREATE TABLE IF NOT EXISTS `HeaderPenerimaanInfaqSodakohs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `DiterimaOleh` longtext DEFAULT NULL,
  `Penyetor` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `Total` double NOT NULL,
  `JamaahId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_HeaderPenerimaanInfaqSodakohs_JamaahId` (`JamaahId`),
  CONSTRAINT `FK_HeaderPenerimaanInfaqSodakohs_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.HeaderPenerimaanInfaqSodakohs: ~0 rows (approximately)
DELETE FROM `HeaderPenerimaanInfaqSodakohs`;
/*!40000 ALTER TABLE `HeaderPenerimaanInfaqSodakohs` DISABLE KEYS */;
/*!40000 ALTER TABLE `HeaderPenerimaanInfaqSodakohs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.HewanQurbans
CREATE TABLE IF NOT EXISTS `HewanQurbans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `Pemilik` longtext DEFAULT NULL,
  `Bruto` double NOT NULL,
  `Netto` double NOT NULL,
  `PersenNet` double NOT NULL,
  `KepalaSapi` longtext DEFAULT NULL,
  `Tahun` int(11) NOT NULL,
  `Jenis` int(11) NOT NULL,
  `NoUrutPotong` int(11) DEFAULT 0,
  `Keterangan` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.HewanQurbans: ~29 rows (approximately)
DELETE FROM `HewanQurbans`;
/*!40000 ALTER TABLE `HewanQurbans` DISABLE KEYS */;
INSERT INTO `HewanQurbans` (`Id`, `No`, `Pemilik`, `Bruto`, `Netto`, `PersenNet`, `KepalaSapi`, `Tahun`, `Jenis`, `NoUrutPotong`, `Keterangan`) VALUES
	(1, 1, 'P DIDIK', 455, 136.5, 0.3, 'P DIDIK', 2020, 0, 7, NULL),
	(2, 2, 'P EKO', 600, 150, 0.25, 'P EKO', 2020, 0, 1, NULL),
	(3, 3, 'P RUBIYO', 400, 100, 0.25, 'P RUBIYO', 2020, 0, 8, NULL),
	(4, 4, 'BER 10 RAMA', 600, 150, 0.25, 'BU SARAH', 2020, 0, 5, NULL),
	(5, 5, 'KLP P BAYU', 500, 125, 0.25, 'P BAYU', 2020, 0, 4, NULL),
	(6, 6, 'KLP P IQBAL', 800, 200, 0.25, 'P IQBAL', 2020, 0, 6, NULL),
	(7, 7, 'KLP PAK PUTRA', 520, 130, 0.25, 'P PUTRA', 2020, 0, 3, NULL),
	(8, 8, 'KLP JAMAAH ALDI', 600, 150, 0.25, 'P KARTA', 2020, 0, 9, NULL),
	(9, 9, 'BER 7 DANI', 470, 117.5, 0.25, 'P YUSUF', 2020, 0, 2, NULL),
	(98, 1, 'P DIDIK', 607, 151.75, 0.25, 'P DIDIK', 2021, 0, 0, 'LM/148'),
	(99, 2, 'P EKO', 950, 237.5, 0.25, 'P EKO', 2021, 0, 0, '-'),
	(100, 3, 'P RUBIYO', 300, 90, 0.3, 'P RUBIYO', 2021, 0, 0, '-'),
	(101, 4, 'BER 9', 512, 153.6, 0.3, 'P HENDRO', 2021, 0, 0, 'BL240'),
	(102, 5, 'KLP P BAYU', 630, 157.5, 0.25, 'P BAYU', 2021, 0, 0, '-'),
	(103, 6, 'P FADHIL', 490, 122.5, 0.25, 'P FADHIL', 2021, 0, 0, '-'),
	(104, 7, 'KLP PAK PUTRA', 500, 125, 0.25, 'P PUTRA', 2021, 0, 0, '-'),
	(105, 8, 'KELOMPOK', 600, 150, 0.25, 'BU SARAH', 2021, 0, 0, 'LM37'),
	(106, 9, 'BU JAKA', 297, 89.1, 0.3, 'BU JAKA', 2021, 0, 0, 'P251'),
	(107, 10, 'P HARDONO', 423, 126.89999999999999, 0.3, 'P HARDONO', 2021, 0, 0, 'BL198'),
	(108, 11, 'P ZAINAL', 346, 103.8, 0.3, 'P ZAINAL', 2021, 0, 0, 'BL172'),
	(118, 1, 'P DIDIK', 560, 140, 0.25, 'P DIDIK', 2022, 0, 3, NULL),
	(119, 2, 'P EKO', 600, 150, 0.25, 'P EKO', 2022, 0, 1, NULL),
	(120, 3, 'P RUBIYO', 400, 80, 0.2, 'P RUBIYO', 2022, 0, 7, NULL),
	(121, 4, 'KLP GAB LIMO', 600, 150, 0.25, 'Bu Sarah', 2022, 0, 2, NULL),
	(122, 5, 'KLP P BAYU', 437, 109.25, 0.25, 'P BAYU', 2022, 0, 6, NULL),
	(123, 6, 'KLP PAK PUTRA', 450, 112.5, 0.25, 'P PUTRA', 2022, 0, 5, NULL),
	(124, 7, 'KLP BER 9', 515, 128.75, 0.25, 'Bu Dewi', 2022, 0, 4, NULL),
	(125, 8, 'P Hardono', 370, 111, 0.3, 'P Hardono', 2022, 0, 8, NULL),
	(126, 9, 'FADHIL', 370, 111, 0.3, 'P Zainal', 2022, 0, 9, NULL);
/*!40000 ALTER TABLE `HewanQurbans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.InfoMasjids
CREATE TABLE IF NOT EXISTS `InfoMasjids` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `KodeMasjid` longtext DEFAULT NULL,
  `DataMasjid` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.InfoMasjids: ~0 rows (approximately)
DELETE FROM `InfoMasjids`;
/*!40000 ALTER TABLE `InfoMasjids` DISABLE KEYS */;
INSERT INTO `InfoMasjids` (`Id`, `KodeMasjid`, `DataMasjid`) VALUES
	(2, 'ALAMIN', '{"Imam":"Ust. Asep","Muazin":"Ust. Amir","Khotib":"Ust. Asep","WaktuShalats":[],"Kegiatan":[],"Lokasi":"Jl Cibulet No.1","Cuaca":0,"TanggalHariIni":"0001-01-01T00:00:00","NamaMasjid":"Al Amin","Pengumuman":[{"Keterangan":"Semangat dalam ibadah"},{"Keterangan":"Perbanyak Sodakoh"},{"Keterangan":"Jangan malas dalam perjuangan agama"},{"Keterangan":"Rajin mengaji dan berbakti pada orang tua"}],"ImageUrl":[],"VideoUrl":null}');
/*!40000 ALTER TABLE `InfoMasjids` ENABLE KEYS */;

-- Dumping structure for table moslemdb.InfoQurbans
CREATE TABLE IF NOT EXISTS `InfoQurbans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tahun` int(11) NOT NULL,
  `TglMulai` datetime(6) NOT NULL,
  `TglSelesai` datetime(6) NOT NULL,
  `PanitiaUrl` longtext DEFAULT NULL,
  `InfoLainUrl` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.InfoQurbans: ~3 rows (approximately)
DELETE FROM `InfoQurbans`;
/*!40000 ALTER TABLE `InfoQurbans` DISABLE KEYS */;
INSERT INTO `InfoQurbans` (`Id`, `Tahun`, `TglMulai`, `TglSelesai`, `PanitiaUrl`, `InfoLainUrl`) VALUES
	(1, 2020, '2021-05-29 07:00:00.000000', '2021-05-29 16:00:00.000000', '', ' '),
	(2, 2021, '2021-07-20 00:00:00.000000', '2021-07-22 00:00:00.000000', '', ''),
	(3, 2022, '2022-07-09 00:00:00.000000', '2022-07-09 00:00:00.000000', '', '');
/*!40000 ALTER TABLE `InfoQurbans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Jamaahs
CREATE TABLE IF NOT EXISTS `Jamaahs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `KK` varchar(50) DEFAULT NULL,
  `Nama` varchar(256) DEFAULT NULL,
  `Posisi` int(11) DEFAULT NULL,
  `Gol` varchar(10) DEFAULT NULL,
  `Kelamin` char(1) DEFAULT NULL,
  `TanggalLahir` datetime DEFAULT NULL,
  `TempatLahir` varchar(500) DEFAULT NULL,
  `Alamat` varchar(500) DEFAULT NULL,
  `Telepon` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `CreatedBy` varchar(256) DEFAULT NULL,
  `Status` int(11) DEFAULT 0,
  `PhotoUrl` varchar(600) DEFAULT NULL,
  `KelasId` bigint(20) DEFAULT NULL,
  `Ayah` varchar(500) DEFAULT NULL,
  `Ibu` varchar(500) DEFAULT NULL,
  `FatherId` bigint(20) DEFAULT NULL,
  `MotherId` bigint(20) DEFAULT NULL,
  `Pekerjaan` varchar(500) DEFAULT NULL,
  `Pendidikan` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Jamaahs_Kelass_KelasId` (`KelasId`),
  CONSTRAINT `FK_Jamaahs_Kelass_KelasId` FOREIGN KEY (`KelasId`) REFERENCES `Kelass` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Jamaahs: ~8 rows (approximately)
DELETE FROM `Jamaahs`;
/*!40000 ALTER TABLE `Jamaahs` DISABLE KEYS */;
INSERT INTO `Jamaahs` (`Id`, `KK`, `Nama`, `Posisi`, `Gol`, `Kelamin`, `TanggalLahir`, `TempatLahir`, `Alamat`, `Telepon`, `Email`, `CreatedBy`, `Status`, `PhotoUrl`, `KelasId`, `Ayah`, `Ibu`, `FatherId`, `MotherId`, `Pekerjaan`, `Pendidikan`) VALUES
	(192, 'A001', 'Asep Dengkul', 7, '0', 'L', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL),
	(193, 'A002', 'Abyan Usman', 7, '0', 'P', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL),
	(194, 'B001', 'Beni Sukur', 7, '0', 'L', '2007-07-29 00:00:00', 'Bogor', 'Jl Baru No.1', NULL, NULL, NULL, 1, NULL, 5, '', '', 0, 0, NULL, NULL),
	(195, 'B002', 'Bogel Asmar', 7, '0', 'L', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 5, NULL, NULL, 0, 0, NULL, NULL),
	(196, 'C001', 'Carli Houten', 7, '0', 'L', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, 0, 0, NULL, NULL),
	(197, 'C001', 'Cami Laila', 7, '0', 'P', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, 0, 0, NULL, NULL),
	(198, 'D001', 'Doni Kerbol', 7, '0', 'L', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL),
	(199, 'D001', 'Dasima Sumbi', 7, '0', 'P', NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL);
/*!40000 ALTER TABLE `Jamaahs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.KalenderKelompoks
CREATE TABLE IF NOT EXISTS `KalenderKelompoks` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Kegiatan` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `TanggalMulai` datetime(6) NOT NULL,
  `TanggalSelesai` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.KalenderKelompoks: ~2 rows (approximately)
DELETE FROM `KalenderKelompoks`;
/*!40000 ALTER TABLE `KalenderKelompoks` DISABLE KEYS */;
INSERT INTO `KalenderKelompoks` (`Id`, `Kegiatan`, `Keterangan`, `TanggalMulai`, `TanggalSelesai`) VALUES
	(1, 'Kajian Rutin Sabtu', 'Al Quran dan Hadith', '2021-09-23 00:00:00.000000', '2021-09-23 00:00:00.000000'),
	(2, 'Kajian Rutin Minggu', 'Al Quran dan Hadith', '2021-09-25 00:00:00.000000', '2021-09-25 00:00:00.000000');
/*!40000 ALTER TABLE `KalenderKelompoks` ENABLE KEYS */;

-- Dumping structure for table moslemdb.KalenderPendidikans
CREATE TABLE IF NOT EXISTS `KalenderPendidikans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Kegiatan` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `TanggalMulai` datetime(6) NOT NULL,
  `TanggalSelesai` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.KalenderPendidikans: ~3 rows (approximately)
DELETE FROM `KalenderPendidikans`;
/*!40000 ALTER TABLE `KalenderPendidikans` DISABLE KEYS */;
INSERT INTO `KalenderPendidikans` (`Id`, `Kegiatan`, `Keterangan`, `TanggalMulai`, `TanggalSelesai`) VALUES
	(1, 'Kegiatan A', 'ok', '2021-08-26 00:00:00.000000', '2021-08-27 00:00:00.000000'),
	(2, 'Kegiatan B', 'ok', '2021-08-30 00:00:00.000000', '2021-08-30 00:00:00.000000'),
	(3, 'Kegiatan C', 'yes', '2021-08-01 00:00:00.000000', '2021-08-04 00:00:00.000000');
/*!40000 ALTER TABLE `KalenderPendidikans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Kelass
CREATE TABLE IF NOT EXISTS `Kelass` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `MinUsia` int(11) NOT NULL,
  `MaxUsia` int(11) NOT NULL,
  `Kelompok` longtext DEFAULT NULL,
  `WaliKelas` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Kelass: ~7 rows (approximately)
DELETE FROM `Kelass`;
/*!40000 ALTER TABLE `Kelass` DISABLE KEYS */;
INSERT INTO `Kelass` (`Id`, `Nama`, `MinUsia`, `MaxUsia`, `Kelompok`, `WaliKelas`) VALUES
	(1, 'Kelas PAUD', 1, 4, 'Al Amin', 'Bu Aip'),
	(2, 'Kelas A', 5, 7, 'Al Amin', 'Pak Omen'),
	(3, 'Kelas B ', 8, 9, 'Al Amin', 'Mas Togi'),
	(4, 'Kelas C ', 10, 12, 'Al Amin', 'Mba Sita'),
	(5, 'Pra Remaja', 13, 15, 'Al Amin', 'Mas Sukur'),
	(6, 'Muda-mudi', 18, 28, 'Al Amin', 'Bu Lina'),
	(7, 'Remaja', 16, 18, 'Al Amin', 'Mas Sukur');
/*!40000 ALTER TABLE `Kelass` ENABLE KEYS */;

-- Dumping structure for table moslemdb.KPIBatches
CREATE TABLE IF NOT EXISTS `KPIBatches` (
  `BatchNo` int(11) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) DEFAULT NULL,
  `PeriodePenilaian` int(11) NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  PRIMARY KEY (`BatchNo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.KPIBatches: ~0 rows (approximately)
DELETE FROM `KPIBatches`;
/*!40000 ALTER TABLE `KPIBatches` DISABLE KEYS */;
INSERT INTO `KPIBatches` (`BatchNo`, `Tanggal`, `PeriodePenilaian`, `Keterangan`) VALUES
	(1, '2022-03-29 00:00:00.000000', 0, 'batch perdana');
/*!40000 ALTER TABLE `KPIBatches` ENABLE KEYS */;

-- Dumping structure for table moslemdb.KPIs
CREATE TABLE IF NOT EXISTS `KPIs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `DapukanId` bigint(20) NOT NULL,
  `Parameter` longtext DEFAULT NULL,
  `MinScore` int(11) NOT NULL,
  `MaxScore` int(11) NOT NULL,
  `Deskripsi` longtext DEFAULT NULL,
  `Kategori` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_KPIs_DapukanId` (`DapukanId`),
  CONSTRAINT `FK_KPIs_Dapukans_DapukanId` FOREIGN KEY (`DapukanId`) REFERENCES `Dapukans` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.KPIs: ~2 rows (approximately)
DELETE FROM `KPIs`;
/*!40000 ALTER TABLE `KPIs` DISABLE KEYS */;
INSERT INTO `KPIs` (`Id`, `DapukanId`, `Parameter`, `MinScore`, `MaxScore`, `Deskripsi`, `Kategori`) VALUES
	(1, 1, 'Pemahaman Organisasi', 1, 5, 'Memahami organisasi DKM dan memiliki jaringan yang baik', 'Organisasi'),
	(4, 1, 'Pemahaman Hukum', 1, 5, 'Memahami hukum islam dengan baik, dan mempraktekannya', 'Hukum'),
	(7, 1, 'Kemampuan Eksekusi Kegiatan', 1, 5, 'Mampu menjalankan kegiatan-kegiatan DKM berserta sumber daya yang dibutuhkan', 'Kegiatan');
/*!40000 ALTER TABLE `KPIs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.KPIScoreHeaders
CREATE TABLE IF NOT EXISTS `KPIScoreHeaders` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `BatchNo` int(11) DEFAULT NULL,
  `Dapukan` longtext DEFAULT NULL,
  `Nama` longtext DEFAULT NULL,
  `TanggalPenilaian` datetime(6) DEFAULT NULL,
  `PenilaianOleh` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_KPIScoreHeaders_BatchNo` (`BatchNo`),
  CONSTRAINT `FK_KPIScoreHeaders_KPIBatches_BatchNo` FOREIGN KEY (`BatchNo`) REFERENCES `KPIBatches` (`BatchNo`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.KPIScoreHeaders: ~0 rows (approximately)
DELETE FROM `KPIScoreHeaders`;
/*!40000 ALTER TABLE `KPIScoreHeaders` DISABLE KEYS */;
/*!40000 ALTER TABLE `KPIScoreHeaders` ENABLE KEYS */;

-- Dumping structure for table moslemdb.KPIScores
CREATE TABLE IF NOT EXISTS `KPIScores` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `KPIscoreHeaderId` bigint(20) NOT NULL,
  `KPIId` bigint(20) NOT NULL,
  `Nilai` int(11) NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_KPIScores_KPIId` (`KPIId`),
  KEY `IX_KPIScores_KPIscoreHeaderId` (`KPIscoreHeaderId`),
  CONSTRAINT `FK_KPIScores_KPIScoreHeaders_KPIscoreHeaderId` FOREIGN KEY (`KPIscoreHeaderId`) REFERENCES `KPIScoreHeaders` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_KPIScores_KPIs_KPIId` FOREIGN KEY (`KPIId`) REFERENCES `KPIs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.KPIScores: ~0 rows (approximately)
DELETE FROM `KPIScores`;
/*!40000 ALTER TABLE `KPIScores` DISABLE KEYS */;
/*!40000 ALTER TABLE `KPIScores` ENABLE KEYS */;

-- Dumping structure for table moslemdb.LaporanHasilBelajars
CREATE TABLE IF NOT EXISTS `LaporanHasilBelajars` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `JamaahId` bigint(20) NOT NULL,
  `KelasId` bigint(20) NOT NULL,
  `SikapAkhlak` longtext DEFAULT NULL,
  `Kerajinan` longtext DEFAULT NULL,
  `KebersihanKerapihan` longtext DEFAULT NULL,
  `Tahun` int(11) NOT NULL,
  `Semester` int(11) NOT NULL,
  `Sakit` int(11) NOT NULL,
  `Ijin` int(11) NOT NULL,
  `Hadir` int(11) NOT NULL,
  `Alpha` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_LaporanHasilBelajars_JamaahId` (`JamaahId`),
  KEY `IX_LaporanHasilBelajars_KelasId` (`KelasId`),
  CONSTRAINT `FK_LaporanHasilBelajars_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_LaporanHasilBelajars_Kelass_KelasId` FOREIGN KEY (`KelasId`) REFERENCES `Kelass` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.LaporanHasilBelajars: ~0 rows (approximately)
DELETE FROM `LaporanHasilBelajars`;
/*!40000 ALTER TABLE `LaporanHasilBelajars` DISABLE KEYS */;
/*!40000 ALTER TABLE `LaporanHasilBelajars` ENABLE KEYS */;

-- Dumping structure for table moslemdb.MateriPerKelass
CREATE TABLE IF NOT EXISTS `MateriPerKelass` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `MateriId` bigint(20) DEFAULT NULL,
  `KelasId` bigint(20) DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `Semester` int(11) NOT NULL,
  `Tahun` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_MateriPerKelass_KelasId` (`KelasId`),
  KEY `IX_MateriPerKelass_MateriId` (`MateriId`),
  CONSTRAINT `FK_MateriPerKelass_Kelass_KelasId` FOREIGN KEY (`KelasId`) REFERENCES `Kelass` (`Id`),
  CONSTRAINT `FK_MateriPerKelass_Materis_MateriId` FOREIGN KEY (`MateriId`) REFERENCES `Materis` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=1961 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.MateriPerKelass: ~479 rows (approximately)
DELETE FROM `MateriPerKelass`;
/*!40000 ALTER TABLE `MateriPerKelass` DISABLE KEYS */;
INSERT INTO `MateriPerKelass` (`Id`, `No`, `MateriId`, `KelasId`, `Keterangan`, `IsActive`, `Semester`, `Tahun`) VALUES
	(1205, 1, 89, 3, NULL, 1, 2, 2021),
	(1209, 2, 95, 3, NULL, 1, 2, 2021),
	(1210, 3, 96, 3, NULL, 1, 2, 2021),
	(1211, 4, 97, 3, NULL, 1, 2, 2021),
	(1212, 5, 98, 3, NULL, 1, 2, 2021),
	(1213, 6, 99, 3, NULL, 1, 2, 2021),
	(1220, 7, 208, 3, NULL, 1, 2, 2021),
	(1221, 8, 37, 3, NULL, 1, 2, 2021),
	(1222, 9, 100, 3, NULL, 1, 2, 2021),
	(1223, 10, 127, 3, NULL, 1, 2, 2021),
	(1224, 11, 149, 3, NULL, 1, 2, 2021),
	(1226, 12, 174, 3, NULL, 1, 2, 2021),
	(1229, 13, 90, 3, NULL, 1, 2, 2021),
	(1230, 14, 91, 3, NULL, 1, 2, 2021),
	(1231, 15, 18, 3, NULL, 1, 2, 2021),
	(1232, 16, 19, 3, NULL, 1, 2, 2021),
	(1233, 17, 20, 3, NULL, 1, 2, 2021),
	(1234, 18, 51, 3, NULL, 1, 2, 2021),
	(1235, 19, 52, 3, NULL, 1, 2, 2021),
	(1236, 20, 53, 3, NULL, 1, 2, 2021),
	(1237, 21, 86, 3, NULL, 1, 2, 2021),
	(1238, 22, 87, 3, NULL, 1, 2, 2021),
	(1239, 23, 88, 3, NULL, 1, 2, 2021),
	(1245, 24, 79, 3, NULL, 1, 2, 2021),
	(1246, 25, 80, 3, NULL, 1, 2, 2021),
	(1249, 26, 207, 3, NULL, 1, 2, 2021),
	(1250, 1, 145, 4, NULL, 1, 2, 2021),
	(1251, 2, 202, 4, NULL, 1, 2, 2021),
	(1253, 3, 204, 4, NULL, 1, 2, 2021),
	(1254, 4, 205, 4, NULL, 1, 2, 2021),
	(1255, 5, 206, 4, NULL, 1, 2, 2021),
	(1266, 10, 201, 4, NULL, 1, 2, 2021),
	(1268, 12, 200, 4, NULL, 1, 2, 2021),
	(1269, 13, 198, 4, NULL, 1, 2, 2021),
	(1270, 14, 146, 4, NULL, 1, 2, 2021),
	(1271, 15, 147, 4, NULL, 1, 2, 2021),
	(1272, 16, 148, 4, NULL, 1, 2, 2021),
	(1285, 17, 199, 4, NULL, 1, 2, 2021),
	(1286, 18, 207, 4, NULL, 1, 2, 2021),
	(1334, 1, 21, 2, NULL, 1, 2, 2021),
	(1335, 2, 28, 2, NULL, 1, 2, 2021),
	(1337, 3, 30, 2, NULL, 1, 2, 2021),
	(1338, 4, 31, 2, NULL, 1, 2, 2021),
	(1339, 5, 32, 2, NULL, 1, 2, 2021),
	(1340, 6, 33, 2, NULL, 1, 2, 2021),
	(1341, 7, 34, 2, NULL, 1, 2, 2021),
	(1342, 8, 35, 2, NULL, 1, 2, 2021),
	(1344, 9, 96, 2, NULL, 1, 2, 2021),
	(1345, 10, 1, 2, NULL, 1, 2, 2021),
	(1346, 11, 2, 2, NULL, 1, 2, 2021),
	(1347, 12, 3, 2, NULL, 1, 2, 2021),
	(1348, 13, 4, 2, NULL, 1, 2, 2021),
	(1353, 15, 100, 2, NULL, 1, 2, 2021),
	(1354, 16, 127, 2, NULL, 1, 2, 2021),
	(1355, 17, 149, 2, NULL, 1, 2, 2021),
	(1357, 18, 174, 2, NULL, 1, 2, 2021),
	(1362, 19, 18, 2, NULL, 1, 2, 2021),
	(1363, 20, 19, 2, NULL, 1, 2, 2021),
	(1364, 21, 20, 2, NULL, 1, 2, 2021),
	(1365, 22, 51, 2, NULL, 1, 2, 2021),
	(1366, 23, 52, 2, NULL, 1, 2, 2021),
	(1369, 24, 10, 2, NULL, 1, 2, 2021),
	(1376, 25, 17, 2, NULL, 1, 2, 2021),
	(1377, 26, 44, 2, NULL, 1, 2, 2021),
	(1382, 27, 207, 2, NULL, 1, 2, 2021),
	(1383, 1, 21, 1, NULL, 1, 2, 2021),
	(1387, 2, 30, 1, NULL, 1, 2, 2021),
	(1388, 3, 31, 1, NULL, 1, 2, 2021),
	(1389, 4, 32, 1, NULL, 1, 2, 2021),
	(1390, 5, 33, 1, NULL, 1, 2, 2021),
	(1394, 6, 1, 1, NULL, 1, 2, 2021),
	(1395, 7, 2, 1, NULL, 1, 2, 2021),
	(1396, 8, 3, 1, NULL, 1, 2, 2021),
	(1397, 9, 4, 1, NULL, 1, 2, 2021),
	(1400, 10, 35, 1, NULL, 1, 2, 2021),
	(1404, 11, 22, 1, NULL, 1, 2, 2021),
	(1406, 12, 18, 1, NULL, 1, 2, 2021),
	(1407, 13, 19, 1, NULL, 1, 2, 2021),
	(1408, 14, 20, 1, NULL, 1, 2, 2021),
	(1409, 15, 8, 1, NULL, 1, 2, 2021),
	(1410, 16, 9, 1, NULL, 1, 2, 2021),
	(1412, 17, 10, 1, NULL, 1, 2, 2021),
	(1413, 18, 12, 1, NULL, 1, 2, 2021),
	(1414, 19, 13, 1, NULL, 1, 2, 2021),
	(1415, 20, 14, 1, NULL, 1, 2, 2021),
	(1416, 21, 15, 1, NULL, 1, 2, 2021),
	(1417, 22, 16, 1, NULL, 1, 2, 2021),
	(1418, 23, 17, 1, NULL, 1, 2, 2021),
	(1419, 24, 44, 1, NULL, 1, 2, 2021),
	(1420, 25, 11, 1, NULL, 1, 2, 2021),
	(1421, 26, 37, 1, NULL, 1, 2, 2021),
	(1422, 1, 287, 5, NULL, 1, 2, 2021),
	(1423, 2, 294, 5, NULL, 1, 2, 2021),
	(1424, 3, 303, 5, NULL, 1, 2, 2021),
	(1425, 4, 302, 5, NULL, 1, 2, 2021),
	(1426, 5, 301, 5, NULL, 1, 2, 2021),
	(1427, 6, 338, 5, NULL, 1, 2, 2021),
	(1428, 7, 206, 5, NULL, 1, 2, 2021),
	(1429, 8, 295, 5, NULL, 1, 2, 2021),
	(1430, 9, 274, 5, NULL, 1, 2, 2021),
	(1431, 10, 272, 5, NULL, 1, 2, 2021),
	(1432, 11, 271, 5, NULL, 1, 2, 2021),
	(1433, 12, 313, 5, NULL, 1, 2, 2021),
	(1434, 13, 312, 5, NULL, 1, 2, 2021),
	(1435, 14, 284, 5, NULL, 1, 2, 2021),
	(1436, 15, 320, 5, NULL, 1, 2, 2021),
	(1437, 16, 273, 5, NULL, 1, 2, 2021),
	(1438, 17, 296, 5, NULL, 1, 2, 2021),
	(1439, 27, 51, 1, NULL, 1, 2, 2021),
	(1440, 28, 90, 1, NULL, 1, 2, 2021),
	(1441, 29, 91, 1, NULL, 1, 2, 2021),
	(1442, 30, 167, 1, NULL, 1, 2, 2021),
	(1444, 28, 262, 2, NULL, 1, 2, 2021),
	(1457, 27, 173, 3, NULL, 1, 2, 2021),
	(1461, 20, 172, 4, NULL, 1, 2, 2021),
	(1463, 21, 232, 4, NULL, 1, 2, 2021),
	(1464, 22, 234, 4, NULL, 1, 2, 2021),
	(1471, 24, 401, 4, NULL, 1, 2, 2021),
	(1472, 25, 184, 4, NULL, 1, 2, 2021),
	(1474, 28, 48, 3, NULL, 1, 2, 2021),
	(1475, 29, 49, 3, NULL, 1, 2, 2021),
	(1477, 30, 108, 3, NULL, 1, 2, 2021),
	(1478, 31, 110, 3, NULL, 1, 2, 2021),
	(1479, 32, 111, 3, NULL, 1, 2, 2021),
	(1482, 33, 141, 3, NULL, 1, 2, 2021),
	(1483, 34, 39, 3, NULL, 1, 2, 2021),
	(1484, 35, 40, 3, NULL, 1, 2, 2021),
	(1485, 36, 41, 3, NULL, 1, 2, 2021),
	(1487, 37, 5, 3, NULL, 1, 2, 2021),
	(1488, 38, 7, 3, NULL, 1, 2, 2021),
	(1489, 29, 87, 2, NULL, 1, 1, 2022),
	(1490, 30, 53, 2, NULL, 1, 1, 2022),
	(1491, 31, 86, 2, NULL, 1, 1, 2022),
	(1492, 32, 88, 2, NULL, 1, 1, 2022),
	(1493, 39, 115, 3, NULL, 1, 1, 2022),
	(1494, 40, 167, 3, NULL, 1, 1, 2022),
	(1495, 41, 56, 3, NULL, 1, 1, 2022),
	(1496, 42, 116, 3, NULL, 1, 1, 2022),
	(1497, 43, 117, 3, NULL, 1, 1, 2022),
	(1498, 18, 172, 5, NULL, 1, 1, 2022),
	(1512, 1, 404, 6, '-', 1, 1, 2022),
	(1513, 2, 405, 6, '-', 1, 1, 2022),
	(1514, 3, 406, 6, '-', 1, 1, 2022),
	(1515, 4, 407, 6, '-', 1, 1, 2022),
	(1516, 5, 408, 6, '-', 1, 1, 2022),
	(1517, 6, 409, 6, '-', 1, 1, 2022),
	(1518, 7, 410, 6, '-', 1, 1, 2022),
	(1519, 8, 411, 6, '-', 1, 1, 2022),
	(1520, 9, 412, 6, '-', 1, 1, 2022),
	(1521, 10, 413, 6, '-', 1, 1, 2022),
	(1522, 11, 414, 6, '-', 1, 1, 2022),
	(1523, 12, 415, 6, '-', 1, 1, 2022),
	(1524, 13, 416, 6, '-', 1, 1, 2022),
	(1525, 14, 417, 6, '-', 1, 1, 2022),
	(1526, 15, 418, 6, '-', 1, 1, 2022),
	(1527, 16, 419, 6, '-', 1, 1, 2022),
	(1528, 17, 420, 6, '-', 1, 1, 2022),
	(1626, 31, 262, 1, NULL, 1, 1, 2022),
	(1627, 33, 42, 2, NULL, 1, 1, 2022),
	(1628, 34, 147, 2, NULL, 1, 1, 2022),
	(1629, 35, 169, 2, NULL, 1, 1, 2022),
	(1630, 36, 115, 2, NULL, 1, 1, 2022),
	(1631, 37, 116, 2, NULL, 1, 1, 2022),
	(1632, 38, 117, 2, NULL, 1, 1, 2022),
	(1633, 39, 142, 2, NULL, 1, 1, 2022),
	(1634, 40, 71, 2, NULL, 1, 1, 2022),
	(1637, 43, 107, 2, NULL, 1, 1, 2022),
	(1638, 44, 133, 2, NULL, 1, 1, 2022),
	(1639, 45, 126, 2, NULL, 1, 1, 2022),
	(1640, 46, 200, 2, NULL, 1, 1, 2022),
	(1643, 49, 118, 2, NULL, 1, 1, 2022),
	(1644, 44, 268, 3, NULL, 1, 1, 2022),
	(1645, 45, 171, 3, NULL, 1, 1, 2022),
	(1646, 46, 205, 3, NULL, 1, 1, 2022),
	(1647, 47, 198, 3, NULL, 1, 1, 2022),
	(1648, 48, 184, 3, NULL, 1, 1, 2022),
	(1649, 26, 295, 4, NULL, 1, 1, 2022),
	(1650, 27, 294, 4, NULL, 1, 1, 2022),
	(1651, 28, 296, 4, NULL, 1, 1, 2022),
	(1652, 29, 284, 4, NULL, 1, 1, 2022),
	(1653, 19, 285, 5, NULL, 1, 1, 2022),
	(1654, 20, 311, 5, NULL, 1, 1, 2022),
	(1655, 21, 387, 5, NULL, 1, 1, 2022),
	(1656, 22, 234, 5, NULL, 1, 1, 2022),
	(1657, 18, 366, 6, NULL, 1, 1, 2022),
	(1658, 19, 367, 6, NULL, 1, 1, 2022),
	(1659, 20, 380, 6, NULL, 1, 1, 2022),
	(1660, 21, 381, 6, NULL, 1, 1, 2022),
	(1661, 22, 382, 6, NULL, 1, 1, 2022),
	(1662, 23, 491, 6, NULL, 1, 1, 2022),
	(1663, 50, 45, 2, NULL, 1, 1, 2022),
	(1664, 51, 81, 2, NULL, 1, 1, 2022),
	(1665, 52, 83, 2, NULL, 1, 1, 2022),
	(1666, 53, 492, 2, NULL, 1, 1, 2022),
	(1667, 32, 23, 1, NULL, 1, 1, 2022),
	(1668, 33, 26, 1, NULL, 1, 1, 2022),
	(1669, 34, 27, 1, NULL, 1, 1, 2022),
	(1670, 35, 28, 1, NULL, 1, 1, 2022),
	(1671, 36, 58, 1, NULL, 1, 1, 2022),
	(1672, 37, 62, 1, NULL, 1, 1, 2022),
	(1673, 38, 29, 1, NULL, 1, 1, 2022),
	(1674, 39, 34, 1, NULL, 1, 1, 2022),
	(1675, 40, 36, 1, NULL, 1, 1, 2022),
	(1676, 41, 66, 1, NULL, 1, 1, 2022),
	(1677, 42, 5, 1, NULL, 1, 1, 2022),
	(1678, 43, 6, 1, NULL, 1, 1, 2022),
	(1679, 44, 7, 1, NULL, 1, 1, 2022),
	(1680, 45, 54, 1, NULL, 1, 2, 2022),
	(1681, 70, 41, 1, NULL, 1, 2, 2022),
	(1682, 69, 40, 1, NULL, 1, 2, 2022),
	(1683, 68, 39, 1, NULL, 1, 2, 2022),
	(1684, 67, 38, 1, NULL, 1, 2, 2022),
	(1685, 66, 70, 1, NULL, 1, 2, 2022),
	(1686, 65, 69, 1, NULL, 1, 2, 2022),
	(1687, 64, 68, 1, NULL, 1, 2, 2022),
	(1688, 63, 67, 1, NULL, 1, 2, 2022),
	(1689, 62, 65, 1, NULL, 1, 2, 2022),
	(1690, 61, 64, 1, NULL, 1, 2, 2022),
	(1691, 60, 63, 1, NULL, 1, 2, 2022),
	(1692, 59, 61, 1, NULL, 1, 2, 2022),
	(1693, 58, 60, 1, NULL, 1, 2, 2022),
	(1694, 57, 59, 1, NULL, 1, 2, 2022),
	(1695, 56, 50, 1, NULL, 1, 2, 2022),
	(1696, 55, 49, 1, NULL, 1, 2, 2022),
	(1697, 54, 48, 1, NULL, 1, 2, 2022),
	(1698, 53, 47, 1, NULL, 1, 2, 2022),
	(1699, 52, 46, 1, NULL, 1, 2, 2022),
	(1700, 51, 45, 1, NULL, 1, 2, 2022),
	(1701, 50, 53, 1, NULL, 1, 2, 2022),
	(1702, 49, 52, 1, NULL, 1, 2, 2022),
	(1703, 48, 57, 1, NULL, 1, 2, 2022),
	(1704, 47, 56, 1, NULL, 1, 2, 2022),
	(1705, 46, 55, 1, NULL, 1, 2, 2022),
	(1706, 71, 42, 1, NULL, 1, 2, 2022),
	(1707, 72, 43, 1, NULL, 1, 2, 2022),
	(1708, 54, 89, 2, NULL, 1, 1, 2022),
	(1711, 57, 72, 2, NULL, 1, 1, 2022),
	(1712, 58, 99, 2, NULL, 1, 1, 2022),
	(1713, 59, 98, 2, NULL, 1, 1, 2022),
	(1714, 60, 97, 2, NULL, 1, 1, 2022),
	(1715, 61, 95, 2, NULL, 1, 1, 2022),
	(1716, 62, 94, 2, NULL, 1, 1, 2022),
	(1717, 63, 93, 2, NULL, 1, 1, 2022),
	(1718, 64, 92, 2, NULL, 1, 1, 2022),
	(1720, 66, 84, 2, NULL, 1, 1, 2022),
	(1721, 67, 82, 2, NULL, 1, 1, 2022),
	(1722, 68, 80, 2, NULL, 1, 1, 2022),
	(1723, 69, 79, 2, NULL, 1, 1, 2022),
	(1724, 70, 78, 2, NULL, 1, 1, 2022),
	(1725, 71, 77, 2, NULL, 1, 1, 2022),
	(1726, 72, 91, 2, NULL, 1, 1, 2022),
	(1727, 73, 90, 2, NULL, 1, 1, 2022),
	(1728, 74, 75, 2, NULL, 1, 1, 2022),
	(1729, 75, 76, 2, NULL, 1, 1, 2022),
	(1733, 77, 108, 2, NULL, 1, 2, 2022),
	(1734, 78, 109, 2, NULL, 1, 2, 2022),
	(1735, 79, 110, 2, NULL, 1, 2, 2022),
	(1736, 80, 111, 2, NULL, 1, 2, 2022),
	(1737, 81, 112, 2, NULL, 1, 2, 2022),
	(1738, 82, 113, 2, NULL, 1, 2, 2022),
	(1739, 83, 114, 2, NULL, 1, 2, 2022),
	(1740, 84, 120, 2, NULL, 1, 2, 2022),
	(1741, 85, 121, 2, NULL, 1, 2, 2022),
	(1742, 86, 122, 2, NULL, 1, 2, 2022),
	(1743, 87, 123, 2, NULL, 1, 2, 2022),
	(1744, 88, 124, 2, NULL, 1, 2, 2022),
	(1745, 89, 125, 2, NULL, 1, 2, 2022),
	(1749, 76, 119, 2, NULL, 1, 2, 2022),
	(1750, 49, 145, 3, NULL, 1, 1, 2022),
	(1751, 50, 130, 3, NULL, 1, 1, 2022),
	(1752, 51, 129, 3, NULL, 1, 1, 2022),
	(1753, 52, 128, 3, NULL, 1, 1, 2022),
	(1754, 53, 140, 3, NULL, 1, 1, 2022),
	(1755, 54, 139, 3, NULL, 1, 1, 2022),
	(1756, 55, 138, 3, NULL, 1, 1, 2022),
	(1757, 56, 137, 3, NULL, 1, 1, 2022),
	(1758, 57, 136, 3, NULL, 1, 1, 2022),
	(1759, 58, 135, 3, NULL, 1, 1, 2022),
	(1760, 59, 134, 3, NULL, 1, 1, 2022),
	(1761, 60, 133, 3, NULL, 1, 1, 2022),
	(1762, 61, 144, 3, NULL, 1, 1, 2022),
	(1763, 62, 143, 3, NULL, 1, 1, 2022),
	(1764, 63, 142, 3, NULL, 1, 1, 2022),
	(1765, 64, 148, 3, NULL, 1, 1, 2022),
	(1766, 65, 147, 3, NULL, 1, 1, 2022),
	(1767, 66, 146, 3, NULL, 1, 1, 2022),
	(1768, 67, 131, 3, NULL, 1, 1, 2022),
	(1769, 68, 132, 3, NULL, 1, 1, 2022),
	(1770, 88, 170, 3, NULL, 1, 2, 2022),
	(1771, 89, 172, 3, NULL, 1, 2, 2022),
	(1772, 87, 153, 3, NULL, 1, 2, 2022),
	(1773, 85, 151, 3, NULL, 1, 2, 2022),
	(1774, 70, 169, 3, NULL, 1, 2, 2022),
	(1775, 71, 164, 3, NULL, 1, 2, 2022),
	(1776, 72, 165, 3, NULL, 1, 2, 2022),
	(1777, 73, 166, 3, NULL, 1, 2, 2022),
	(1778, 74, 154, 3, NULL, 1, 2, 2022),
	(1779, 75, 155, 3, NULL, 1, 2, 2022),
	(1780, 76, 156, 3, NULL, 1, 2, 2022),
	(1781, 77, 157, 3, NULL, 1, 2, 2022),
	(1782, 78, 158, 3, NULL, 1, 2, 2022),
	(1783, 79, 159, 3, NULL, 1, 2, 2022),
	(1784, 80, 160, 3, NULL, 1, 2, 2022),
	(1785, 81, 161, 3, NULL, 1, 2, 2022),
	(1786, 82, 162, 3, NULL, 1, 2, 2022),
	(1787, 83, 163, 3, NULL, 1, 2, 2022),
	(1788, 84, 150, 3, NULL, 1, 2, 2022),
	(1789, 86, 152, 3, NULL, 1, 2, 2022),
	(1790, 69, 168, 3, NULL, 1, 2, 2022),
	(1791, 30, 179, 4, NULL, 1, 1, 2022),
	(1792, 31, 176, 4, NULL, 1, 1, 2022),
	(1793, 32, 175, 4, NULL, 1, 1, 2022),
	(1794, 33, 203, 4, NULL, 1, 1, 2022),
	(1795, 34, 197, 4, NULL, 1, 1, 2022),
	(1796, 35, 196, 4, NULL, 1, 1, 2022),
	(1797, 36, 195, 4, NULL, 1, 1, 2022),
	(1798, 37, 194, 4, NULL, 1, 1, 2022),
	(1799, 38, 193, 4, NULL, 1, 1, 2022),
	(1800, 39, 192, 4, NULL, 1, 1, 2022),
	(1801, 40, 177, 4, NULL, 1, 1, 2022),
	(1802, 41, 191, 4, NULL, 1, 1, 2022),
	(1803, 42, 189, 4, NULL, 1, 1, 2022),
	(1804, 43, 188, 4, NULL, 1, 1, 2022),
	(1805, 44, 187, 4, NULL, 1, 1, 2022),
	(1806, 45, 186, 4, NULL, 1, 1, 2022),
	(1807, 46, 185, 4, NULL, 1, 1, 2022),
	(1808, 47, 183, 4, NULL, 1, 1, 2022),
	(1809, 48, 182, 4, NULL, 1, 1, 2022),
	(1810, 49, 181, 4, NULL, 1, 1, 2022),
	(1811, 50, 180, 4, NULL, 1, 1, 2022),
	(1812, 51, 190, 4, NULL, 1, 1, 2022),
	(1813, 52, 178, 4, NULL, 1, 1, 2022),
	(1814, 96, 238, 4, NULL, 1, 2, 2022),
	(1815, 95, 237, 4, NULL, 1, 2, 2022),
	(1816, 94, 236, 4, NULL, 1, 2, 2022),
	(1817, 93, 235, 4, NULL, 1, 2, 2022),
	(1818, 92, 233, 4, NULL, 1, 2, 2022),
	(1819, 91, 254, 4, NULL, 1, 2, 2022),
	(1820, 90, 214, 4, NULL, 1, 2, 2022),
	(1821, 89, 213, 4, NULL, 1, 2, 2022),
	(1822, 88, 212, 4, NULL, 1, 2, 2022),
	(1823, 87, 211, 4, NULL, 1, 2, 2022),
	(1824, 86, 210, 4, NULL, 1, 2, 2022),
	(1825, 85, 209, 4, NULL, 1, 2, 2022),
	(1826, 84, 253, 4, NULL, 1, 2, 2022),
	(1827, 82, 251, 4, NULL, 1, 2, 2022),
	(1828, 54, 216, 4, NULL, 1, 2, 2022),
	(1829, 55, 217, 4, NULL, 1, 2, 2022),
	(1830, 56, 218, 4, NULL, 1, 2, 2022),
	(1831, 57, 219, 4, NULL, 1, 2, 2022),
	(1832, 58, 220, 4, NULL, 1, 2, 2022),
	(1833, 59, 231, 4, NULL, 1, 2, 2022),
	(1834, 60, 221, 4, NULL, 1, 2, 2022),
	(1835, 61, 222, 4, NULL, 1, 2, 2022),
	(1836, 62, 223, 4, NULL, 1, 2, 2022),
	(1837, 63, 224, 4, NULL, 1, 2, 2022),
	(1838, 64, 225, 4, NULL, 1, 2, 2022),
	(1839, 65, 226, 4, NULL, 1, 2, 2022),
	(1840, 66, 227, 4, NULL, 1, 2, 2022),
	(1841, 83, 252, 4, NULL, 1, 2, 2022),
	(1842, 67, 228, 4, NULL, 1, 2, 2022),
	(1843, 69, 230, 4, NULL, 1, 2, 2022),
	(1844, 70, 239, 4, NULL, 1, 2, 2022),
	(1845, 71, 240, 4, NULL, 1, 2, 2022),
	(1846, 72, 241, 4, NULL, 1, 2, 2022),
	(1847, 73, 242, 4, NULL, 1, 2, 2022),
	(1848, 74, 243, 4, NULL, 1, 2, 2022),
	(1849, 75, 244, 4, NULL, 1, 2, 2022),
	(1850, 76, 245, 4, NULL, 1, 2, 2022),
	(1851, 77, 246, 4, NULL, 1, 2, 2022),
	(1852, 78, 247, 4, NULL, 1, 2, 2022),
	(1853, 79, 248, 4, NULL, 1, 2, 2022),
	(1854, 80, 249, 4, NULL, 1, 2, 2022),
	(1855, 81, 250, 4, NULL, 1, 2, 2022),
	(1856, 68, 229, 4, NULL, 1, 2, 2022),
	(1857, 53, 215, 4, NULL, 1, 2, 2022),
	(1858, 23, 286, 5, NULL, 1, 1, 2022),
	(1859, 24, 291, 5, NULL, 1, 1, 2022),
	(1860, 25, 290, 5, NULL, 1, 1, 2022),
	(1861, 26, 289, 5, NULL, 1, 1, 2022),
	(1862, 27, 300, 5, NULL, 1, 1, 2022),
	(1863, 28, 299, 5, NULL, 1, 1, 2022),
	(1864, 29, 298, 5, NULL, 1, 1, 2022),
	(1865, 30, 297, 5, NULL, 1, 1, 2022),
	(1866, 31, 281, 5, NULL, 1, 1, 2022),
	(1867, 32, 280, 5, NULL, 1, 1, 2022),
	(1868, 33, 279, 5, NULL, 1, 1, 2022),
	(1869, 34, 278, 5, NULL, 1, 1, 2022),
	(1870, 35, 277, 5, NULL, 1, 1, 2022),
	(1871, 36, 276, 5, NULL, 1, 1, 2022),
	(1872, 37, 275, 5, NULL, 1, 1, 2022),
	(1873, 38, 283, 5, NULL, 1, 1, 2022),
	(1874, 39, 282, 5, NULL, 1, 1, 2022),
	(1875, 40, 288, 5, NULL, 1, 1, 2022),
	(1876, 41, 292, 5, NULL, 1, 1, 2022),
	(1877, 42, 293, 5, NULL, 1, 1, 2022),
	(1878, 73, 332, 5, NULL, 1, 2, 2022),
	(1879, 72, 331, 5, NULL, 1, 2, 2022),
	(1880, 71, 330, 5, NULL, 1, 2, 2022),
	(1881, 70, 329, 5, NULL, 1, 2, 2022),
	(1882, 69, 328, 5, NULL, 1, 2, 2022),
	(1883, 68, 327, 5, NULL, 1, 2, 2022),
	(1884, 67, 326, 5, NULL, 1, 2, 2022),
	(1885, 66, 325, 5, NULL, 1, 2, 2022),
	(1886, 64, 323, 5, NULL, 1, 2, 2022),
	(1887, 44, 319, 5, NULL, 1, 2, 2022),
	(1888, 45, 321, 5, NULL, 1, 2, 2022),
	(1889, 46, 314, 5, NULL, 1, 2, 2022),
	(1890, 47, 315, 5, NULL, 1, 2, 2022),
	(1891, 48, 316, 5, NULL, 1, 2, 2022),
	(1892, 49, 317, 5, NULL, 1, 2, 2022),
	(1893, 50, 304, 5, NULL, 1, 2, 2022),
	(1894, 51, 305, 5, NULL, 1, 2, 2022),
	(1895, 52, 306, 5, NULL, 1, 2, 2022),
	(1896, 65, 324, 5, NULL, 1, 2, 2022),
	(1897, 53, 307, 5, NULL, 1, 2, 2022),
	(1898, 55, 309, 5, NULL, 1, 2, 2022),
	(1899, 56, 310, 5, NULL, 1, 2, 2022),
	(1900, 57, 333, 5, NULL, 1, 2, 2022),
	(1901, 58, 334, 5, NULL, 1, 2, 2022),
	(1902, 59, 335, 5, NULL, 1, 2, 2022),
	(1903, 60, 336, 5, NULL, 1, 2, 2022),
	(1904, 61, 337, 5, NULL, 1, 2, 2022),
	(1905, 62, 339, 5, NULL, 1, 2, 2022),
	(1906, 63, 322, 5, NULL, 1, 2, 2022),
	(1907, 54, 308, 5, NULL, 1, 2, 2022),
	(1908, 43, 318, 5, NULL, 1, 2, 2022),
	(1909, 1, 347, 7, NULL, 1, 1, 2022),
	(1910, 2, 355, 7, NULL, 1, 1, 2022),
	(1911, 3, 354, 7, NULL, 1, 1, 2022),
	(1912, 4, 353, 7, NULL, 1, 1, 2022),
	(1913, 5, 352, 7, NULL, 1, 1, 2022),
	(1914, 6, 351, 7, NULL, 1, 1, 2022),
	(1915, 7, 350, 7, NULL, 1, 1, 2022),
	(1916, 8, 361, 7, NULL, 1, 1, 2022),
	(1917, 9, 360, 7, NULL, 1, 1, 2022),
	(1918, 10, 359, 7, NULL, 1, 1, 2022),
	(1919, 11, 358, 7, NULL, 1, 1, 2022),
	(1920, 12, 493, 7, NULL, 1, 1, 2022),
	(1921, 13, 344, 7, NULL, 1, 1, 2022),
	(1922, 14, 343, 7, NULL, 1, 1, 2022),
	(1923, 15, 342, 7, NULL, 1, 1, 2022),
	(1924, 16, 341, 7, NULL, 1, 1, 2022),
	(1925, 17, 346, 7, NULL, 1, 1, 2022),
	(1926, 18, 345, 7, NULL, 1, 1, 2022),
	(1927, 19, 349, 7, NULL, 1, 1, 2022),
	(1928, 20, 348, 7, NULL, 1, 1, 2022),
	(1929, 21, 356, 7, NULL, 1, 1, 2022),
	(1930, 22, 357, 7, NULL, 1, 1, 2022),
	(1931, 48, 382, 7, NULL, 1, 2, 2022),
	(1932, 47, 381, 7, NULL, 1, 2, 2022),
	(1933, 46, 380, 7, NULL, 1, 2, 2022),
	(1934, 45, 379, 7, NULL, 1, 2, 2022),
	(1935, 23, 373, 7, NULL, 1, 2, 2022),
	(1936, 25, 375, 7, NULL, 1, 2, 2022),
	(1937, 43, 387, 7, NULL, 1, 2, 2022),
	(1938, 42, 386, 7, NULL, 1, 2, 2022),
	(1939, 41, 385, 7, NULL, 1, 2, 2022),
	(1940, 40, 384, 7, NULL, 1, 2, 2022),
	(1941, 39, 383, 7, NULL, 1, 2, 2022),
	(1942, 38, 369, 7, NULL, 1, 2, 2022),
	(1943, 37, 368, 7, NULL, 1, 2, 2022),
	(1944, 36, 367, 7, NULL, 1, 2, 2022),
	(1945, 24, 374, 7, NULL, 1, 2, 2022),
	(1946, 35, 366, 7, NULL, 1, 2, 2022),
	(1947, 33, 364, 7, NULL, 1, 2, 2022),
	(1948, 32, 363, 7, NULL, 1, 2, 2022),
	(1949, 31, 362, 7, NULL, 1, 2, 2022),
	(1950, 30, 372, 7, NULL, 1, 2, 2022),
	(1951, 29, 371, 7, NULL, 1, 2, 2022),
	(1952, 28, 370, 7, NULL, 1, 2, 2022),
	(1953, 27, 377, 7, NULL, 1, 2, 2022),
	(1954, 26, 376, 7, NULL, 1, 2, 2022),
	(1955, 34, 365, 7, NULL, 1, 2, 2022),
	(1956, 44, 378, 7, NULL, 1, 2, 2022),
	(1957, 24, 495, 6, NULL, 1, 1, 2022),
	(1958, 25, 494, 6, NULL, 1, 1, 2022),
	(1959, 26, 498, 6, NULL, 1, 2, 2022),
	(1960, 27, 497, 6, NULL, 1, 2, 2022);
/*!40000 ALTER TABLE `MateriPerKelass` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Materis
CREATE TABLE IF NOT EXISTS `Materis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext CHARACTER SET latin1 DEFAULT NULL,
  `BabId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Materis_BabId` (`BabId`),
  CONSTRAINT `FK_Materis_Babs_BabId` FOREIGN KEY (`BabId`) REFERENCES `Babs` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=499 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table moslemdb.Materis: ~427 rows (approximately)
DELETE FROM `Materis`;
/*!40000 ALTER TABLE `Materis` DISABLE KEYS */;
INSERT INTO `Materis` (`Id`, `No`, `Nama`, `Keterangan`, `BabId`) VALUES
	(1, 1, '(1) الفاتحة', 'paud semester 1', 8),
	(2, 2, 'الناس (2)', 'paud semester 1', 8),
	(3, 3, 'الفلق (3)', 'paud semester 1', 8),
	(4, 4, 'الإخلاص (4)', 'paud semester 1', 8),
	(5, 5, 'المسد (5)', 'paud semester 1', 8),
	(6, 6, 'النصر (6)', 'paud semester 1', 8),
	(7, 7, 'الكافرون (7)', 'paud semester 1', 8),
	(8, 1, '(1)   Doa akan tidur', 'paud semester 1', 3),
	(9, 2, '(2)   Doa bangun tidur', 'paud semester 1', 3),
	(10, 3, '(3)   Doa iftitah', 'paud semester 1', 3),
	(11, 4, '(4)   Bacaan ruku', 'paud semester 1', 3),
	(12, 5, '(5)   I\'tidal', 'paud semester 1', 3),
	(13, 6, '(6)   Bacaan duduk diantara dua sujud', 'paud semester 1', 3),
	(14, 7, '(7)   Bacaan sujud', 'paud semester 1', 3),
	(15, 8, '(8)   Doa sebelum makan', 'paud semester 1', 3),
	(16, 9, '(9)   Doa sesudah makan', 'paud semester 1', 3),
	(17, 10, '(10) Doa untuk kedua orang tua', 'paud semester 1', 3),
	(18, 1, '(1) Asmaul Husna 1-5', 'paud semester 1', 2),
	(19, 2, '(2) Asmaul Husna 6-10', 'paud semester 1', 2),
	(20, 3, '(3) Asmaul Husna 11-15', 'paud semester 1', 2),
	(21, 1, '(1) Bersalaman kepada guru', 'paud semester 1', 1),
	(22, 2, '(2) Makan menggunakan tangan kanan', 'paud semester 1', 1),
	(23, 3, '(3) Izin kalau meninggalkan kelas', 'paud semester 1', 1),
	(24, 1, '(1) Datang ke kelas tepat waktu', 'paud semester 1', 4),
	(25, 2, '(2) Mandi sebelum berangkat', 'paud semester 1', 4),
	(26, 3, '(3) Merapikan kembali peralatan tulis', 'paud semester 1', 4),
	(27, 4, '(4) Menjaga kebersihan kelas', 'paud semester 1', 4),
	(28, 5, '(5) Berbuat baik dan menyayangi teman', 'paud semester 1', 4),
	(29, 1, '(1) Cerita tentang bersyukur', 'paud semester 1', 7),
	(30, 2, '(2) Mewarnai Asmaul Husna', 'paud semester 1', 7),
	(31, 3, '(3) Mewarnai huruf hijaiyah', 'paud semester 1', 7),
	(32, 4, '(4) Melagukan huruf hijaiyah', 'paud semester 1', 7),
	(33, 5, '(5) Praktek wudlu', 'paud semester 1', 7),
	(34, 6, '(6) Gerakan sholat', 'paud semester 1', 7),
	(35, 7, '(7) Menulis huruf hijaiyah', 'paud semester 1', 7),
	(36, 8, '(8) Kisah Nabi Idris', 'paud semester 1', 7),
	(37, 1, 'Tilawati 1', 'paud semester 1', 11),
	(38, 1, 'الكوثر (1)', 'paud semester 2', 8),
	(39, 2, 'الماعون (2)', 'paud semester 2', 8),
	(40, 3, 'قريش (3)', 'paud semester 2', 8),
	(41, 4, 'الفيل (4)', 'paud semester 2', 8),
	(42, 5, 'الهمزة (5)', 'paud semester 2', 8),
	(43, 6, 'العصر (6)', 'paud semester 2', 8),
	(44, 1, '(1) Doa kebaikan dunia akhirat', 'paud semester 2', 3),
	(45, 2, '(2) Doa mencari ilmu 1', 'paud semester 2', 3),
	(46, 3, '(3) Doa minum susu', 'paud semester 2', 3),
	(47, 4, '(4) Doa Nabi Musa', 'paud semester 2', 3),
	(48, 5, '(5) Doa masuk toilet ', 'paud semester 2', 3),
	(49, 6, '(6) Doa keluar toilet', 'paud semester 2', 3),
	(50, 7, '(7) Doa minta masuk surga firdaus', 'paud semester 2', 3),
	(51, 1, '(1) Asmaul Husna 16-20', 'paud semester 2', 2),
	(52, 2, '(2) Asmaul Husna 21-25', 'paud semester 2', 2),
	(53, 3, '(3) Asmaul Husna 26-30', 'paud semester 2', 2),
	(54, 1, '(1) Tata cara mengucapkan salam', 'paud semester 2', 1),
	(55, 2, '(2) Tata cara mengucapkan syukur', 'paud semester 2', 1),
	(56, 3, '(3) Tata cara menguap dan bersin', 'paud semester 2', 1),
	(57, 4, '(4) Tata cara minum', 'paud semester 2', 1),
	(58, 1, '(1) Mandi sebelum berangkat ngaji', 'paud semester 2', 4),
	(59, 2, '(2) Memakai pakaian rapi dan bersih', 'paud semester 2', 4),
	(60, 3, '(3) Murid perempuan menggunakan kerudung', 'paud semester 2', 4),
	(61, 4, '(4) Merapikan kembali benda-benda miliknya', 'paud semester 2', 4),
	(62, 5, '(5) Datang tepat waktu', 'paud semester 2', 4),
	(63, 1, '(1) Kisah Nabi Hud', 'paud semester 2', 7),
	(64, 2, '(2) Kisah Nabi Sholih', 'paud semester 2', 7),
	(65, 3, '(3) Kisah Nabi Nuh', 'paud semester 2', 7),
	(66, 4, '(4) Mewarnai Asmaul Husna', 'paud semester 2', 7),
	(67, 5, '(5) Mewarnai gambar', 'paud semester 2', 7),
	(68, 6, '(6) Melagukan huruf hijaiyah', 'paud semester 2', 7),
	(69, 7, '(7) Lafadz syukur', 'paud semester 2', 7),
	(70, 8, '(8) Menonton Kisah Teladan', 'paud semester 2', 7),
	(71, 1, 'التكاثر (1)', 'kelas A semester 1', 8),
	(72, 2, 'القارعة (2)', 'kelas A semester 1', 8),
	(73, 3, 'العاديات (3)', 'kelas A semester 1', 8),
	(74, 4, 'الزلزلة (4)', 'kelas A semester 1', 8),
	(75, 5, 'البينة (5)', 'kelas A semester 1', 8),
	(76, 6, 'القدر (6)', 'kelas A semester 1', 8),
	(77, 1, '(1) Doa sebelum berwudlu', 'kelas A semester 1', 3),
	(78, 2, '(2) Doa setelah berwudlu', 'kelas A semester 1', 3),
	(79, 3, '(3) Bacaan tasyahud/tahiyat', 'kelas A semester 1', 3),
	(80, 4, '(4) Bacaan sholawat', 'kelas A semester 1', 3),
	(81, 5, '(5) Doa mencari ilmu II', 'kelas A semester 1', 3),
	(82, 6, '(6) Doa minta ilham yang baik', 'kelas A semester 1', 3),
	(83, 7, '(7) Doa pagi sore', 'kelas A semester 1', 3),
	(84, 8, '(8) Doa ketika lupa membaca doa makan', 'kelas A semester 1', 3),
	(85, 9, '(9) Doa raja istigfar', 'kelas A semester 1', 3),
	(86, 1, '(1) Asmaul Husna 31-35', 'kelas A semester 1', 2),
	(87, 2, '(2) Asmaul Husna 36-40', 'kelas A semester 1', 2),
	(88, 3, '(3) Asmaul Husna 41-45', 'kelas A semester 1', 2),
	(89, 1, '(1) Tata Krama Berpakaian dan Berhias', 'kelas A semester 1', 1),
	(90, 2, '(2) Tata Krama Ketika Makan', 'kelas A semester 1', 1),
	(91, 3, '(3) Tata Krama Ketika Minum', 'kelas A semester 1', 1),
	(92, 1, '(1) Mandi sebelum berangkat ngaji', 'kelas A semester 1', 4),
	(93, 2, '(2) Memakai pakaian rapi dan bersih', 'kelas A semester 1', 4),
	(94, 3, '(3) Murid perempuan menggunakan kerudung', 'kelas A semester 1', 4),
	(95, 1, 'Praktek wudlu', 'kelas A semester 1', 7),
	(96, 2, 'Praktek sholat', 'kelas A semester 1', 7),
	(97, 3, 'Pemahaman tentang Najis dan Sholat', 'kelas A semester 1', 7),
	(98, 4, 'Ta’dhim terhadap syairulloh', 'kelas A semester 1', 7),
	(99, 5, 'Pegon lepas (kata)', 'kelas A semester 1', 7),
	(100, 1, 'Tilawati 2', 'kelas A semester 1', 11),
	(101, 1, 'العلق (1)', 'kelas A semester 2', 8),
	(102, 2, 'التين (2)', 'kelas A semester 2', 8),
	(103, 3, 'الشرح (3)', 'kelas A semester 2', 8),
	(104, 4, 'الضحى (4)', 'kelas A semester 2', 8),
	(105, 5, 'الليل (5)', 'kelas A semester 2', 8),
	(106, 6, 'الشمس (6)', 'kelas A semester 2', 8),
	(107, 1, '(1) Doa ketika tertimpa musibah', 'kelas A semester 2', 3),
	(108, 2, '(2) Doa mendengar suara petir', 'kelas A semester 2', 3),
	(109, 3, '(3) Doa ketetapan iman', 'kelas A semester 2', 3),
	(110, 4, '(4) Doa masuk rumah', 'kelas A semester 2', 3),
	(111, 5, '(5) Doa keluar rumah', 'kelas A semester 2', 3),
	(112, 6, '(6) Doa berbuka puasa', 'kelas A semester 2', 3),
	(113, 7, '(7) Ucapan syukur', 'kelas A semester 2', 3),
	(114, 8, '(8) Doa lailatul qodar', 'kelas A semester 2', 3),
	(115, 1, '(1) Asmaul Husna 46-50', 'kelas A semester 2', 2),
	(116, 2, '(2) Asmaul Husna 51-55', 'kelas A semester 2', 2),
	(117, 3, '(3) Asmaul Husna 56-60', 'kelas A semester 2', 2),
	(118, 1, '(1) Tata Krama Bertamu', 'kelas A semester 2', 1),
	(119, 2, '(2) Tata Krama Menerima Tamu', 'kelas A semester 2', 1),
	(120, 1, '(1) Mandi sebelum berangkat ngaji', 'kelas A semester 2', 4),
	(121, 2, '(2) Datang Tepat Waktu', 'kelas A semester 2', 4),
	(122, 3, '(3) Memperhatikan pelajaran yang disampaikan', 'kelas A semester 2', 4),
	(123, 4, '(4) Membuang sampah pada tempat sampah', 'kelas A semester 2', 4),
	(124, 5, '(5) Tidak Mencorat-coret bangku', 'kelas A semester 2', 4),
	(125, 1, 'Pegon sambung (kata)', 'kelas A semester 2', 7),
	(126, 2, 'Menulis sambung', 'kelas A semester 2', 7),
	(127, 1, 'Tilawati 3', 'kelas A semester 2', 11),
	(128, 1, 'البلد (1)', 'kelas B semester 1', 8),
	(129, 2, 'الفجر (2)', 'kelas B semester 1', 8),
	(130, 3, 'الغاشية (3)', 'kelas B semester 1', 8),
	(131, 4, 'الأعلى (4)', 'kelas B semester 1', 8),
	(132, 5, 'الطارق (5)', 'kelas B semester 1', 8),
	(133, 1, '(1) Doa ketika ada angin kencang', 'kelas B semester 1', 3),
	(134, 2, '(2) Doa setelah adzan', 'kelas B semester 1', 3),
	(135, 3, '(3) Doa masuk masjid', 'kelas B semester 1', 3),
	(136, 4, '(4) Doa keluar masjid', 'kelas B semester 1', 3),
	(137, 5, '(5) Doa melihat orang dicoba', 'kelas B semester 1', 3),
	(138, 6, '(6) Dzikir sesudah sholat', 'kelas B semester 1', 3),
	(139, 7, '(7) Doa turun hujan', 'kelas B semester 1', 3),
	(140, 8, '(8) Doa kesabaran', 'kelas B semester 1', 3),
	(141, 9, '(9) Doa berpakaian', 'kelas B semester 1', 3),
	(142, 1, '(1) Asmaul Husna 61-65', 'kelas B semester 1', 2),
	(143, 2, '(2) Asmaul Husna 66-70', 'kelas B semester 1', 2),
	(144, 3, '(3) Asmaul Husna 71-75', 'kelas B semester 1', 2),
	(145, 1, '(1) Tata Krama Berbicara dengan Orang Lain', 'kelas B semester 1', 1),
	(146, 2, '(2) Tata krama berbicara di telphone', 'kelas B semester 1', 1),
	(147, 3, '(3) Etika bergaul dan bermain', 'kelas B semester 1', 1),
	(148, 4, '(4) Tata Krama Tidur', 'kelas B semester 1', 1),
	(149, 1, 'Tilawati 4', 'kelas B semester 1', 11),
	(150, 1, 'البروج (1)', 'kelas B semester 2', 8),
	(151, 2, 'الإنشقاق (2)', 'kelas B semester 2', 8),
	(152, 3, 'المطففين (3)', 'kelas B semester 2', 8),
	(153, 4, 'الإنفطار (4)', 'kelas B semester 2', 8),
	(154, 1, '(1) Doa maskumambang', 'kelas B semester 2', 3),
	(155, 2, '(2) Doa berbuka puasa', 'kelas B semester 2', 3),
	(156, 3, '(3) Doa minum air zam-zam', 'kelas B semester 2', 3),
	(157, 4, '(4) Doa naik kendaraan', 'kelas B semester 2', 3),
	(158, 5, '(5) Ismul a’dzom', 'kelas B semester 2', 3),
	(159, 6, '(6) Doa minta masuk surga firdaus', 'kelas B semester 2', 3),
	(160, 7, '(7) Doa  minta naik haji', 'kelas B semester 2', 3),
	(161, 8, '(8) Doa sujud Alqurâ€™an', 'kelas B semester 2', 3),
	(162, 9, '(9) Doa menjenguk orang sakit', 'kelas B semester 2', 3),
	(163, 10, '(10) Doa masuk pasar', 'kelas B semester 2', 3),
	(164, 1, '(1) Asmaul Husna 76-80', 'kelas B semester 2', 2),
	(165, 2, '(2) Asmaul Husna 81-85', 'kelas B semester 2', 2),
	(166, 3, '(3) Asmaul Husna 86-99', 'kelas B semester 2', 2),
	(167, 1, '(1) Tata Krama Berjalan', 'kelas B semester 2', 1),
	(168, 2, '(2) Adab ketika berada di masjid', 'kelas B semester 2', 1),
	(169, 3, '(3) Tata Krama terhadap orangtua', 'kelas B semester 2', 1),
	(170, 1, '(1) Hukum Membaca Ta\'awud dan Basmalah', 'kelas B semester 2', 10),
	(171, 2, '(2) Hukum Nun Mati dan Tanwin', 'kelas B semester 2', 10),
	(172, 3, '(3) Hukum Mim Mati', 'kelas B semester 2', 10),
	(173, 1, 'Menulis dan Memberi makna do’a-do’a materi usia 5 dan 6 tahun', 'kelas B semester 2', 7),
	(174, 1, 'Tilawati 5', 'kelas B semester 2', 11),
	(175, 1, 'التكوير (1)', 'kelas C semester 1', 8),
	(176, 2, 'عبس (2)', 'kelas C semester 1', 8),
	(177, 3, 'النازعات (3)', 'kelas C semester 1', 8),
	(178, 4, 'النبأ (4)', 'kelas C semester 1', 8),
	(179, 1, '(1) Doa melihat tanggal', 'kelas C semester 1', 3),
	(180, 2, '(2) Kumpulan doa Nabi Muhammad SAW', 'kelas C semester 1', 3),
	(181, 3, '(3) Doa perlindungan dari setan, jin dan tukang sihir', 'kelas C semester 1', 3),
	(182, 4, '(4) Doa perlindungan dari sifat penakut dan malas', 'kelas C semester 1', 3),
	(183, 5, '(5) Do’a supaya bisa mensyukuri nikmat Alloh', 'kelas C semester 1', 3),
	(184, 6, '(6) PR 13', 'kelas C semester 1', 3),
	(185, 7, '(7) Doa perlindungan dari jeleknya anggota badan', 'kelas C semester 1', 3),
	(186, 1, '(1)  An-Nas', 'kelas C semester 1', 6),
	(187, 2, '(2)  Al-Falaq', 'kelas C semester 1', 6),
	(188, 3, '(3)  Al-Ikhlas', 'kelas C semester 1', 6),
	(189, 4, '(4)  Al-Masad', 'kelas C semester 1', 6),
	(190, 5, '(5)  An-Nasr', 'kelas C semester 1', 6),
	(191, 6, '(6)  Al-Kafirun', 'kelas C semester 1', 6),
	(192, 7, '(7)  Al-Kautsar', 'kelas C semester 1', 6),
	(193, 8, '(8)  Al-Ma\'un', 'kelas C semester 1', 6),
	(194, 9, '(9)  Quraisy', 'kelas C semester 1', 6),
	(195, 10, '(10) Al-Fiil', 'kelas C semester 1', 6),
	(196, 11, '(11) Al-Humazah', 'kelas C semester 1', 6),
	(197, 12, '(12) Al-\'Asr', 'kelas C semester 1', 6),
	(198, 1, 'Kitabussolah', 'kelas C semester 1', 5),
	(199, 1, 'Tayammum', 'kelas C semester 1', 7),
	(200, 2, 'Cara mensucikan Najis', 'kelas C semester 1', 7),
	(201, 3, 'Pegon Biasa (kalimat)', 'kelas C semester 1', 7),
	(202, 4, 'Pegon Baku (kata)', 'kelas C semester 1', 7),
	(203, 5, 'Dalil 5 bab', 'kelas C semester 1', 7),
	(204, 6, 'Tata krama taâ€™ziah', 'kelas C semester 1', 7),
	(205, 7, 'Tata krama berkendara', 'kelas C semester 1', 7),
	(206, 8, 'Review materi akhlaq', 'kelas C semester 1', 7),
	(207, 1, 'Tilawati 6', 'kelas C semester 1', 11),
	(208, 1, 'Juz 29', 'kelas C semester 1', 9),
	(209, 1, 'البقرة : ٢٥٥־٢٥٧ (1)', 'kelas C semester 2', 8),
	(210, 2, 'الكهف : ١־١٠ (2)', 'kelas C semester 2', 8),
	(211, 3, 'الصف : ١٠־١٤ (3)', 'kelas C semester 2', 8),
	(212, 4, 'الحشر : ٢٢־٢٤ (4)', 'kelas C semester 2', 8),
	(213, 5, '(5) البقرة : ۱۔ ۵', 'kelas C semester 2', 8),
	(214, 6, 'البقرة : ٢٨٤־٢٨٦ (6)', 'kelas C semester 2', 8),
	(215, 1, '(1) Doa pengayoman', 'kelas C semester 2', 3),
	(216, 2, '(2) Doa minta agar mati syahid', 'kelas C semester 2', 3),
	(217, 3, '(3) Doa berlindung dari amal jelek', 'kelas C semester 2', 3),
	(218, 4, '(4) Doa Nabi Yunus', 'kelas C semester 2', 3),
	(219, 5, '(5) Doa pengampunan', 'kelas C semester 2', 3),
	(220, 6, '(6) Doa setelah membaca Alqurâ€™an', 'kelas C semester 2', 3),
	(221, 1, '(1) Q.S At-Takatsur', 'kelas C semester 2', 6),
	(222, 2, '(2) Q.S Al-Qori\'ah', 'kelas C semester 2', 6),
	(223, 3, '(4) Q.S Al-Adiyat', 'kelas C semester 2', 6),
	(224, 4, '(5) Q.S Al-Zalzalah', 'kelas C semester 2', 6),
	(225, 5, '(6) Q.S Al-Bayyinah', 'kelas C semester 2', 6),
	(226, 6, '(7) Q.S Al-Qodr', 'kelas C semester 2', 6),
	(227, 7, '(8) Q.S Al-Alaq', 'kelas C semester 2', 6),
	(228, 8, '(9) Q.S At-Tiin', 'kelas C semester 2', 6),
	(229, 9, '(10) Q.S As-Syirh', 'kelas C semester 2', 6),
	(230, 10, '(11) Q.S Ad-Dluha', 'kelas C semester 2', 6),
	(231, 1, 'Kitab Sholat', 'kelas C semester 2', 5),
	(232, 1, '(1) Makhrojul huruf', 'kelas C semester 2', 10),
	(233, 2, '(2) Hukum Ta’awudz dan Basmallah', 'kelas C semester 2', 10),
	(234, 3, '(3) Hukum nun mati dan tanwin + Gunnah', 'kelas C semester 2', 10),
	(235, 4, '(4) Hukum Mad Thobi\'i', 'kelas C semester 2', 10),
	(236, 5, '(5) Hukum idzgom', 'kelas C semester 2', 10),
	(237, 6, '(6) Hukum Qolqolah', 'kelas C semester 2', 10),
	(238, 7, '(7) Hukum alif lam syamsiyah dan qomariyah', 'kelas C semester 2', 10),
	(239, 1, '(1) Juz 30 (الليل)', 'kelas C semester 2', 7),
	(240, 2, '(2) Juz 30 (الشمس)', 'kelas C semester 2', 7),
	(241, 3, '(3) Juz 30 (البلد)', 'kelas C semester 2', 7),
	(242, 4, '(4) Juz 30 (الفجر)', 'kelas C semester 2', 7),
	(243, 5, '(5) Juz 30 (الغاشية)', 'kelas C semester 2', 7),
	(244, 6, '(6) Juz 30 (الأعلى)', 'kelas C semester 2', 7),
	(245, 7, '(7) Juz 30 (الطارق)', 'kelas C semester 2', 7),
	(246, 8, '(8) Juz 30 (البروج)', 'kelas C semester 2', 7),
	(247, 9, '(9) Juz 30 (الإنشقاق)', 'kelas C semester 2', 7),
	(248, 10, '(10) Juz 30 (المطففين)', 'kelas C semester 2', 7),
	(249, 11, '(11) Juz 30 (الإنفطار)', 'kelas C semester 2', 7),
	(250, 12, '(12) Juz 30 (التكوير)', 'kelas C semester 2', 7),
	(251, 13, '(13) Juz 30 (عبس)', 'kelas C semester 2', 7),
	(252, 14, '(14) Juz 30 (النازعات)', 'kelas C semester 2', 7),
	(253, 15, '(15) Juz 30 (النباء)', 'kelas C semester 2', 7),
	(254, 1, 'Q.S Albaqarah', 'kelas C semester 2', 9),
	(255, 1, 'Tata Krama Berpakaian dan Berhias', 'Caberawit', 12),
	(256, 2, 'Tata Krama Ketika Makan', 'Caberawit', 12),
	(257, 3, 'Tata Krama Ketika Minum', 'Caberawit', 12),
	(258, 4, 'Tata Krama Bertamu', 'Caberawit', 12),
	(259, 5, 'Tata Krama Menerima Tamu', 'Caberawit', 12),
	(260, 6, 'Tata Krama Berbicara dengan Orang Lain (Berbincang-bincang)', 'Caberawit', 12),
	(261, 7, 'Tata Krama Tidur', 'kelas PAUD dan A semester 2', 12),
	(262, 8, 'Tata Krama Berjalan', 'Caberawit', 12),
	(263, 9, 'Tata Krama Mengendarai Sepeda / Motor / Mobil', 'Caberawit', 12),
	(264, 10, 'Tata Krama Terhadap Kedua Orang Tua', 'Caberawit', 12),
	(265, 11, 'Tata Krama Terhadap Orang yang Lebih Tua / Yang Dituakan', 'Caberawit', 12),
	(266, 12, 'Tata Krama Bertelphone', 'Caberawit', 12),
	(267, 13, 'Tata Krama dalam Pergaulan', 'Caberawit', 12),
	(268, 14, 'Tata Krama Ta\'ziah', 'Caberawit', 12),
	(269, 15, 'Hal-hal yang tidak pantas dilakukan dihadapan orang lain', 'Caberawit', 12),
	(270, 16, 'Memelihara Kebersihan Diri', 'Caberawit', 12),
	(271, 1, 'JUZ 29', 'praremaja semester 1', 6),
	(272, 2, 'JUZ 28', 'praremaja semester 1', 6),
	(273, 3, 'JUZ 27', 'praremaja semester 1', 6),
	(274, 4, 'JUZ 26', 'praremaja semester 1', 6),
	(275, 5, 'JUZ 25', 'praremaja semester 1', 6),
	(276, 6, 'JUZ 24', 'praremaja semester 1', 6),
	(277, 7, 'JUZ 23', 'praremaja semester 1', 6),
	(278, 8, 'JUZ 22', 'praremaja semester 1', 6),
	(279, 9, 'JUZ 21', 'praremaja semester 1', 6),
	(280, 10, 'Al Baqoroh 284 – 286', 'praremaja semester 1', 6),
	(281, 11, 'Al Mu’minun 1 – 11', 'praremaja semester 1', 6),
	(282, 1, '(1) Kitabul Adab', 'praremaja semester 1', 5),
	(283, 2, '(2) Kitab Hukum', 'praremaja semester 1', 5),
	(284, 3, '(3) Kitab Doa', 'praremaja semester 1', 5),
	(285, 4, '(4) Kitab Jenazah', 'praremaja semester 1', 5),
	(286, 1, '(1) Doa Sholat Jenazah', 'praremaja semester 1', 3),
	(287, 2, '(2) Doa Setelah Membaca Alqur\'an', 'praremaja semester 1', 3),
	(288, 3, '(3) Doa 1/3 Malam ', 'praremaja semester 1', 3),
	(289, 1, '(1) الملك', 'praremaja semester 1', 13),
	(290, 2, 'التكوير (2)', 'praremaja semester 1', 13),
	(291, 3, 'عبس (3)', 'praremaja semester 1', 13),
	(292, 4, 'النازعات (4)', 'praremaja semester 1', 13),
	(293, 5, 'النبأ (5)', 'praremaja semester 1', 13),
	(294, 1, '(1) Dalil Keimanan (Bersyukur)', 'praremaja semester 1', 14),
	(295, 2, '(2) Dalil Keimanan (Mempersungguh)', 'praremaja semester 1', 14),
	(296, 3, '(3) Dalil Keimanan (Mengagungkan + Berdoa)', 'praremaja semester 1', 14),
	(297, 1, '(1) Taharah (Wudlu, Tayamum, Mandi Jinabah)', 'praremaja semester 1', 7),
	(298, 2, '(2) Mensucikan pakaian dan tempat', 'praremaja semester 1', 7),
	(299, 3, '(3) Penjelasan Mahram', 'praremaja semester 1', 7),
	(300, 4, '(4) Keutamaan berdoa', 'praremaja semester 1', 7),
	(301, 1, '(1) Hukum Mad', 'praremaja semester 1', 10),
	(302, 2, '(2) Hukum Ro’', 'praremaja semester 1', 10),
	(303, 3, '(3) Tanda Waqof', 'praremaja semester 1', 10),
	(304, 1, 'JUZ 16', 'praremaja semester 2', 6),
	(305, 2, 'JUZ 17', 'praremaja semester 2', 6),
	(306, 3, 'JUZ 18', 'praremaja semester 2', 6),
	(307, 4, 'JUZ 19', 'praremaja semester 2', 6),
	(308, 5, 'JUZ 20', 'praremaja semester 2', 6),
	(309, 6, 'As Shof 10 - 13', 'praremaja semester 2', 6),
	(310, 7, 'Al Kahfi 1 – 10', 'praremaja semester 2', 6),
	(311, 8, 'Al Mu’minun 115 - 118', 'praremaja semester 2', 6),
	(312, 1, '(1) Kitab Nawafil', 'praremaja semester 2', 5),
	(313, 2, '(2) Kitab Surga dan Neraka', 'praremaja semester 2', 5),
	(314, 3, '(3) Kitab Hukum', 'praremaja semester 2', 5),
	(315, 4, '(4) Kitab Jihad', 'praremaja semester 2', 5),
	(316, 5, '(5) Kitab Manasik Haji', 'praremaja semester 2', 5),
	(317, 6, '(6) Tata Krama', 'praremaja semester 2', 5),
	(318, 1, '(1) Doa Terhindar dari lingkungan jelek', 'praremaja semester 2', 3),
	(319, 2, '(2) Doa Naik kendaraan', 'praremaja semester 2', 3),
	(320, 3, '(3) Doa Bela Diri', 'praremaja semester 2', 3),
	(321, 4, '(4) Doa perlindungan malas', 'praremaja semester 2', 3),
	(322, 1, 'البقرة : ٢٥٥־٢٥٧ (1)', 'praremaja semester 2', 13),
	(323, 2, 'الكهف : ١־١٠ (2)', 'praremaja semester 2', 13),
	(324, 3, 'الصف : ١٠־١٤ (3)', 'praremaja semester 2', 13),
	(325, 4, 'الحشر : ٢٢־٢٤ (4)', 'praremaja semester 2', 13),
	(326, 5, 'البقرة : ٢٨٤־٢٨٦ (5)', 'praremaja semester 2', 13),
	(327, 6, '(6)  حم السجدة', 'praremaja semester 2', 13),
	(328, 1, '(1) Dalil Mengaji', 'praremaja semester 2', 14),
	(329, 2, '(2) Dalil Beramal', 'praremaja semester 2', 14),
	(330, 3, '(3) Dalil JIhad', 'praremaja semester 2', 14),
	(331, 4, '(4) Dalil Bernegara', 'praremaja semester 2', 14),
	(332, 5, '(5) Dalil Taat Pemimpin', 'praremaja semester 2', 14),
	(333, 1, '(1) Praktek sholat', 'praremaja semester 2', 7),
	(334, 2, '(2) Keutamaan Membaca Alqur\'an', 'praremaja semester 2', 7),
	(335, 3, '(3) Pembacaan Perintah Agama', 'praremaja semester 2', 7),
	(336, 4, '(4) Pembacaan Larangan Agama', 'praremaja semester 2', 7),
	(337, 5, '(5) Warga Negara ', 'praremaja semester 2', 7),
	(338, 6, '(6) Bela Diri', 'praremaja semester 2', 7),
	(339, 7, '(7) Latihan Khutbah sesuai Al Qur’an_Hadits', 'praremaja semester 2', 7),
	(341, 2, 'JUZ 12', 'remaja semester 1', 6),
	(342, 3, 'JUZ 13', 'remaja semester 1', 6),
	(343, 4, 'JUZ 14', 'remaja semester 1', 6),
	(344, 5, 'JUZ 15', 'remaja semester 1', 6),
	(345, 1, '(1) Kitab Hukum', 'remaja semester 1', 5),
	(346, 2, '(2) Kitab Manasik Haji Umroh', 'remaja semester 1', 5),
	(347, 1, '(1) Do’a Sholat Tasbih', 'remaja semester 1', 3),
	(348, 2, '(2) Do’a Sholat Hajat', 'remaja semester 1', 3),
	(349, 3, '(3) Do’a Sholat Istikhoroh', 'remaja semester 1', 3),
	(350, 1, '(1) الصف', 'remaja semester 1', 13),
	(351, 2, 'التكوير (2)', 'remaja semester 1', 13),
	(352, 3, 'عبس (3)', 'remaja semester 1', 13),
	(353, 4, 'النازعات (4)', 'remaja semester 1', 13),
	(354, 5, 'النبأ (5)', 'remaja semester 1', 13),
	(355, 1, '(1) Dalil Berbudi Baik', 'remaja semester 1', 14),
	(356, 2, '(2) Dalil Berbudi Baik', 'remaja semester 1', 14),
	(357, 3, '(3) Dalil Berbudi Baik', 'remaja semester 1', 14),
	(358, 1, '(1) Taharah (Wudlu, Tayamum, Mandi Jinabah)', 'remaja semester 1', 7),
	(359, 2, '(2) Mensucikan pakaian dan tempat', 'remaja semester 1', 7),
	(360, 3, '(3) Penjelasan Mahram', 'remaja semester 1', 7),
	(361, 4, '(4) Keutamaan berdoa', 'remaja semester 1', 7),
	(362, 1, 'JUZ 3', 'remaja semester 2', 6),
	(363, 2, 'JUZ 4', 'remaja semester 2', 6),
	(364, 3, 'JUZ 5', 'remaja semester 2', 6),
	(365, 4, 'JUZ 6', 'remaja semester 2', 6),
	(366, 5, 'JUZ 7', 'remaja semester 2', 6),
	(367, 6, 'JUZ 8', 'remaja semester 2', 6),
	(368, 7, 'JUZ 9', 'remaja semester 2', 6),
	(369, 8, 'JUZ 10', 'remaja semester 2', 6),
	(370, 1, '(1) Kitabus Shaum', 'remaja semester 2', 5),
	(371, 2, '(2) Kitabul Khotbah', 'remaja semester 2', 5),
	(372, 3, '(3) Kitabul Haji', 'remaja semester 2', 5),
	(373, 1, '(1) Do’a minta mati syahid', 'remaja semester 2', 3),
	(374, 2, '(2) Do’a berlindung dari syirik', 'remaja semester 2', 3),
	(375, 3, '(3) Do’a berlindung dari siksa kubur', 'remaja semester 2', 3),
	(376, 4, '(4) Do’a agar bisa naik haji', 'remaja semester 2', 3),
	(377, 5, '(5) Do’a minum air zam – zam', 'remaja semester 2', 3),
	(378, 1, '(1) Surat Yasin', 'remaja semester 2', 13),
	(379, 2, '(2) Surat Addukhon', 'remaja semester 2', 13),
	(380, 1, '(1) Dalil Mencari Ilmu', 'remaja semester 2', 14),
	(381, 2, '(2) Dalil Memahami Agama', 'remaja semester 2', 14),
	(382, 3, '(3) Dalil Kemandirian', 'remaja semester 2', 14),
	(383, 1, '(1) Praktek sholat', 'remaja semester 2', 7),
	(384, 2, '(2) Keutamaan Membaca Alqur\'an', 'remaja semester 2', 7),
	(385, 3, '(3) Pembacaan Perintah Agama', 'remaja semester 2', 7),
	(386, 4, '(4) Pembacaan Larangan Agama', 'remaja semester 2', 7),
	(387, 5, '(5) BUKU Tata Krama', 'remaja semester 2', 7),
	(388, 1, 'Tata Krama Berpakaian dan Berhias', 'praremaja dan remaja', 12),
	(389, 2, 'Tata Krama Ketika Makan', 'praremaja dan remaja', 12),
	(390, 3, 'Tata Krama Ketika Minum', 'praremaja dan remaja', 12),
	(391, 4, 'Tata Krama Bertamu', 'praremaja dan remaja', 12),
	(392, 5, 'Tata Krama Menerima Tamu', 'praremaja dan remaja', 12),
	(393, 6, 'Tata Krama Berbicara dengan Orang Lain (Berbincang-bincang)', 'praremaja dan remaja', 12),
	(394, 7, 'Tata Krama Tidur', 'praremaja dan remaja', 12),
	(395, 8, 'Tata Krama Berjalan', 'praremaja dan remaja', 12),
	(396, 9, 'Tata Krama Mengendarai Sepeda / Motor / Mobil', 'praremaja dan remaja', 12),
	(397, 10, 'Tata Krama Terhadap Kedua Orang Tua', 'praremaja dan remaja', 12),
	(398, 11, 'Tata Krama Terhadap Orang yang Lebih Tua / Yang Dituakan', 'praremaja dan remaja', 12),
	(399, 12, 'Tata Krama Bertelphone', 'praremaja dan remaja', 12),
	(400, 13, 'Tata Krama dalam Pergaulan', 'praremaja dan remaja', 12),
	(401, 14, 'Tata Krama Ta\'ziah', 'praremaja dan remaja', 12),
	(402, 15, 'Hal-hal yang tidak pantas dilakukan dihadapan orang lain', 'praremaja dan remaja', 12),
	(403, 16, 'Memelihara Kebersihan Diri', 'praremaja dan remaja', 12),
	(404, 1, '1. Melanjutkan Materi Tadarus', 'muda mudi semester 1', 9),
	(405, 1, '1. Al-Maidah Ayat 37 - Al-An\'am 27 (kelompok)', 'muda mudi semester 1', 6),
	(406, 2, '2. An-Nisa 148 - Al-Maidah 5 (desa)', 'muda mudi semester 1', 6),
	(407, 1, '1. Khotbah (13-76) ', 'muda mudi semester 1', 5),
	(408, 2, '2. Khotbah (1-12) ', 'muda mudi semester 1', 5),
	(409, 1, '1. Review materi saat tadarus', 'muda mudi semester 1', 10),
	(410, 1, '1. Dalil Menjadi Alim Fakih', 'muda mudi semester 1', 14),
	(411, 2, '2. Dalil Memiliki Akhlakul Karimah', 'muda mudi semester 1', 14),
	(412, 1, '1. Buku Tata Krama', 'muda mudi semester 1', 12),
	(413, 1, '1. Bela diri', 'muda mudi semester 1', 7),
	(414, 2, '2. Kemandirian', 'muda mudi semester 1', 7),
	(415, 3, '3. Olahraga', 'muda mudi semester 1', 7),
	(416, 4, '4. Beramal Sholeh', 'muda mudi semester 1', 7),
	(417, 5, '5. Metode Dakwah', 'muda mudi semester 1', 7),
	(418, 3, '3. Al-Baqoroh 89 - Al-Baqoroh 126 ', 'muda mudi semester 1', 6),
	(419, 4, '4. Al-Fatihah 1 - Al-Baqoroh 24 ', 'muda mudi semester 1', 6),
	(420, 3, '3. Perdamaian dalam bernegara', 'muda mudi semester 1', 5),
	(491, 1, 'Kitab Pernikahan', 'Kitab tentang pernikahan..', 5),
	(492, 1, 'BCM', 'Kelas A', 7),
	(493, 1, 'JUZ 11', 'Remaja Semester 1', 6),
	(494, 1, 'JUZ 1', 'remaja cimanggu semester 1', 6),
	(495, 1, 'Kitab Aturan Bernegara', 'muda mudi cimanggu semester 1', 5),
	(496, 1, 'Buku Tata Krama', 'muda mudi cimanggu semester 1', 7),
	(497, 2, 'JUZ 2', 'muda mudi cimanggu semester 2', 6),
	(498, 1, 'Muktarut Da\'wat', 'muda mudi cimanggu semester 2', 5);
/*!40000 ALTER TABLE `Materis` ENABLE KEYS */;

-- Dumping structure for table moslemdb.MosqueAlarms
CREATE TABLE IF NOT EXISTS `MosqueAlarms` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Judul` longtext NOT NULL,
  `AlarmId` longtext NOT NULL,
  `Waktu` time(6) NOT NULL,
  `AktifDari` datetime(6) NOT NULL,
  `AktifSampai` datetime(6) NOT NULL,
  `Berulang` tinyint(1) NOT NULL,
  `Hari` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.MosqueAlarms: ~2 rows (approximately)
DELETE FROM `MosqueAlarms`;
/*!40000 ALTER TABLE `MosqueAlarms` DISABLE KEYS */;
INSERT INTO `MosqueAlarms` (`Id`, `Judul`, `AlarmId`, `Waktu`, `AktifDari`, `AktifSampai`, `Berulang`, `Hari`) VALUES
	(1, 'Alarm Sahur', 'alarm1', '03:00:00.000000', '2022-04-18 11:24:33.227709', '2022-05-02 23:59:59.000000', 1, '0;1;2;3;4;5;6'),
	(2, 'Alarm Doa Malam', 'alarm1', '02:30:00.000000', '2022-04-18 12:24:30.638878', '2022-05-02 00:00:00.000000', 1, '0;1;2;3;4;5;6');
/*!40000 ALTER TABLE `MosqueAlarms` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Mustahiks
CREATE TABLE IF NOT EXISTS `Mustahiks` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  `Jumlah` int(11) NOT NULL,
  `TipeAsnab` int(11) NOT NULL,
  `Beras` double NOT NULL,
  `Uang` double NOT NULL,
  `Tahun` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Mustahiks: ~38 rows (approximately)
DELETE FROM `Mustahiks`;
/*!40000 ALTER TABLE `Mustahiks` DISABLE KEYS */;
INSERT INTO `Mustahiks` (`Id`, `No`, `Nama`, `Jumlah`, `TipeAsnab`, `Beras`, `Uang`, `Tahun`) VALUES
	(56, 1, 'F1', 4, 1, 6, 175000, 2021),
	(57, 2, 'F2', 1, 1, 1, 35000, 2021),
	(58, 3, 'F3', 2, 1, 3, 70000, 2021),
	(59, 4, 'F4', 4, 1, 6, 175000, 2021),
	(60, 5, 'M1', 3, 2, 8, 280000, 2021),
	(61, 6, 'F5', 5, 1, 8, 210000, 2021),
	(62, 7, 'F6', 3, 1, 4, 140000, 2021),
	(63, 8, 'MU1', 1, 5, 1, 35000, 2021),
	(64, 9, 'MU2', 1, 5, 1, 35000, 2021),
	(65, 10, 'F7', 2, 1, 3, 70000, 2021),
	(66, 11, 'F8', 2, 1, 3, 70000, 2021),
	(71, 1, 'F1', 3, 1, 6, 0, 2022),
	(72, 2, 'F2', 1, 1, 2, 0, 2022),
	(73, 4, 'F3', 4, 1, 8, 0, 2022),
	(74, 5, 'F4', 5, 1, 10, 0, 2022),
	(75, 6, 'F5', 3, 1, 6, 0, 2022),
	(76, 7, 'F6', 1, 1, 2, 0, 2022),
	(77, 8, 'F7', 2, 1, 4, 0, 2022),
	(78, 3, 'F8', 2, 2, 8, 0, 2022),
	(79, 9, 'F9', 3, 2, 12, 0, 2022),
	(111, 1, 'F1', 3, 1, 0, 0, 2023),
	(112, 2, 'F2', 2, 1, 0, 0, 2023),
	(113, 3, 'F3', 4, 1, 0, 0, 2023),
	(114, 4, 'F4', 5, 1, 0, 0, 2023),
	(115, 5, 'F5', 3, 1, 0, 0, 2023),
	(116, 6, 'F6', 1, 2, 0, 0, 2023),
	(117, 7, 'F7', 4, 1, 0, 0, 2023),
	(118, 8, 'F8', 1, 4, 0, 0, 2023),
	(128, 1, 'F1', 3, 1, 0, 0, 2024),
	(129, 2, 'F2', 2, 1, 0, 0, 2024),
	(130, 3, 'F3', 4, 1, 0, 0, 2024),
	(131, 4, 'F4', 5, 1, 0, 0, 2024),
	(132, 5, 'F5', 3, 1, 0, 0, 2024),
	(133, 6, 'F6', 1, 2, 0, 0, 2024),
	(134, 7, 'F7', 4, 1, 0, 0, 2024),
	(135, 8, 'F8', 1, 4, 0, 0, 2024),
	(136, 9, 'F9', 3, 1, 0, 0, 2024),
	(137, 10, 'F10', 2, 1, 0, 0, 2024);
/*!40000 ALTER TABLE `Mustahiks` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Musyawarah5Unsurs
CREATE TABLE IF NOT EXISTS `Musyawarah5Unsurs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `DocumentUrl` longtext DEFAULT NULL,
  `CreatedBy` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Musyawarah5Unsurs: ~0 rows (approximately)
DELETE FROM `Musyawarah5Unsurs`;
/*!40000 ALTER TABLE `Musyawarah5Unsurs` DISABLE KEYS */;
INSERT INTO `Musyawarah5Unsurs` (`Id`, `Tanggal`, `Nama`, `Keterangan`, `DocumentUrl`, `CreatedBy`) VALUES
	(1, '2021-12-05 20:21:01.825205', 'Rapat Akhir Tahun 2023', 'hasil', '', 'Pengelola');
/*!40000 ALTER TABLE `Musyawarah5Unsurs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Musyawarahs
CREATE TABLE IF NOT EXISTS `Musyawarahs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime NOT NULL,
  `Topik` varchar(300) NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `DocumentUrl` varchar(600) NOT NULL,
  `CreatedBy` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Musyawarahs: ~0 rows (approximately)
DELETE FROM `Musyawarahs`;
/*!40000 ALTER TABLE `Musyawarahs` DISABLE KEYS */;
INSERT INTO `Musyawarahs` (`Id`, `Tanggal`, `Topik`, `Keterangan`, `DocumentUrl`, `CreatedBy`) VALUES
	(1, '2020-08-08 00:00:00', 'Evaluasi Rutin Jan 2020', NULL, '', 'Tim');
/*!40000 ALTER TABLE `Musyawarahs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Muzakis
CREATE TABLE IF NOT EXISTS `Muzakis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `NoUrut` int(11) NOT NULL,
  `KK` longtext DEFAULT NULL,
  `Nama` longtext DEFAULT NULL,
  `Posisi` int(11) NOT NULL,
  `IsMustahik` tinyint(1) NOT NULL,
  `ZakatBeras` int(11) NOT NULL,
  `TitipZakat` double NOT NULL,
  `SelisihBeras` double NOT NULL,
  `SelisihTitipan` double NOT NULL,
  `Amil` longtext DEFAULT NULL,
  `DanaTalangan` double NOT NULL,
  `SudahZakat` tinyint(1) NOT NULL,
  `SudahRealisasi` tinyint(1) NOT NULL,
  `SudahTercatat` tinyint(1) NOT NULL,
  `Tahun` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8567 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Muzakis: ~0 rows (approximately)
DELETE FROM `Muzakis`;
/*!40000 ALTER TABLE `Muzakis` DISABLE KEYS */;
/*!40000 ALTER TABLE `Muzakis` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Nasehats
CREATE TABLE IF NOT EXISTS `Nasehats` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Topik` longtext NOT NULL,
  `Penasehat1` longtext NOT NULL,
  `Penasehat2` longtext NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Nasehats: ~0 rows (approximately)
DELETE FROM `Nasehats`;
/*!40000 ALTER TABLE `Nasehats` DISABLE KEYS */;
INSERT INTO `Nasehats` (`Id`, `Tanggal`, `Topik`, `Penasehat1`, `Penasehat2`) VALUES
	(3, '2020-10-03 00:00:00.000000', 'Perjuangan Sahabat Nabi', 'Ust. Asep', '-');
/*!40000 ALTER TABLE `Nasehats` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Ngajis
CREATE TABLE IF NOT EXISTS `Ngajis` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `TanggalDari` datetime(6) NOT NULL,
  `TanggalSampai` datetime(6) NOT NULL,
  `StreamUrl` longtext DEFAULT NULL,
  `DocumentUrl` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Ngajis: ~2 rows (approximately)
DELETE FROM `Ngajis`;
/*!40000 ALTER TABLE `Ngajis` DISABLE KEYS */;
INSERT INTO `Ngajis` (`Id`, `Nama`, `Keterangan`, `TanggalDari`, `TanggalSampai`, `StreamUrl`, `DocumentUrl`) VALUES
	(2, 'Kajian Rutin Sabtu', NULL, '2020-09-21 09:28:15.478439', '2020-12-31 10:58:15.000000', 'https://teams.microsoft.com/l/meetup-join/19%3ameeting_YWM5NDdhZTQtYzAwYS00NzE2LTgzMTQtYzFkNzVhNzNmNGM4%40thread.v2/0?context=%7b%22Tid%22%3a%22191fd7cd-eec1-45c1-aeea-1db525f949cc%22%2c%22Oid%22%3a%2245304974-bcc6-4a86-a0cf-9b37f9a73ef9%22%7d', NULL),
	(3, 'Kajian Rutin Ahad', NULL, '2020-09-21 09:28:36.122330', '2020-12-31 10:58:36.000000', 'https://teams.microsoft.com/l/meetup-join/19%3ameeting_MWM5ZTg1ZWUtODFlYy00MDA0LThlY2MtM2I0NzIxNDM1NzU4%40thread.v2/0?context=%7b%22Tid%22%3a%22191fd7cd-eec1-45c1-aeea-1db525f949cc%22%2c%22Oid%22%3a%2245304974-bcc6-4a86-a0cf-9b37f9a73ef9%22%7d', NULL);
/*!40000 ALTER TABLE `Ngajis` ENABLE KEYS */;

-- Dumping structure for table moslemdb.NilaiSiswas
CREATE TABLE IF NOT EXISTS `NilaiSiswas` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `Hadir` tinyint(1) NOT NULL,
  `Nilai` int(11) NOT NULL,
  `JamaahId` bigint(20) NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `KeteranganDari` longtext DEFAULT NULL,
  `Respon` longtext DEFAULT NULL,
  `ResponDari` longtext DEFAULT NULL,
  `MateriPerKelasId` bigint(20) NOT NULL,
  `Kehadiran` int(11) DEFAULT 0,
  PRIMARY KEY (`Id`),
  KEY `IX_NilaiSiswas_JamaahId` (`JamaahId`),
  KEY `IX_NilaiSiswas_MateriPerKelasId` (`MateriPerKelasId`),
  CONSTRAINT `FK_NilaiSiswas_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_NilaiSiswas_MateriPerKelass_MateriPerKelasId` FOREIGN KEY (`MateriPerKelasId`) REFERENCES `MateriPerKelass` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.NilaiSiswas: ~0 rows (approximately)
DELETE FROM `NilaiSiswas`;
/*!40000 ALTER TABLE `NilaiSiswas` DISABLE KEYS */;
/*!40000 ALTER TABLE `NilaiSiswas` ENABLE KEYS */;

-- Dumping structure for table moslemdb.PenerimaanInfaqSodakohs
CREATE TABLE IF NOT EXISTS `PenerimaanInfaqSodakohs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `No` int(11) NOT NULL,
  `AkunInfaqSodakohId` bigint(20) NOT NULL,
  `HeaderPenerimaanInfaqSodakohId` bigint(20) NOT NULL,
  `JamaahId` bigint(20) NOT NULL,
  `NamaJamaah` longtext DEFAULT NULL,
  `NamaAkun` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `Jumlah` double NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_PenerimaanInfaqSodakohs_AkunInfaqSodakohId` (`AkunInfaqSodakohId`),
  KEY `IX_PenerimaanInfaqSodakohs_HeaderPenerimaanInfaqSodakohId` (`HeaderPenerimaanInfaqSodakohId`),
  KEY `IX_PenerimaanInfaqSodakohs_JamaahId` (`JamaahId`),
  CONSTRAINT `FK_PenerimaanInfaqSodakohs_AkunInfaqSodakohs_AkunInfaqSodakohId` FOREIGN KEY (`AkunInfaqSodakohId`) REFERENCES `AkunInfaqSodakohs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_PenerimaanInfaqSodakohs_HeaderPenerimaanInfaqSodakohs_Header~` FOREIGN KEY (`HeaderPenerimaanInfaqSodakohId`) REFERENCES `HeaderPenerimaanInfaqSodakohs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_PenerimaanInfaqSodakohs_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.PenerimaanInfaqSodakohs: ~0 rows (approximately)
DELETE FROM `PenerimaanInfaqSodakohs`;
/*!40000 ALTER TABLE `PenerimaanInfaqSodakohs` DISABLE KEYS */;
/*!40000 ALTER TABLE `PenerimaanInfaqSodakohs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.PengeluaranInfaqSodakohs
CREATE TABLE IF NOT EXISTS `PengeluaranInfaqSodakohs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `No` int(11) NOT NULL,
  `AkunInfaqSodakohId` bigint(20) NOT NULL,
  `NamaAkun` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `Jumlah` double NOT NULL,
  `DikeluarkanOleh` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_PengeluaranInfaqSodakohs_AkunInfaqSodakohId` (`AkunInfaqSodakohId`),
  CONSTRAINT `FK_PengeluaranInfaqSodakohs_AkunInfaqSodakohs_AkunInfaqSodakohId` FOREIGN KEY (`AkunInfaqSodakohId`) REFERENCES `AkunInfaqSodakohs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.PengeluaranInfaqSodakohs: ~0 rows (approximately)
DELETE FROM `PengeluaranInfaqSodakohs`;
/*!40000 ALTER TABLE `PengeluaranInfaqSodakohs` DISABLE KEYS */;
/*!40000 ALTER TABLE `PengeluaranInfaqSodakohs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Pengumumans
CREATE TABLE IF NOT EXISTS `Pengumumans` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Judul` varchar(250) NOT NULL DEFAULT '0',
  `Isi` varchar(800) NOT NULL DEFAULT '0',
  `Tanggal` datetime NOT NULL,
  `CreatedBy` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Pengumumans: ~0 rows (approximately)
DELETE FROM `Pengumumans`;
/*!40000 ALTER TABLE `Pengumumans` DISABLE KEYS */;
INSERT INTO `Pengumumans` (`Id`, `Judul`, `Isi`, `Tanggal`, `CreatedBy`) VALUES
	(1, 'Qurban 2023', 'Waspada wabah LSD, pastikan qurban di vaksin dulu', '2022-11-01 06:00:30', 'Tim');
/*!40000 ALTER TABLE `Pengumumans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Pinjamans
CREATE TABLE IF NOT EXISTS `Pinjamans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `Peminjam` longtext DEFAULT NULL,
  `PemberiPinjaman` longtext DEFAULT NULL,
  `JumlahPinjaman` double NOT NULL,
  `TanggalPinjam` datetime(6) NOT NULL,
  `TanggalPengembalian` datetime(6) NOT NULL,
  `JangkaWaktuHari` int(11) NOT NULL,
  `Tipe` int(11) NOT NULL,
  `Status` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Pinjamans: ~0 rows (approximately)
DELETE FROM `Pinjamans`;
/*!40000 ALTER TABLE `Pinjamans` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pinjamans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.ProfilInfaqJamaahs
CREATE TABLE IF NOT EXISTS `ProfilInfaqJamaahs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `JamaahId` bigint(20) NOT NULL,
  `Frekuensi` int(11) NOT NULL,
  `Pekerjaan` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_ProfilInfaqJamaahs_JamaahId` (`JamaahId`),
  CONSTRAINT `FK_ProfilInfaqJamaahs_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.ProfilInfaqJamaahs: ~0 rows (approximately)
DELETE FROM `ProfilInfaqJamaahs`;
/*!40000 ALTER TABLE `ProfilInfaqJamaahs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProfilInfaqJamaahs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.ProgramRamadans
CREATE TABLE IF NOT EXISTS `ProgramRamadans` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `TanggalUpdate` datetime(6) NOT NULL,
  `Nama` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.ProgramRamadans: ~0 rows (approximately)
DELETE FROM `ProgramRamadans`;
/*!40000 ALTER TABLE `ProgramRamadans` DISABLE KEYS */;
INSERT INTO `ProgramRamadans` (`Id`, `TanggalUpdate`, `Nama`) VALUES
	(5, '2021-01-07 20:32:41.221786', 'Yusup');
/*!40000 ALTER TABLE `ProgramRamadans` ENABLE KEYS */;

-- Dumping structure for table moslemdb.ProgramSemesters
CREATE TABLE IF NOT EXISTS `ProgramSemesters` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Minggu` int(11) NOT NULL,
  `Bulan` int(11) NOT NULL,
  `MateriPerKelasId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_ProgramSemesters_MateriPerKelasId` (`MateriPerKelasId`),
  CONSTRAINT `FK_ProgramSemesters_MateriPerKelass_MateriPerKelasId` FOREIGN KEY (`MateriPerKelasId`) REFERENCES `MateriPerKelass` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.ProgramSemesters: ~0 rows (approximately)
DELETE FROM `ProgramSemesters`;
/*!40000 ALTER TABLE `ProgramSemesters` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProgramSemesters` ENABLE KEYS */;

-- Dumping structure for table moslemdb.ProsentaseZakats
CREATE TABLE IF NOT EXISTS `ProsentaseZakats` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `Persen` double NOT NULL,
  `IsAsnab` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.ProsentaseZakats: ~5 rows (approximately)
DELETE FROM `ProsentaseZakats`;
/*!40000 ALTER TABLE `ProsentaseZakats` DISABLE KEYS */;
INSERT INTO `ProsentaseZakats` (`Id`, `Nama`, `Persen`, `IsAsnab`) VALUES
	(1, 'Amil', 0.1, 0),
	(2, 'Penyelenggaraan', 0.05, 0),
	(3, 'Alat', 0.03, 0),
	(4, 'Lainnya', 0.02, 0),
	(5, 'Asnab', 0.8, 1);
/*!40000 ALTER TABLE `ProsentaseZakats` ENABLE KEYS */;

-- Dumping structure for table moslemdb.SetoranSodakohKhususBarangs
CREATE TABLE IF NOT EXISTS `SetoranSodakohKhususBarangs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `JamaahId` bigint(20) NOT NULL,
  `NamaPenyetor` longtext DEFAULT NULL,
  `AkunSodakohKhususId` bigint(20) NOT NULL,
  `NamaBarang` longtext DEFAULT NULL,
  `Jumlah` double NOT NULL,
  `Satuan` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `DiterimaOleh` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_SetoranSodakohKhususBarangs_AkunSodakohKhususId` (`AkunSodakohKhususId`),
  KEY `IX_SetoranSodakohKhususBarangs_JamaahId` (`JamaahId`),
  CONSTRAINT `FK_SetoranSodakohKhususBarangs_AkunSodakohKhususs_AkunSodakohKh~` FOREIGN KEY (`AkunSodakohKhususId`) REFERENCES `AkunSodakohKhususs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_SetoranSodakohKhususBarangs_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.SetoranSodakohKhususBarangs: ~0 rows (approximately)
DELETE FROM `SetoranSodakohKhususBarangs`;
/*!40000 ALTER TABLE `SetoranSodakohKhususBarangs` DISABLE KEYS */;
/*!40000 ALTER TABLE `SetoranSodakohKhususBarangs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.SetoranSodakohKhususs
CREATE TABLE IF NOT EXISTS `SetoranSodakohKhususs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `JamaahId` bigint(20) NOT NULL,
  `NamaPenyetor` longtext DEFAULT NULL,
  `AkunSodakohKhususId` bigint(20) NOT NULL,
  `Jumlah` double NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `DiterimaOleh` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_SetoranSodakohKhususs_AkunSodakohKhususId` (`AkunSodakohKhususId`),
  KEY `IX_SetoranSodakohKhususs_JamaahId` (`JamaahId`),
  CONSTRAINT `FK_SetoranSodakohKhususs_AkunSodakohKhususs_AkunSodakohKhususId` FOREIGN KEY (`AkunSodakohKhususId`) REFERENCES `AkunSodakohKhususs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_SetoranSodakohKhususs_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.SetoranSodakohKhususs: ~0 rows (approximately)
DELETE FROM `SetoranSodakohKhususs`;
/*!40000 ALTER TABLE `SetoranSodakohKhususs` DISABLE KEYS */;
/*!40000 ALTER TABLE `SetoranSodakohKhususs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.SiswaPerKelass
CREATE TABLE IF NOT EXISTS `SiswaPerKelass` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `KelasId` bigint(20) DEFAULT NULL,
  `JamaahId` bigint(20) DEFAULT NULL,
  `Tahun` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_SiswaPerKelass_JamaahId` (`JamaahId`),
  KEY `IX_SiswaPerKelass_KelasId` (`KelasId`),
  CONSTRAINT `FK_SiswaPerKelass_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`),
  CONSTRAINT `FK_SiswaPerKelass_Kelass_KelasId` FOREIGN KEY (`KelasId`) REFERENCES `Kelass` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- Dumping data for table moslemdb.SiswaPerKelass: ~0 rows (approximately)
DELETE FROM `SiswaPerKelass`;
/*!40000 ALTER TABLE `SiswaPerKelass` DISABLE KEYS */;
/*!40000 ALTER TABLE `SiswaPerKelass` ENABLE KEYS */;

-- Dumping structure for table moslemdb.SmsBroadcasts
CREATE TABLE IF NOT EXISTS `SmsBroadcasts` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Judul` varchar(300) NOT NULL DEFAULT '0',
  `Pesan` varchar(300) NOT NULL DEFAULT '0',
  `DikirimKe` varchar(8000) NOT NULL DEFAULT '0',
  `WaktuKirim` time DEFAULT NULL,
  `AktifDari` datetime DEFAULT NULL,
  `AktifSampai` datetime DEFAULT NULL,
  `Terkirim` int(11) DEFAULT NULL,
  `Berulang` bit(1) NOT NULL DEFAULT b'0',
  `Hari` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.SmsBroadcasts: ~2 rows (approximately)
DELETE FROM `SmsBroadcasts`;
/*!40000 ALTER TABLE `SmsBroadcasts` DISABLE KEYS */;
INSERT INTO `SmsBroadcasts` (`Id`, `Judul`, `Pesan`, `DikirimKe`, `WaktuKirim`, `AktifDari`, `AktifSampai`, `Terkirim`, `Berulang`, `Hari`) VALUES
	(3, 'Pengingat Solat Malam', 'Assalamualaikum, Ysh monggo sempatkan tahajud dan doa malam, jgn lupa tadarus. ', '', '03:30:00', '2021-04-11 18:02:21', '2022-12-12 23:59:59', 0, b'1', '0;1;2;3;4;5;6'),
	(5, 'Persiapan Teraweh', 'Assalamualaikum wr wb, persiapan Teraweh dan Mncari Lailatulqadr, Semoga Alloh memberikan magfiroh dan kebarokahan. ', '', '19:00:00', '2021-04-12 04:24:50', '2021-05-12 23:59:59', 0, b'1', '0;1;2;3;4;5;6');
/*!40000 ALTER TABLE `SmsBroadcasts` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Sodakohs
CREATE TABLE IF NOT EXISTS `Sodakohs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `NamaBank` longtext DEFAULT NULL,
  `NoRekening` longtext DEFAULT NULL,
  `NamaRekening` longtext DEFAULT NULL,
  `NamaGopay` longtext DEFAULT NULL,
  `NomorGopay` longtext DEFAULT NULL,
  `GopayQRUrl` longtext DEFAULT NULL,
  `Kategori` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Sodakohs: ~0 rows (approximately)
DELETE FROM `Sodakohs`;
/*!40000 ALTER TABLE `Sodakohs` DISABLE KEYS */;
/*!40000 ALTER TABLE `Sodakohs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.StateStorages
CREATE TABLE IF NOT EXISTS `StateStorages` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `NameKey` longtext DEFAULT NULL,
  `ValueString` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.StateStorages: ~7 rows (approximately)
DELETE FROM `StateStorages`;
/*!40000 ALTER TABLE `StateStorages` DISABLE KEYS */;
INSERT INTO `StateStorages` (`Id`, `NameKey`, `ValueString`) VALUES
	(1, 'zakatfitrah-2021', '{"HargaJualBeras":25000,"PembagianDetail":[{"No":1,"TotalPembagian":92.0,"TotalBerasDijual":74.0,"TotalBerasSisa":18.000000000000007,"TotalBerasSisaSebelumnya":0.0,"TotalUang":2590000.0,"Detail":[{"Nama":"SB","Terima":36.800000000000004,"Dijual":36.0,"Sisa":0.8000000000000043,"SisaSebelumnya":0.0,"Uang":1260000.0,"DibeliOleh":[{"Id":4246,"NoUrut":3,"KK":"AKK001","Nama":"Andi Kudi","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4245,"NoUrut":2,"KK":"AKK001","Nama":"Anisa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4121,"NoUrut":1,"KK":"AKK001","Nama":"Nina Herlina","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4249,"NoUrut":1,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4251,"NoUrut":3,"KK":"AKK003","Nama":"Handika Wira Ramadhan","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4250,"NoUrut":2,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4255,"NoUrut":1,"KK":"AKK008","Nama":"Abu Dhohir","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4259,"NoUrut":5,"KK":"AKK008","Nama":"Adit Abdu Rohman","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4257,"NoUrut":3,"KK":"AKK008","Nama":"Dewi Maryam","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4256,"NoUrut":2,"KK":"AKK008","Nama":"Kusrini","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4258,"NoUrut":4,"KK":"AKK008","Nama":"Novi Sholikhatun","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4262,"NoUrut":3,"KK":"BKK009","Nama":"Adine Sainandira Yoshe","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4260,"NoUrut":1,"KK":"BKK009","Nama":"Bayubadra Megaranda","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4263,"NoUrut":4,"KK":"BKK009","Nama":"Calisha Nayundari Yoshe","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4261,"NoUrut":2,"KK":"BKK009","Nama":"Dian Ary Kusumah","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4264,"NoUrut":5,"KK":"BKK009","Nama":"Elfrina Sazradiba Yoshe","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4244,"NoUrut":7,"KK":"BKK009","Nama":"Istatik Yudirahayu","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4265,"NoUrut":6,"KK":"BKK009","Nama":"Sakinah Novianti","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4234,"NoUrut":1,"KK":"DKK013","Nama":"Doddy","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"AZIZ","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4235,"NoUrut":2,"KK":"DKK013","Nama":"Risti Diana Putri","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"AZIZ","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4236,"NoUrut":3,"KK":"DKK013","Nama":"Rizqiana Safa Khaira","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"AZIZ","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4266,"NoUrut":3,"KK":"DKK015","Nama":"Abiyyu Nara","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4267,"NoUrut":4,"KK":"DKK015","Nama":"Adara Naura","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4240,"NoUrut":2,"KK":"DKK015","Nama":"Dyah (Dhea) Pitaloka","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4239,"NoUrut":1,"KK":"DKK015","Nama":"Repal","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4305,"NoUrut":4,"KK":"EKK018","Nama":"Budi Nuryanto","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4303,"NoUrut":2,"KK":"EKK018","Nama":"Dimas Daud Probokusumo","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4302,"NoUrut":1,"KK":"EKK018","Nama":"Euis Hartati","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4304,"NoUrut":3,"KK":"EKK018","Nama":"Mia Febriani","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4306,"NoUrut":1,"KK":"EKK019","Nama":"Ernanto","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4309,"NoUrut":4,"KK":"EKK019","Nama":"Nadine Alika","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4308,"NoUrut":3,"KK":"EKK019","Nama":"Salma Renata","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4307,"NoUrut":2,"KK":"EKK019","Nama":"Sri Wahyuni","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4310,"NoUrut":5,"KK":"EKK019","Nama":"Val Aqsha Dirgantara","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4315,"NoUrut":5,"KK":"HKK021","Nama":"Agung Is Hartono","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4312,"NoUrut":2,"KK":"HKK021","Nama":"Dina Safita","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"Daerah","Terima":0.92,"Dijual":0.0,"Sisa":0.92,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":1.84,"Dijual":1.0,"Sisa":0.8400000000000001,"SisaSebelumnya":0.0,"Uang":35000.0,"DibeliOleh":[{"Id":4294,"NoUrut":6,"KK":"HKK021","Nama":"Enza Camila Fitri","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"Kelompok","Terima":11.04,"Dijual":0.0,"Sisa":11.04,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F1","Terima":5.341935483870968,"Dijual":5.0,"Sisa":0.3419354838709676,"SisaSebelumnya":0.0,"Uang":175000.0,"DibeliOleh":[{"Id":4311,"NoUrut":1,"KK":"HKK021","Nama":"Haryo Radityo","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4313,"NoUrut":3,"KK":"HKK021","Nama":"Mikail Abdulkarim","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4314,"NoUrut":4,"KK":"HKK021","Nama":"Setiyowati Soetomo","Posisi":8,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4316,"NoUrut":7,"KK":"HKK021","Nama":"Xhaka Gifta Adenza","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4282,"NoUrut":2,"KK":"IKK025","Nama":"Amanda PP ","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F2","Terima":1.335483870967742,"Dijual":1.0,"Sisa":0.3354838709677419,"SisaSebelumnya":0.0,"Uang":35000.0,"DibeliOleh":[{"Id":4284,"NoUrut":4,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F3","Terima":2.670967741935484,"Dijual":2.0,"Sisa":0.6709677419354838,"SisaSebelumnya":0.0,"Uang":70000.0,"DibeliOleh":[{"Id":4281,"NoUrut":1,"KK":"IKK025","Nama":"Ibn Fadhil","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4283,"NoUrut":3,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F4","Terima":5.341935483870968,"Dijual":5.0,"Sisa":0.3419354838709676,"SisaSebelumnya":0.0,"Uang":175000.0,"DibeliOleh":[{"Id":4287,"NoUrut":3,"KK":"IKK026","Nama":"Azka Nurmala Devi","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":8300.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4285,"NoUrut":1,"KK":"IKK026","Nama":"Imelda Kemala Devi","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":8300.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4286,"NoUrut":2,"KK":"IKK026","Nama":"Nayra Zahra Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":8300.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4151,"NoUrut":2,"KK":"MKK030","Nama":"Bima Danu Kusumah","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4154,"NoUrut":5,"KK":"MKK030","Nama":"Eka Sri Rahayu","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"M1","Terima":8.012903225806452,"Dijual":8.0,"Sisa":0.012903225806452312,"SisaSebelumnya":0.0,"Uang":280000.0,"DibeliOleh":[{"Id":4150,"NoUrut":1,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4152,"NoUrut":3,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4153,"NoUrut":4,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4155,"NoUrut":1,"KK":"MKK031","Nama":"Makmur","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4156,"NoUrut":2,"KK":"MKK031","Nama":"Mida","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4159,"NoUrut":5,"KK":"MKK031","Nama":"Muhammad Dzickry","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4158,"NoUrut":4,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4157,"NoUrut":3,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F5","Terima":6.67741935483871,"Dijual":6.0,"Sisa":0.67741935483871,"SisaSebelumnya":0.0,"Uang":210000.0,"DibeliOleh":[{"Id":4130,"NoUrut":2,"KK":"SKK039","Nama":"M Prayoga Aji Nugraha","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4129,"NoUrut":1,"KK":"SKK039","Nama":"Siti Sarah","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4134,"NoUrut":4,"KK":"SKK040","Nama":"Ahmad Sakha Arkaan Manggala Putra","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4133,"NoUrut":3,"KK":"SKK040","Nama":"Mohammad Sakti Manggala Putra","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4142,"NoUrut":2,"KK":"SKK040","Nama":"Ratih Unjunan Sari","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4132,"NoUrut":1,"KK":"SKK040","Nama":"Satria Manggala","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F6","Terima":4.006451612903226,"Dijual":4.0,"Sisa":0.006451612903226156,"SisaSebelumnya":0.0,"Uang":140000.0,"DibeliOleh":[{"Id":4136,"NoUrut":2,"KK":"SKK041","Nama":"Inez Fajriannisa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4137,"NoUrut":3,"KK":"SKK041","Nama":"M. Farrel SA","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4138,"NoUrut":4,"KK":"SKK041","Nama":"Rizka Dyanira C","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4135,"NoUrut":1,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"MU1","Terima":1.335483870967742,"Dijual":1.0,"Sisa":0.3354838709677419,"SisaSebelumnya":0.0,"Uang":35000.0,"DibeliOleh":[{"Id":4139,"NoUrut":5,"KK":"SKK041","Nama":"Tiara Syahriani Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"MU2","Terima":1.335483870967742,"Dijual":1.0,"Sisa":0.3354838709677419,"SisaSebelumnya":0.0,"Uang":35000.0,"DibeliOleh":[{"Id":4167,"NoUrut":3,"KK":"SKK042","Nama":"Almaira","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"CHOIRUL","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F7","Terima":2.670967741935484,"Dijual":2.0,"Sisa":0.6709677419354838,"SisaSebelumnya":0.0,"Uang":70000.0,"DibeliOleh":[{"Id":4168,"NoUrut":4,"KK":"SKK042","Nama":"Elsanun","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"CHOIRUL","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4141,"NoUrut":2,"KK":"SKK042","Nama":"Nuranisa","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"CHOIRUL","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"F8","Terima":2.670967741935484,"Dijual":2.0,"Sisa":0.6709677419354838,"SisaSebelumnya":0.0,"Uang":70000.0,"DibeliOleh":[{"Id":4140,"NoUrut":1,"KK":"SKK042","Nama":"Sulthon","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"CHOIRUL","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4170,"NoUrut":2,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]}]},{"No":2,"TotalPembagian":74.0,"TotalBerasDijual":29.0,"TotalBerasSisa":63.0,"TotalBerasSisaSebelumnya":18.000000000000007,"TotalUang":1015000.0,"Detail":[{"Nama":"SB","Terima":29.6,"Dijual":26.0,"Sisa":4.400000000000006,"SisaSebelumnya":0.8000000000000043,"Uang":910000.0,"DibeliOleh":[{"Id":4169,"NoUrut":1,"KK":"TKK043","Nama":"Tenny Supartini","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4204,"NoUrut":2,"KK":"WKK045","Nama":"Agam Bhaskoro","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4203,"NoUrut":1,"KK":"WKK045","Nama":"Wiwik Hartatik","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4206,"NoUrut":2,"KK":"YKK046","Nama":"Fera koes Rahayu","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4208,"NoUrut":4,"KK":"YKK046","Nama":"Kresna Rizki Romadhon","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4207,"NoUrut":3,"KK":"YKK046","Nama":"Oscar Tirta Sugema","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4205,"NoUrut":1,"KK":"YKK046","Nama":"Yogi yogaswara ","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4195,"NoUrut":2,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4216,"NoUrut":1,"KK":"ZKK048","Nama":"Zaenal Abidin Masse","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4178,"NoUrut":8,"KK":"ZSIMP06","Nama":"Cut Sartika","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4177,"NoUrut":7,"KK":"ZSIMP06","Nama":"Dyandra Via Dhama","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4171,"NoUrut":1,"KK":"ZSIMP06","Nama":"Hanryan Indrawira","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4174,"NoUrut":4,"KK":"ZSIMP06","Nama":"Indira Via Ramadhani","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4172,"NoUrut":2,"KK":"ZSIMP06","Nama":"Okky Windyasari","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4173,"NoUrut":3,"KK":"ZSIMP06","Nama":"Qiara Vira Putri","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4176,"NoUrut":6,"KK":"ZSIMP06","Nama":"Rio Wia Arazak","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4175,"NoUrut":5,"KK":"ZSIMP06","Nama":"Sierra Vira Hani","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4186,"NoUrut":7,"KK":"ZSIMP08","Nama":"Abdullah Bin H. Salam","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4185,"NoUrut":6,"KK":"ZSIMP08","Nama":"Afkharrilo Angkasawira Bin Hariza Angkasawira","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4184,"NoUrut":5,"KK":"ZSIMP08","Nama":"Aghitsna Nur Farizah Binti Rizal Zulferdi","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4188,"NoUrut":9,"KK":"ZSIMP08","Nama":"Alori Nuraisyah Angkasawira","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4181,"NoUrut":2,"KK":"ZSIMP08","Nama":"Anisatul Khofifah","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4191,"NoUrut":12,"KK":"ZSIMP08","Nama":"Fitriyani","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4189,"NoUrut":10,"KK":"ZSIMP08","Nama":"Haerudin","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4180,"NoUrut":1,"KK":"ZSIMP08","Nama":"Hariza Angkasa Wira Bin Burhanuddin Razak","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4183,"NoUrut":4,"KK":"ZSIMP08","Nama":"Lony Novita Binti H. Abdullah","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"Daerah","Terima":0.74,"Dijual":1.0,"Sisa":0.6600000000000001,"SisaSebelumnya":0.92,"Uang":35000.0,"DibeliOleh":[{"Id":4190,"NoUrut":11,"KK":"ZSIMP08","Nama":"Nunung Nur Halimah","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"Desa","Terima":1.48,"Dijual":2.0,"Sisa":0.3200000000000003,"SisaSebelumnya":0.8400000000000001,"Uang":70000.0,"DibeliOleh":[{"Id":4187,"NoUrut":8,"KK":"ZSIMP08","Nama":"Nurdiah Binti Hermansyah","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021},{"Id":4182,"NoUrut":3,"KK":"ZSIMP08","Nama":"Winda Astuti Binti Alm. Hadi Sunaryo","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":35000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2021}]},{"Nama":"Kelompok","Terima":8.879999999999999,"Dijual":0.0,"Sisa":19.919999999999998,"SisaSebelumnya":11.04,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F1","Terima":4.296774193548387,"Dijual":0.0,"Sisa":4.638709677419355,"SisaSebelumnya":0.3419354838709676,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F2","Terima":1.0741935483870968,"Dijual":0.0,"Sisa":1.4096774193548387,"SisaSebelumnya":0.3354838709677419,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F3","Terima":2.1483870967741936,"Dijual":0.0,"Sisa":2.8193548387096774,"SisaSebelumnya":0.6709677419354838,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F4","Terima":4.296774193548387,"Dijual":0.0,"Sisa":4.638709677419355,"SisaSebelumnya":0.3419354838709676,"Uang":0.0,"DibeliOleh":[]},{"Nama":"M1","Terima":6.445161290322581,"Dijual":0.0,"Sisa":6.458064516129033,"SisaSebelumnya":0.012903225806452312,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F5","Terima":5.370967741935484,"Dijual":0.0,"Sisa":6.048387096774194,"SisaSebelumnya":0.67741935483871,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F6","Terima":3.2225806451612904,"Dijual":0.0,"Sisa":3.2290322580645165,"SisaSebelumnya":0.006451612903226156,"Uang":0.0,"DibeliOleh":[]},{"Nama":"MU1","Terima":1.0741935483870968,"Dijual":0.0,"Sisa":1.4096774193548387,"SisaSebelumnya":0.3354838709677419,"Uang":0.0,"DibeliOleh":[]},{"Nama":"MU2","Terima":1.0741935483870968,"Dijual":0.0,"Sisa":1.4096774193548387,"SisaSebelumnya":0.3354838709677419,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F7","Terima":2.1483870967741936,"Dijual":0.0,"Sisa":2.8193548387096774,"SisaSebelumnya":0.6709677419354838,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F8","Terima":2.1483870967741936,"Dijual":0.0,"Sisa":2.8193548387096774,"SisaSebelumnya":0.6709677419354838,"Uang":0.0,"DibeliOleh":[]}]},{"No":3,"TotalPembagian":29.0,"TotalBerasDijual":0.0,"TotalBerasSisa":92.0,"TotalBerasSisaSebelumnya":63.0,"TotalUang":0.0,"Detail":[{"Nama":"SB","Terima":11.600000000000001,"Dijual":0.0,"Sisa":16.000000000000007,"SisaSebelumnya":4.400000000000006,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Daerah","Terima":0.29,"Dijual":0.0,"Sisa":0.9500000000000002,"SisaSebelumnya":0.6600000000000001,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":0.58,"Dijual":0.0,"Sisa":0.9000000000000002,"SisaSebelumnya":0.3200000000000003,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Kelompok","Terima":3.48,"Dijual":0.0,"Sisa":23.4,"SisaSebelumnya":19.919999999999998,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F1","Terima":1.6838709677419355,"Dijual":0.0,"Sisa":6.32258064516129,"SisaSebelumnya":4.638709677419355,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F2","Terima":0.42096774193548386,"Dijual":0.0,"Sisa":1.8306451612903225,"SisaSebelumnya":1.4096774193548387,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F3","Terima":0.8419354838709677,"Dijual":0.0,"Sisa":3.661290322580645,"SisaSebelumnya":2.8193548387096774,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F4","Terima":1.6838709677419355,"Dijual":0.0,"Sisa":6.32258064516129,"SisaSebelumnya":4.638709677419355,"Uang":0.0,"DibeliOleh":[]},{"Nama":"M1","Terima":2.5258064516129033,"Dijual":0.0,"Sisa":8.983870967741936,"SisaSebelumnya":6.458064516129033,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F5","Terima":2.1048387096774195,"Dijual":0.0,"Sisa":8.153225806451614,"SisaSebelumnya":6.048387096774194,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F6","Terima":1.2629032258064516,"Dijual":0.0,"Sisa":4.491935483870968,"SisaSebelumnya":3.2290322580645165,"Uang":0.0,"DibeliOleh":[]},{"Nama":"MU1","Terima":0.42096774193548386,"Dijual":0.0,"Sisa":1.8306451612903225,"SisaSebelumnya":1.4096774193548387,"Uang":0.0,"DibeliOleh":[]},{"Nama":"MU2","Terima":0.42096774193548386,"Dijual":0.0,"Sisa":1.8306451612903225,"SisaSebelumnya":1.4096774193548387,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F7","Terima":0.8419354838709677,"Dijual":0.0,"Sisa":3.661290322580645,"SisaSebelumnya":2.8193548387096774,"Uang":0.0,"DibeliOleh":[]},{"Nama":"F8","Terima":0.8419354838709677,"Dijual":0.0,"Sisa":3.661290322580645,"SisaSebelumnya":2.8193548387096774,"Uang":0.0,"DibeliOleh":[]}]}]}'),
	(2, 'qurban-2020', '{"TotalBerat":1623.0,"BeratTanpaSampil":1383.0,"TotalBeratBersih":1259.0,"Report":[{"No":"1","Uraian":"Jumlah Sapi","Jumlah":"9","Satuan":"Ekor"},{"No":"2","Uraian":"Jumlah Kambing","Jumlah":"0","Satuan":"Ekor"},{"No":"3","Uraian":"Porsi Jamaah","Jumlah":"670.00","Satuan":"Kg"},{"No":"4","Uraian":"Budi Luhur Sekitar Lingkungan Jamaah","Jumlah":"385.00","Satuan":"Kg"},{"No":"5","Uraian":"Porsi (8 @ 30kg) Sampil Jamaah","Jumlah":"240.00","Satuan":"Ekor"},{"No":"6","Uraian":"Budi Luhur Lainnya","Jumlah":"122.00","Satuan":"Kg"},{"No":"7","Uraian":"Budi Luhur Warga","Jumlah":"65.00","Satuan":"Kg"},{"No":"8","Uraian":"Budi Luhur Desa","Jumlah":"75.00","Satuan":"Kg"},{"No":"9","Uraian":"Budi Luhur Jamaah","Jumlah":"11.00","Satuan":"Kg"},{"No":"10","Uraian":"Budi Luhur Pejabat","Jumlah":"46.00","Satuan":"Kg"},{"No":"11","Uraian":"Budi Luhur Keamanan","Jumlah":"9.00","Satuan":"Kg"}],"Info":{"Id":1,"Tahun":2020,"TglMulai":"2021-05-29T07:00:00","TglSelesai":"2021-05-29T16:00:00","PanitiaUrl":"https://storagemurahaje.blob.core.windows.net/ngaji-online/PanitiaQurban_29_05_2021_infoqurban.png","InfoLainUrl":null},"BL":[{"Id":1,"Urut":1,"Nama":"APRESIASI/BONUS","BERAT":3.5,"BUNGKUS":15.0,"KP":"","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":2,"Urut":2,"Nama":"ART OSCAR","BERAT":1.0,"BUNGKUS":4.0,"KP":"G","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":3,"Urut":3,"Nama":"BL SEKITAR OSCAR","BERAT":1.0,"BUNGKUS":65.0,"KP":"G","KETERANGAN":"Pak Budi, Tambal Ban","Tahun":2020,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":4,"Urut":4,"Nama":"BU DANI","BERAT":2.0,"BUNGKUS":1.0,"KP":"E","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":5,"Urut":5,"Nama":"BU YOMO","BERAT":2.0,"BUNGKUS":1.0,"KP":"E","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":6,"Urut":6,"Nama":"BUAZIZ","BERAT":2.0,"BUNGKUS":1.0,"KP":"E","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":7,"Urut":7,"Nama":"CADANGAN","BERAT":1.5,"BUNGKUS":20.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":8,"Urut":8,"Nama":"DESA BUDI AGUNG1 0.5 Kg","BERAT":0.5,"BUNGKUS":150.0,"KP":"H","KETERANGAN":"Pemintaan 994","Tahun":2020,"Jenis":0,"SudahSiap":false,"SudahDiterima":false},{"Id":9,"Urut":9,"Nama":"GALI SUMUR","BERAT":1.0,"BUNGKUS":2.0,"KP":"G","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":10,"Urut":10,"Nama":"GUNARDI","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":11,"Urut":11,"Nama":"GUNTUR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":12,"Urut":12,"Nama":"HAMZAH","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":null,"Tahun":2020,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":13,"Urut":13,"Nama":"HERI  PURNOMO","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":null,"Tahun":2020,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":14,"Urut":15,"Nama":"JAGAL","BERAT":1.0,"BUNGKUS":12.0,"KP":"G","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":15,"Urut":16,"Nama":"PEJABAT Kel, 2RT, RW,DKM","BERAT":2.0,"BUNGKUS":15.0,"KP":"E","KETERANGAN":null,"Tahun":2020,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":16,"Urut":17,"Nama":"PEJABAT KORAMIL","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":17,"Urut":18,"Nama":"PEJABAT LINGKUNGAN DESA BA","BERAT":2.0,"BUNGKUS":5.0,"KP":"E","KETERANGAN":"Pemintaan 994","Tahun":2020,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":18,"Urut":19,"Nama":"PEJABAT POLSEK","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":19,"Urut":20,"Nama":"SATPAM BAR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":20,"Urut":21,"Nama":"SATPAM CENGKEH","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":21,"Urut":22,"Nama":"SATPAM OSCAR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":22,"Urut":23,"Nama":"SULAIMAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":23,"Urut":24,"Nama":"TRISNO","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":24,"Urut":25,"Nama":"TUKANG TENDA","BERAT":1.0,"BUNGKUS":4.0,"KP":"G","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":25,"Urut":26,"Nama":"WAWAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":26,"Urut":27,"Nama":"WULAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":27,"Urut":29,"Nama":"FERDI (Pak Kartalim)","BERAT":1.5,"BUNGKUS":0.0,"KP":"F","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":28,"Urut":28,"Nama":"PARKIR YASMIN","BERAT":1.0,"BUNGKUS":4.0,"KP":"G","KETERANGAN":null,"Tahun":2020,"Jenis":6,"SudahSiap":false,"SudahDiterima":false}],"DataHewanQurban":[{"Id":1,"No":1,"Pemilik":"P DIDIK","Bruto":455.0,"Netto":136.5,"PersenNet":0.3,"KepalaSapi":"P DIDIK","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":2,"No":2,"Pemilik":"P EKO","Bruto":600.0,"Netto":150.0,"PersenNet":0.25,"KepalaSapi":"P EKO","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":3,"No":3,"Pemilik":"P RUBIYO","Bruto":400.0,"Netto":100.0,"PersenNet":0.25,"KepalaSapi":"P RUBIYO","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":4,"No":4,"Pemilik":"BER 10 RAMA","Bruto":600.0,"Netto":150.0,"PersenNet":0.25,"KepalaSapi":"BU SARAH","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":5,"No":5,"Pemilik":"KLP P BAYU","Bruto":500.0,"Netto":125.0,"PersenNet":0.25,"KepalaSapi":"P BAYU","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":6,"No":6,"Pemilik":"KLP P IQBAL","Bruto":800.0,"Netto":200.0,"PersenNet":0.25,"KepalaSapi":"P IQBAL","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":7,"No":7,"Pemilik":"KLP PAK PUTRA","Bruto":520.0,"Netto":130.0,"PersenNet":0.25,"KepalaSapi":"P PUTRA","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":8,"No":8,"Pemilik":"KLP JAMAAH ALDI","Bruto":600.0,"Netto":150.0,"PersenNet":0.25,"KepalaSapi":"P KARTA","Tahun":2020,"Jenis":0,"DataPembagians":null},{"Id":9,"No":9,"Pemilik":"BER 7 DANI","Bruto":470.0,"Netto":117.5,"PersenNet":0.25,"KepalaSapi":"P YUSUF","Tahun":2020,"Jenis":0,"DataPembagians":null}],"Pembagian":[{"Id":1,"KK":"AKK001","Nama":"Nina Herlina","Status":"KK","Golongan":"1","KP":"A","Pembagian":10.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":2,"KK":"AKK002","Nama":"Adi Imam Rusdi","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":3,"KK":"AKK002","Nama":"Ratna Fitria","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":4,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Status":"KK","Golongan":"2","KP":"B","Pembagian":4.0,"BL":8.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL8","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":5,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Status":"CUCU","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":6,"KK":"AKK006","Nama":"Abdul Aziz Setiyawan","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":7,"KK":"AKK006","Nama":"Annisa Ayu Rizky","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":8,"KK":"AKK007","Nama":"Arpita Zafarina Haesah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":9,"KK":"AKK007","Nama":"Arseno","Status":"KK","Golongan":"3","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":10,"KK":"AKK007","Nama":"Kalandra Auriga Al fatih","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":11,"KK":"AKK008","Nama":"Abu Dhohir","Status":"KK","Golongan":"1","KP":"A","Pembagian":10.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":12,"KK":"AKK033","Nama":"Icha (Andi)","Status":"KK","Golongan":"1","KP":"A","Pembagian":10.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":13,"KK":"AKK049","Nama":"Adinda","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":14,"KK":"AKK049","Nama":"Aldira Bagus Aziz","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":15,"KK":"AKK049","Nama":"Muhammad Abidzar Mansyurin Alfirdaus","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":16,"KK":"AKK049","Nama":"Muhammad Azza Maher Alghifari","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":17,"KK":"BKK009","Nama":"Adine Sainandira Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":18,"KK":"BKK009","Nama":"Bayubadra Megaranda","Status":"KK","Golongan":"5","KP":"C","Pembagian":13.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":19,"KK":"BKK009","Nama":"Calisha Nayundari Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":20,"KK":"BKK009","Nama":"Dian Ary Kusumah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":21,"KK":"BKK009","Nama":"Elfrina Sazradiba Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":22,"KK":"CKK010","Nama":"Choirul Sufianto","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":23,"KK":"CKK010","Nama":"Lulu Vivi Nurdina","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":24,"KK":"CKK010","Nama":"Sabia Azza Asyifa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":25,"KK":"CKK010","Nama":"Sahila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":26,"KK":"DKK011","Nama":"Dani Jaya Sukmana","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":27,"KK":"DKK011","Nama":"Irsyad Pasha Aliza Sukmana","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":28,"KK":"DKK011","Nama":"Mellyza","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":29,"KK":"DKK011","Nama":"Rasyid Pasha Aliza Sukmana","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":30,"KK":"DKK012","Nama":"Aisyah Azzahra","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":31,"KK":"DKK012","Nama":"Aulia Syifa Madani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":32,"KK":"DKK012","Nama":"Didik Susilo Widianto","Status":"KK","Golongan":"9","KP":"D","Pembagian":14.5,"BL":18.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":3,"Kantong":"BL18","SudahSiap":false,"SudahDiterima":false,"Sapi":"P DIDIK","HewanQurban":null},{"Id":33,"KK":"DKK012","Nama":"Fatimah Khairunnisa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":34,"KK":"DKK012","Nama":"Nauval Abdurrahman","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":35,"KK":"DKK012","Nama":"Nurul Khodijah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":36,"KK":"DKK012","Nama":"Panji","Status":"KEPONAKAN","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":37,"KK":"DKK012","Nama":"Reben","Status":"IBU","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":8,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":38,"KK":"DKK012","Nama":"Yatin","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":9,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":39,"KK":"DKK013","Nama":"Doddy","Status":"KK","Golongan":"3","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":40,"KK":"DKK013","Nama":"Risti Diana Putri","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":41,"KK":"DKK013","Nama":"Rizqiana Safa Khaira","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":42,"KK":"DKK014","Nama":"Bellyza Bilqissari","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":43,"KK":"DKK014","Nama":"Dewi Trinanda","Status":"KK","Golongan":"3","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":44,"KK":"DKK014","Nama":"Faizal Abdul Aziz","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":45,"KK":"DKK015","Nama":"Abiyyu Nara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":46,"KK":"DKK015","Nama":"Dyah (Dhea) Pitaloka","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":47,"KK":"DKK015","Nama":"Repal","Status":"KK","Golongan":"3","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":48,"KK":"DKK016","Nama":"Dediwanto","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":49,"KK":"DKK016","Nama":"Jayyan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":50,"KK":"DKK016","Nama":"Jiah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":51,"KK":"DKK016","Nama":"Jidan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":52,"KK":"EKK017","Nama":"Eko Nursusanto","Status":"KK","Golongan":"6","KP":"D","Pembagian":13.0,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P EKO","HewanQurban":null},{"Id":53,"KK":"EKK017","Nama":"Farah Wahyuningtyas","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":54,"KK":"EKK017","Nama":"Hafidz Nurhantoko","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":55,"KK":"EKK017","Nama":"Mira Ekasari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":56,"KK":"EKK017","Nama":"Sarah Pramiarsih","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":57,"KK":"EKK017","Nama":"Zahra Fadhilah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":58,"KK":"EKK018","Nama":"Budi Nuryanto","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":59,"KK":"EKK018","Nama":"Dimas Daud Probokusumo","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":60,"KK":"EKK018","Nama":"Euis Hartati","Status":"KK","Golongan":"3","KP":"B","Pembagian":11.5,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":61,"KK":"EKK019","Nama":"Ernanto","Status":"KK","Golongan":"5","KP":"C","Pembagian":13.0,"BL":7.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":62,"KK":"EKK019","Nama":"Nadine Alika","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":63,"KK":"EKK019","Nama":"Salma Renata","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":64,"KK":"EKK019","Nama":"Sri Wahyuni","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":65,"KK":"EKK019","Nama":"Val Aqsha Dirgantara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":66,"KK":"HKK020","Nama":"Hamsyah Munir","Status":"JM","Golongan":"3","KP":"B","Pembagian":5.5,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":67,"KK":"HKK020","Nama":"Ina Winopratiwi","Status":"ISTRI","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":68,"KK":"HKK020","Nama":"Kemal Aimy Alfarizqi Lubis","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":69,"KK":"HKK020","Nama":"Khaira Aimy Nadra","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":70,"KK":"HKK020","Nama":"Khanza Ainy Belva","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":71,"KK":"HKK021","Nama":"Dina Safita","Status":"ISTRI","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":72,"KK":"HKK021","Nama":"Haryo Radityo","Status":"KK","Golongan":"1","KP":"A","Pembagian":11.5,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":73,"KK":"HKK021","Nama":"Mikail Abdulkarim","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":74,"KK":"HKK021","Nama":"Setyowati","Status":"MERTUA","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":75,"KK":"HKK022","Nama":"Arsyla Sahnum Dwi Putri","Status":"ANAK","Golongan":"2","KP":"B","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":76,"KK":"HKK022","Nama":"Danil Yoga Bertoni","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":77,"KK":"HKK022","Nama":"Faditilan Ramadan Putra Perdana","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":78,"KK":"HKK022","Nama":"Hardono Idris","Status":"KK","Golongan":"1","KP":"A","Pembagian":10.0,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":79,"KK":"HKK022","Nama":"Novi Ris Indarti","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":80,"KK":"HKK022","Nama":"Rezha Putra Perdana","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":81,"KK":"HKK022","Nama":"Siti Hadijah","Status":"ISTRI","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":82,"KK":"HKK022","Nama":"Tri Yulia Hartini","Status":"ANAK","Golongan":"2","KP":"B","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":8,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":83,"KK":"HKK023","Nama":"Emir Abdillah Anindra","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":84,"KK":"HKK023","Nama":"Hafiz Abdulaziz Anindra","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":85,"KK":"HKK023","Nama":"Hendro Pritianto","Status":"KK","Golongan":"1","KP":"A","Pembagian":13.0,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":3,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":86,"KK":"HKK023","Nama":"Latifa Nidaul Hayati","Status":"ISTRI","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":87,"KK":"HKK023","Nama":"Ratu Shalicha Anindra","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":88,"KK":"HKK024","Nama":"Heryana","Status":"KK","Golongan":"1","KP":"A","Pembagian":10.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":89,"KK":"IKK025","Nama":"Amanda PP ","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":90,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":91,"KK":"IKK025","Nama":"Ibn Fadhil","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":8.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":3,"Kantong":"BL8","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":92,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":93,"KK":"IKK026","Nama":"alm Faizal A","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":94,"KK":"IKK026","Nama":"alm Zismal A","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":95,"KK":"IKK026","Nama":"Azka N","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":96,"KK":"IKK026","Nama":"Gilang M","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":97,"KK":"IKK026","Nama":"Imelda","Status":"KK","Golongan":"7","KP":"D","Pembagian":11.5,"BL":7.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":98,"KK":"IKK026","Nama":"Livia S","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":99,"KK":"IKK026","Nama":"Nayra","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":100,"KK":"JKK027","Nama":"Aldoni Bagus Akbar","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":101,"KK":"JKK027","Nama":"Alfin Bagus Aris","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":102,"KK":"JKK027","Nama":"Jaka Suryana","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":18.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":3,"Kantong":"BL18","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":103,"KK":"JKK027","Nama":"Yanti Nuryanti","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":104,"KK":"JKK028","Nama":"Ade Darni","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":105,"KK":"JKK028","Nama":"Jodi Mangun Raharjo","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":106,"KK":"JKK028","Nama":"Shafa Hafizah Jody","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":107,"KK":"JKK028","Nama":"Zalfa Jacinda Jody","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":108,"KK":"KKK029","Nama":"Aril Janura Reinold","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":109,"KK":"KKK029","Nama":"Kartalim","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":110,"KK":"KKK029","Nama":"Kevin Arisandi","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":111,"KK":"KKK029","Nama":"Nurchamidah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":112,"KK":"MKK030","Nama":"Bima Danu Kusumah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":113,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":9.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":114,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":115,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":116,"KK":"MKK031","Nama":"Makmur","Status":"KK","Golongan":"5","KP":"C","Pembagian":13.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":117,"KK":"MKK031","Nama":"Mida","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":118,"KK":"MKK031","Nama":"Muhammad Dzickry","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":119,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":120,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":121,"KK":"MKK032","Nama":"Amasya Luthfia Zara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":122,"KK":"MKK032","Nama":"Azeeva Medina Zahraina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":123,"KK":"MKK032","Nama":"Mochamad Iqbal","Status":"KK","Golongan":"5","KP":"C","Pembagian":13.0,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":3,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":124,"KK":"MKK032","Nama":"Zafran Akbar Assidiq","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":125,"KK":"MKK032","Nama":"Zuria Vidya Nindita","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":126,"KK":"NKK034","Nama":"Hafidam Haidar","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":127,"KK":"NKK034","Nama":"Naniek Rahmawati (Suherman)","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":128,"KK":"PKK035","Nama":"Putra Nugraha Satria Utama","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":129,"KK":"PKK035","Nama":"Rajaska Rega Yanova","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":130,"KK":"PKK035","Nama":"Rajendra King Malique Ibrahim","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":131,"KK":"PKK035","Nama":"Resi Meitrisuri","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":132,"KK":"RKK036","Nama":"Geenan Radhian az Zahid","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":133,"KK":"RKK036","Nama":"Intan Kusuma Wijaya","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":134,"KK":"RKK036","Nama":"Ramadhan Hidayaturrahman","Status":"KK","Golongan":"3","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":135,"KK":"RKK037","Nama":"Rachmat Irawan","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":136,"KK":"RKK037","Nama":"Ulfa Agustiana","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":137,"KK":"RKK038","Nama":"Daksa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":138,"KK":"RKK038","Nama":"Dhimas Upandyandaru Satrio","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":139,"KK":"RKK038","Nama":"Endang Mufrihati","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":140,"KK":"RKK038","Nama":"Fariha Adellia Virgiandaru","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":141,"KK":"RKK038","Nama":"Fitiandaru Azzalia Nurfarina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":142,"KK":"RKK038","Nama":"Rubiyo","Status":"KK","Golongan":"6","KP":"D","Pembagian":14.5,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":6,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P RUBIYO","HewanQurban":null},{"Id":143,"KK":"SKK039","Nama":"M Prayoga Aji Nugraha","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":144,"KK":"SKK039","Nama":"Siti Sarah","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":145,"KK":"SKK040","Nama":"M Sakti Putra Manggala","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":146,"KK":"SKK040","Nama":"Ratih Unjunan Sari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":147,"KK":"SKK040","Nama":"Sakha","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":148,"KK":"SKK040","Nama":"Satria Manggala","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":149,"KK":"SKK041","Nama":"Amelia Nurfajrina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":150,"KK":"SKK041","Nama":"Ati Mustiati","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":151,"KK":"SKK041","Nama":"Inez Fajriannisa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":152,"KK":"SKK041","Nama":"M. Farrel SA","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":153,"KK":"SKK041","Nama":"Rizka Dyanira H.","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":154,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Status":"KK","Golongan":"7","KP":"D","Pembagian":14.5,"BL":7.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":6,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":155,"KK":"SKK041","Nama":"Tiara Syahriani Putri","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":156,"KK":"SKK042","Nama":"Almaria Zalfa Berly Nadifa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":157,"KK":"SKK042","Nama":"Dewi A","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":158,"KK":"SKK042","Nama":"Sulthon","Status":"KK","Golongan":"3","KP":"B","Pembagian":13.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":3,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":159,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":160,"KK":"TKK043","Nama":"Tenny Supartini","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":161,"KK":"WKK044","Nama":"Callysta Fathia Mikaila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":162,"KK":"WKK044","Nama":"Erlita Purnamasari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":163,"KK":"WKK044","Nama":"Keyshilla Namira","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":164,"KK":"WKK044","Nama":"Wira Mandrasetia","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":165,"KK":"WKK045","Nama":"Agam Bhaskoro","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":166,"KK":"WKK045","Nama":"Wiwik Hartatik","Status":"KK","Golongan":"2","KP":"B","Pembagian":10.0,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":167,"KK":"YKK046","Nama":"Fera koes Rahayu","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":168,"KK":"YKK046","Nama":"Kresna Rizki Romadhon","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":169,"KK":"YKK046","Nama":"Oscar Tirta Sugema","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":170,"KK":"YKK046","Nama":"Yogi yogaswara ","Status":"KK","Golongan":"4","KP":"C","Pembagian":13.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":4,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":171,"KK":"YKK047","Nama":"Ilyas Radhian Dzilkayis","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":172,"KK":"YKK047","Nama":"Lely Endah Kumala","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":173,"KK":"YKK047","Nama":"Shabira Zakiya Azrina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":174,"KK":"YKK047","Nama":"Yaquta Zulfatan Khairan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":175,"KK":"YKK047","Nama":"Yusup Saputra","Status":"KK","Golongan":"5","KP":"C","Pembagian":13.0,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2020,"NoUrut":5,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":176,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":177,"KK":"ZKK048","Nama":"Zaenal Abidin Masse","Status":"KK","Golongan":"2","KP":"B","Pembagian":11.5,"BL":18.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":2,"Kantong":"BL18","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":178,"KK":"ZSIMP16","Nama":"MUDA-MUDI","Status":"KK","Golongan":"1","KP":"A","Pembagian":14.5,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":14.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":179,"KK":"ZSIMP17","Nama":"Alm. Amih (bu Teny)","Status":"JM","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":180,"KK":"ZSIMP18","Nama":"Muhsin (Putra Heryana)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":181,"KK":"ZSIMP19","Nama":"Eka (lulu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":182,"KK":"ZSIMP20","Nama":"Novi (Putri Pak Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":183,"KK":"ZSIMP21","Nama":"Fadhilan (Cucu Pak Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 7 DANI","HewanQurban":null},{"Id":184,"KK":"ZSIMP23","Nama":"Sri Hastuti (Ibu Yogi)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":185,"KK":"ZSIMP24","Nama":"Giwangkara (Kakak Yogi)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":186,"KK":"ZSIMP25","Nama":"Astri (Bu Sarah)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 10 RAMA","HewanQurban":null},{"Id":187,"KK":"ZSIMP26","Nama":"Hendra (Rumania)","Status":"JM","Golongan":"2","KP":"B","Pembagian":5.5,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":188,"KK":"ZSIMP27","Nama":"Yuningsih (Mertua Wira)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":189,"KK":"ZSIMP28","Nama":"Sumantri (Mertua Wira)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":190,"KK":"ZSIMP29","Nama":"Agam Bhaskoro","Status":"JM","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":191,"KK":"ZSIMP30","Nama":"Istatik (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":192,"KK":"ZSIMP31","Nama":"Mega Puspita (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":193,"KK":"ZSIMP32","Nama":"Badri (dhohir)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":194,"KK":"ZSIMP33","Nama":"Rudi Canada","Status":"JM","Golongan":"2","KP":"B","Pembagian":5.5,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P IQBAL","HewanQurban":null},{"Id":195,"KK":"ZSIMP34","Nama":"Reza (Ibu Aisyah)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":196,"KK":"ZSIMP35","Nama":"Indra (Ibu Aisyah)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":197,"KK":"ZSIMP36","Nama":"Eka","Status":"JM","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":198,"KK":"ZSIMP37","Nama":"Mia","Status":"JM","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":199,"KK":"ZSIMP38","Nama":"Abidzar Anhar","Status":"KK","Golongan":"1","KP":"A","Pembagian":10.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null},{"Id":200,"KK":"ZSIMP39","Nama":"Anggit (Pak Karta)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2020,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP JAMAAH ALDI","HewanQurban":null}],"QtySampil":8,"BeratSampil":30.0}'),
	(3, 'qurban-2021', '{"TotalBerat":1507.0,"BeratTanpaSampil":1207.0,"TotalBeratBersih":1507.6499999999999,"Report":[{"No":"1","Uraian":"Jumlah Sapi","Jumlah":"11","Satuan":"Ekor"},{"No":"2","Uraian":"Jumlah Kambing","Jumlah":"0","Satuan":"Ekor"},{"No":"3","Uraian":"Porsi Jamaah","Jumlah":"475.00","Satuan":"Kg"},{"No":"4","Uraian":"Porsi Apresiasi Jamaah","Jumlah":"94.50","Satuan":"Kg"},{"No":"5","Uraian":"Budi Luhur Sekitar Lingkungan Jamaah","Jumlah":"313.00","Satuan":"Kg"},{"No":"6","Uraian":"Porsi (10 @ 30kg) Sampil Jamaah","Jumlah":"300.00","Satuan":"Ekor"},{"No":"7","Uraian":"Budi Luhur Pejabat","Jumlah":"53.00","Satuan":"Kg"},{"No":"8","Uraian":"Budi Luhur Jamaah","Jumlah":"8.00","Satuan":"Kg"},{"No":"9","Uraian":"Budi Luhur Warga","Jumlah":"115.50","Satuan":"Kg"},{"No":"10","Uraian":"Budi Luhur Keamanan","Jumlah":"9.00","Satuan":"Kg"},{"No":"11","Uraian":"Budi Luhur Desa","Jumlah":"100.00","Satuan":"Kg"},{"No":"12","Uraian":"Budi Luhur Lainnya","Jumlah":"39.00","Satuan":"Kg"}],"Info":null,"BL":[{"Id":0,"Urut":1,"Nama":"PEJABAT KEL.","BERAT":2.0,"BUNGKUS":5.0,"KP":"E","KETERANGAN":"BU DIDIK, P SATRIA","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":2,"Nama":"PA HERI  PURNOMO","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"KHOIRUL","Tahun":2021,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":3,"Nama":"PA HAMZAH","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"KHOIRUL","Tahun":2021,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":4,"Nama":"BU AZIZ","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"BU DIDIK","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":5,"Nama":"BU DANI","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"BU DIDIK","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":6,"Nama":"BU RANI","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"BU DIDIK","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":7,"Nama":"TETEH AISYAH","BERAT":2.0,"BUNGKUS":1.0,"KP":"E","KETERANGAN":"BU DIDIK","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":8,"Nama":"PEJABAT KORAMIL","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":9,"Nama":"PEJABAT POLSEK","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":10,"Nama":"PEJABAT BABINSA & BABINMAS","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":11,"Nama":"SATPAM OSCAR / KANTOR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2021,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":12,"Nama":"SATPAM BAR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2021,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":13,"Nama":"WAWAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":14,"Nama":"TRISNO","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":15,"Nama":"GUNARDI","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":16,"Nama":"SULAIMAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":17,"Nama":"INAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":18,"Nama":"GUNTUR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":19,"Nama":"TUKANG TENDA","BERAT":1.0,"BUNGKUS":4.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":20,"Nama":"JAGAL","BERAT":1.0,"BUNGKUS":20.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":21,"Nama":"GALI SUMUR","BERAT":1.0,"BUNGKUS":2.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":22,"Nama":"DESA BUDI AGUNG1 0.5 Kg","BERAT":0.5,"BUNGKUS":200.0,"KP":"H","KETERANGAN":"KHOIRUL","Tahun":2021,"Jenis":0,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":23,"Nama":"CADANGAN","BERAT":1.5,"BUNGKUS":25.0,"KP":"F","KETERANGAN":null,"Tahun":2021,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":24,"Nama":"NINING","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"BU SARAH","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":25,"Nama":"SATPAM CENGKEH","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2021,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":26,"Nama":"BL SEKITAR OSCAR","BERAT":1.0,"BUNGKUS":65.0,"KP":"G","KETERANGAN":"ALDO, YUSUP, NOVAL","Tahun":2021,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":27,"Nama":"RT / RW","BERAT":2.0,"BUNGKUS":5.0,"KP":"E","KETERANGAN":"P SATRIA ","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":28,"Nama":"TAMBAL BAN","BERAT":1.5,"BUNGKUS":1.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2021,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":0,"Urut":29,"Nama":"DESA BUDI AGUNG1 2 Kg","BERAT":2.0,"BUNGKUS":10.0,"KP":"E","KETERANGAN":"KHOIRUL","Tahun":2021,"Jenis":2,"SudahSiap":false,"SudahDiterima":false}],"DataHewanQurban":[{"Id":0,"No":1,"Pemilik":"P DIDIK","Bruto":607.0,"Netto":151.75,"PersenNet":0.25,"KepalaSapi":"P DIDIK","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"LM/148","DataPembagians":null},{"Id":0,"No":2,"Pemilik":"P EKO","Bruto":950.0,"Netto":237.5,"PersenNet":0.25,"KepalaSapi":"P EKO","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"-","DataPembagians":null},{"Id":0,"No":3,"Pemilik":"P RUBIYO","Bruto":300.0,"Netto":90.0,"PersenNet":0.3,"KepalaSapi":"P RUBIYO","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"-","DataPembagians":null},{"Id":0,"No":4,"Pemilik":"BER 9","Bruto":512.0,"Netto":153.6,"PersenNet":0.3,"KepalaSapi":"P HENDRO","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"BL240","DataPembagians":null},{"Id":0,"No":5,"Pemilik":"KLP P BAYU","Bruto":630.0,"Netto":157.5,"PersenNet":0.25,"KepalaSapi":"P BAYU","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"-","DataPembagians":null},{"Id":0,"No":6,"Pemilik":"P FADHIL","Bruto":490.0,"Netto":122.5,"PersenNet":0.25,"KepalaSapi":"P FADHIL","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"-","DataPembagians":null},{"Id":0,"No":7,"Pemilik":"KLP PAK PUTRA","Bruto":500.0,"Netto":125.0,"PersenNet":0.25,"KepalaSapi":"P PUTRA","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"-","DataPembagians":null},{"Id":0,"No":8,"Pemilik":"KELOMPOK","Bruto":600.0,"Netto":150.0,"PersenNet":0.25,"KepalaSapi":"BU SARAH","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"LM37","DataPembagians":null},{"Id":0,"No":9,"Pemilik":"BU JAKA","Bruto":297.0,"Netto":89.1,"PersenNet":0.3,"KepalaSapi":"BU JAKA","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"P251","DataPembagians":null},{"Id":0,"No":10,"Pemilik":"P HARDONO","Bruto":423.0,"Netto":126.89999999999999,"PersenNet":0.3,"KepalaSapi":"P HARDONO","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"BL198","DataPembagians":null},{"Id":0,"No":11,"Pemilik":"P ZAINAL","Bruto":346.0,"Netto":103.8,"PersenNet":0.3,"KepalaSapi":"P ZAINAL","Tahun":2021,"NoUrutPotong":0,"Jenis":0,"Keterangan":"BL172","DataPembagians":null}],"Pembagian":[{"Id":0,"KK":"AKK001","Nama":"Nina Herlina","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"AKK002","Nama":"Adi Imam Rusdi","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"AKK002","Nama":"Ratna Fitria","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":8.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL8","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Status":"CUCU","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK007","Nama":"Arpita Zafarina Haesah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK007","Nama":"Arseno","Status":"KK","Golongan":"3","KP":"C","Pembagian":8.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"AKK007","Nama":"Kalandra Auriga Al fatih","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK008","Nama":"Abu Dhohir","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"AKK033","Nama":"Icha (Andi)","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"AKK049","Nama":"Adinda","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK049","Nama":"Aldira Bagus Aziz","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BU JAKA","HewanQurban":null},{"Id":0,"KK":"AKK049","Nama":"Muhammad Abidzar Mansyurin Alfirdaus","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK049","Nama":"Muhammad Azza Maher Alghifari","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"AKK050","Nama":"Abidzar Anhar","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"BKK009","Nama":"Adine Sainandira Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"BKK009","Nama":"Bayubadra Megaranda","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":7.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":2,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":0,"KK":"BKK009","Nama":"Calisha Nayundari Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"BKK009","Nama":"Dian Ary Kusumah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"BKK009","Nama":"Elfrina Sazradiba Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"BKK010","Nama":"Bima Danu Kusumah","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"BKK010","Nama":"Eka Sri Rahayu","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"CKK010","Nama":"Choirul Sufianto","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"CKK010","Nama":"Lulu Vivi Nurdina","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"CKK010","Nama":"Sabia Azza Asyifa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"CKK010","Nama":"Sahila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK011","Nama":"Dani Jaya Sukmana","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"DKK011","Nama":"Irsyad Pasha Aliza Sukmana","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK011","Nama":"Mellyza","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK011","Nama":"Rasyid Pasha Aliza Sukmana","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Aisyah Azzahra","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Aulia Syifa Madani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Didik Susilo Widianto","Status":"KK","Golongan":"8","KP":"E","Pembagian":10.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":3,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P DIDIK","HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Nauval Abdurrahman","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Nurul Khodijah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Panji","Status":"KEPONAKAN","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Reben","Status":"IBU","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":8,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK012","Nama":"Yatin","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":9,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK013","Nama":"Doddy","Status":"KK","Golongan":"3","KP":"C","Pembagian":8.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"DKK013","Nama":"Risti Diana Putri","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK013","Nama":"Rizqiana Safa Khaira","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK014","Nama":"Dewi Trinanda","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"DKK014","Nama":"Faizal Abdul Aziz","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK015","Nama":"Abiyyu Nara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK015","Nama":"Dyah (Dhea) Pitaloka","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK015","Nama":"Repal","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":3,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"DKK015","Nama":"Adara Naura","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK016","Nama":"Dediwanto","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"DKK016","Nama":"Jayyan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK016","Nama":"Jiah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"DKK016","Nama":"Jidan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK017","Nama":"Eko Nursusanto","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P EKO","HewanQurban":null},{"Id":0,"KK":"EKK017","Nama":"Farah Wahyuningtyas","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK017","Nama":"Hafidz Nurhantoko","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK017","Nama":"Mira Ekasari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK017","Nama":"Zahra Fadhilah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK018","Nama":"Euis Hartati","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":0,"KK":"EKK018","Nama":"Dimas Daud Probokusumo","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK019","Nama":"Ernanto","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":7.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"EKK019","Nama":"Nadine Alika","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK019","Nama":"Salma Renata","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK019","Nama":"Sri Wahyuni","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"EKK019","Nama":"Val Aqsha Dirgantara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK021","Nama":"Dina Safita","Status":"ISTRI","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK021","Nama":"Haryo Radityo","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"HKK021","Nama":"Mikail Abdulkarim","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK021","Nama":"Setyowati","Status":"SIMP","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK022","Nama":"Hardono Idris","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":4,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"HKK023","Nama":"Emir Abdillah Anindra","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK023","Nama":"Hafiz Abdulaziz Anindra","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK023","Nama":"Hendro Pritianto","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":3,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"HKK023","Nama":"Latifa Nidaul Hayati","Status":"ISTRI","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"HKK023","Nama":"Ratu Shalicha Anindra","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK025","Nama":"Amanda PP ","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK025","Nama":"Ibn Fadhil","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":3,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P FADHIL","HewanQurban":null},{"Id":0,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK026","Nama":"Azka N","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK026","Nama":"Gilang M","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK026","Nama":"Imelda","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"IKK026","Nama":"Livia S","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"IKK026","Nama":"Nayra","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"JKK027","Nama":"Aldoni Bagus Akbar","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"JKK027","Nama":"Alfin Bagus Aris","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"JKK027","Nama":"Yanti Nuryanti","Status":"KK","Golongan":"3","KP":"C","Pembagian":8.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":4,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"BU JAKA","HewanQurban":null},{"Id":0,"KK":"JKK028","Nama":"Ade Darni","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"JKK028","Nama":"Jodi Mangun Raharjo","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"JKK028","Nama":"Shafa Hafizah Jody","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"JKK028","Nama":"Zalfa Jacinda Jody","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"KKK029","Nama":"Aril Janura Reinold","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"KKK029","Nama":"Kartalim","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"KKK029","Nama":"Kevin Arisandi","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"KKK029","Nama":"Nurchamidah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK030","Nama":"Budi Nuryanto","Status":"SUAMI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":9.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":2,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK031","Nama":"Makmur","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"MKK031","Nama":"Mida","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK031","Nama":"Muhammad Dzickry","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"MKK032","Nama":"MUDA-MUDI","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"NKK034","Nama":"Hafidam Haidar","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"NKK034","Nama":"Naniek Rahmawati (Suherman)","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"PKK035","Nama":"Putra Nugraha Satria Utama","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":7.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"PKK035","Nama":"Rajaska Rega Yanova","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"PKK035","Nama":"Rajendra King Malique Ibrahim","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"PKK035","Nama":"Resi Meitrisuri","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK036","Nama":"Geenan Radhian az Zahid","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK036","Nama":"Intan Kusuma Wijaya","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK036","Nama":"Ramadhan Hidayaturrahman","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":3,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"RKK036","Nama":"Indah","Status":"KEPONAKAN","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK037","Nama":"Rachmat Irawan","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"RKK037","Nama":"Ulfa Agustiana","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK038","Nama":"Daksa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK038","Nama":"Dhimas Upandyandaru Satrio","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK038","Nama":"Endang Mufrihati","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK038","Nama":"Fariha Adellia Virgiandaru","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK038","Nama":"Fitiandaru Azzalia Nurfarina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"RKK038","Nama":"Rubiyo","Status":"KK","Golongan":"6","KP":"E","Pembagian":10.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":6,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P RUBIYO","HewanQurban":null},{"Id":0,"KK":"SKK039","Nama":"M Prayoga Aji Nugraha","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK039","Nama":"Siti Sarah","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":10.0,"KAKI":0.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"SKK040","Nama":"M Sakti Putra Manggala","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK040","Nama":"Ratih Unjunan Sari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK040","Nama":"Sakha","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK040","Nama":"Satria Manggala","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":4,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"SKK041","Nama":"Inez Fajriannisa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK041","Nama":"M. Farrel SA","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK041","Nama":"Rizka Dyanira H.","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":5.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"SKK041","Nama":"Tiara Syahriani Putri","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"TKK043","Nama":"Tenny Supartini","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":10.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":0,"KK":"WKK044","Nama":"Callysta Fathia Mikaila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"WKK044","Nama":"Erlita Purnamasari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"WKK044","Nama":"Keyshilla Namira","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"WKK044","Nama":"Wira Mandrasetia","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":5.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"BL5","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"WKK045","Nama":"Wiwik Hartatik","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":0,"KK":"YKK046","Nama":"Fera koes Rahayu","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK046","Nama":"Kresna Rizki Romadhon","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK046","Nama":"Oscar Tirta Sugema","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK046","Nama":"Yogi yogaswara ","Status":"KK","Golongan":"4","KP":"D","Pembagian":9.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":4,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"YKK047","Nama":"Ilyas Radhian Dzilkayis","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK047","Nama":"Lely Endah Kumala","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK047","Nama":"Shabira Zakiya Azrina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK047","Nama":"Yaquta Zulfatan Khairan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK047","Nama":"Arba Mafaza Kaysan","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"YKK047","Nama":"Yusup Saputra","Status":"KK","Golongan":"6","KP":"E","Pembagian":10.0,"BL":10.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":6,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"YKK0ZZ","Nama":"WIKA M.","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":2.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2021,"NoUrut":1,"Kantong":"BL2","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"ZKK048","Nama":"Zaenal Abidin Masse","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":10.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"BL10","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":0,"KK":"ZSIMP01","Nama":"Alm. Amih (bu Teny)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP02","Nama":"Heru","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP03","Nama":"ANDRI (HARDONO)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP04","Nama":"Sri Hastuti (Ibu Yogi)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP05","Nama":"Aida","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP06","Nama":"MAAS (Putra)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"ZSIMP07","Nama":"ANDRI (WIRA)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"ZSIMP08","Nama":"Istatik (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":0,"KK":"ZSIMP09","Nama":"Rudi Canada","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":0,"KK":"ZSIMP10","Nama":"Eka (TAHU)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP11","Nama":"Mia (DIMAS)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP12","Nama":"Anggit ","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"ZSIMP13","Nama":"dr Olla","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":0,"KK":"ZSIMP14","Nama":"Amasya Luthfia Zara (Iqbal)","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"ZSIMP14","Nama":"Azeeva Medina Zahraina (Iqbal)","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"ZSIMP14","Nama":"Mochamad Iqbal","Status":"SIMP","Golongan":"3","KP":"C","Pembagian":8.0,"BL":7.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":0,"KK":"ZSIMP14","Nama":"Zafran Akbar Assidiq (Iqbal)","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"ZSIMP14","Nama":"Zuria Vidya Nindita (Iqbal)","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":0,"KK":"ZSIMP15","Nama":"Sumantri (Mertua Wira)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":0,"KK":"ZSIMP16","Nama":"HARIZ (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":0,"KK":"ZSIMP17","Nama":"Mega Puspita (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":0,"KK":"ZSIMP18","Nama":"SAKINAH (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":0,"KK":"ZSIMP19","Nama":"Arsyla Sahnum Dwi Putri (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP20","Nama":"Agam Bhaskoro (Wiwik)","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":0,"KK":"ZSIMP21","Nama":"Danil Yoga Bertoni (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP22","Nama":"Faditilan Ramadan Putra Perdana (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP23","Nama":"Novi Ris Indarti (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP24","Nama":"Rezha Putra Perdana (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP25","Nama":"Siti Hadijah (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":0,"KK":"ZSIMP26","Nama":"Tri Yulia Hartini (Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2021,"NoUrut":8,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null}],"QtySampil":10,"BeratSampil":30.0}'),
	(4, 'zakatfitrah-2022', '{"HargaJualBeras":30000,"PembagianDetail":[{"No":1,"TotalPembagian":116.0,"TotalBerasDijual":70.0,"TotalBerasSisa":46.000000000000014,"TotalBerasSisaSebelumnya":0.0,"TotalUang":2800000.0,"Detail":[{"Nama":"SB","Terima":46.400000000000006,"Dijual":46.0,"Sisa":0.4000000000000057,"SisaSebelumnya":0.0,"Uang":1840000.0,"DibeliOleh":[{"Id":6314,"NoUrut":2,"KK":"AKK001","Nama":"Anisa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6193,"NoUrut":1,"KK":"AKK001","Nama":"Nina Herlina","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6317,"NoUrut":1,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6319,"NoUrut":3,"KK":"AKK003","Nama":"Handika Wira Ramadhan","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6318,"NoUrut":2,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6320,"NoUrut":1,"KK":"AKK008","Nama":"Abu Dhohir","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6330,"NoUrut":3,"KK":"BKK010","Nama":"Arjuna Faeyza Shaquell","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6328,"NoUrut":1,"KK":"BKK010","Nama":"Bima Danu Kusumah","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6329,"NoUrut":2,"KK":"BKK010","Nama":"Eka Sri Rahayu","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6300,"NoUrut":1,"KK":"DKK013","Nama":"Doddy Rizal","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6310,"NoUrut":2,"KK":"DKK013","Nama":"Risti Diana Putri","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6301,"NoUrut":3,"KK":"DKK013","Nama":"Rizqiana Safa Khaira","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6359,"NoUrut":1,"KK":"DKK017","Nama":"Dimas Daud Probokusumo","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6337,"NoUrut":2,"KK":"DKK017","Nama":"Mia Febriani","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6366,"NoUrut":1,"KK":"EKK018","Nama":"Euis Hartati","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6349,"NoUrut":2,"KK":"IKK025","Nama":"Amanda PP ","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Fadhil","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6351,"NoUrut":4,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Fadhil","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6358,"NoUrut":1,"KK":"IKK025","Nama":"Muhammad Ibnu Fadhil","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Fadhil","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6350,"NoUrut":3,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Fadhil","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6352,"NoUrut":1,"KK":"IKK026","Nama":"Imelda Kemala Devi","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6353,"NoUrut":2,"KK":"IKK026","Nama":"Nayra Zahra Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6218,"NoUrut":2,"KK":"MKK030","Nama":"Budi Nuryanto","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6239,"NoUrut":1,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6219,"NoUrut":3,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6220,"NoUrut":4,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6221,"NoUrut":1,"KK":"MKK031","Nama":"Makmur","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6222,"NoUrut":2,"KK":"MKK031","Nama":"Mida","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6225,"NoUrut":5,"KK":"MKK031","Nama":"Muhammad Dzickry","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6224,"NoUrut":4,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6223,"NoUrut":3,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6257,"NoUrut":1,"KK":"MKK032","Nama":"mochammad falah akbar ","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6259,"NoUrut":3,"KK":"MKK032","Nama":"nachelle rafaela artavika shefala","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6258,"NoUrut":2,"KK":"MKK032","Nama":"sheilla kharisma gemilang ","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6227,"NoUrut":1,"KK":"RKK037","Nama":"Rachmat Irawan","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6216,"NoUrut":2,"KK":"RKK037","Nama":"Ulfa Agustiana","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6205,"NoUrut":4,"KK":"SKK040","Nama":"Ahmad Sakha Arkaan Manggala Putra","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6214,"NoUrut":3,"KK":"SKK040","Nama":"Mohammad Sakti Manggala Putra","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6204,"NoUrut":2,"KK":"SKK040","Nama":"Ratih Unjunan Sari","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6202,"NoUrut":1,"KK":"SKK040","Nama":"Satria Manggala","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6207,"NoUrut":2,"KK":"SKK041","Nama":"Inez Fajriannisa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6208,"NoUrut":3,"KK":"SKK041","Nama":"M. Farrel SA","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6209,"NoUrut":4,"KK":"SKK041","Nama":"Rizka Dyanira C","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6206,"NoUrut":1,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6210,"NoUrut":5,"KK":"SKK041","Nama":"Tiara Syahriani Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6212,"NoUrut":2,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6211,"NoUrut":1,"KK":"TKK043","Nama":"Tenny Supartini","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Daerah","Terima":1.16,"Dijual":1.0,"Sisa":0.15999999999999992,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":6269,"NoUrut":2,"KK":"WKK045","Nama":"Agam Bhaskoro","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Desa","Terima":2.32,"Dijual":2.0,"Sisa":0.31999999999999984,"SisaSebelumnya":0.0,"Uang":80000.0,"DibeliOleh":[{"Id":6268,"NoUrut":1,"KK":"WKK045","Nama":"Wiwik Hartatik","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6270,"NoUrut":1,"KK":"WKK046","Nama":"Wika Mahardika","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Kelompok","Terima":13.92,"Dijual":0.0,"Sisa":13.92,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Sofyan","Terima":5.4,"Dijual":5.0,"Sisa":0.40000000000000036,"SisaSebelumnya":0.0,"Uang":200000.0,"DibeliOleh":[{"Id":6284,"NoUrut":2,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6283,"NoUrut":1,"KK":"ZKK048","Nama":"Zaenal Abidin Masse","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6260,"NoUrut":1,"KK":"ZKK049","Nama":"ZDandi","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6261,"NoUrut":2,"KK":"ZKK049","Nama":"ZFitri","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6287,"NoUrut":3,"KK":"ZKK049","Nama":"ZJingga","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Dhohir","Terima":1.8,"Dijual":1.0,"Sisa":0.8,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":6383,"NoUrut":4,"KK":"ZKK049","Nama":"ZSeinna","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Dediwanto","Terima":7.2,"Dijual":7.0,"Sisa":0.20000000000000018,"SisaSebelumnya":0.0,"Uang":280000.0,"DibeliOleh":[{"Id":6244,"NoUrut":8,"KK":"ZSIMP06","Nama":"Cut Sartika","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6243,"NoUrut":7,"KK":"ZSIMP06","Nama":"Dyandra Via Dhama","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6285,"NoUrut":1,"KK":"ZSIMP06","Nama":"Hanryan Indrawira","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6264,"NoUrut":4,"KK":"ZSIMP06","Nama":"Indira Via Ramadhani","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6265,"NoUrut":2,"KK":"ZSIMP06","Nama":"Okky Windyasari","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6275,"NoUrut":3,"KK":"ZSIMP06","Nama":"Qiara Vira Putri","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6242,"NoUrut":6,"KK":"ZSIMP06","Nama":"Rio Wia Arazak","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Makmur","Terima":9.0,"Dijual":7.0,"Sisa":2.0,"SisaSebelumnya":0.0,"Uang":280000.0,"DibeliOleh":[{"Id":6251,"NoUrut":5,"KK":"ZSIMP06","Nama":"Sierra Vira Hani","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6252,"NoUrut":7,"KK":"ZSIMP08","Nama":"Abdullah Bin H. Salam","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6250,"NoUrut":6,"KK":"ZSIMP08","Nama":"Afkharrilo Angkasawira Bin Hariza Angkasawira","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6249,"NoUrut":5,"KK":"ZSIMP08","Nama":"Aghitsna Nur Farizah Binti Rizal Zulferdi","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6253,"NoUrut":9,"KK":"ZSIMP08","Nama":"Alori Nuraisyah Angkasawira","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6245,"NoUrut":1,"KK":"ZSIMP08","Nama":"Hariza Angkasa Wira Bin Burhanuddin Razak","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022},{"Id":6248,"NoUrut":4,"KK":"ZSIMP08","Nama":"Lony Novita Binti H. Abdullah","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Doddy","Terima":5.4,"Dijual":0.0,"Sisa":5.4,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Nina Herlina","Terima":1.8,"Dijual":1.0,"Sisa":0.8,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":6262,"NoUrut":8,"KK":"ZSIMP08","Nama":"Nurdiah Binti Hermansyah","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":"Hendro","DanaTalangan":0.0,"SudahZakat":false,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2022}]},{"Nama":"Adi Imam Rusdi","Terima":3.6,"Dijual":0.0,"Sisa":3.6,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Sarah","Terima":7.2,"Dijual":0.0,"Sisa":7.2,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Yanti Nuryanti","Terima":10.8,"Dijual":0.0,"Sisa":10.8,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]}]},{"No":2,"TotalPembagian":70.0,"TotalBerasDijual":0.0,"TotalBerasSisa":116.00000000000003,"TotalBerasSisaSebelumnya":46.000000000000014,"TotalUang":0.0,"Detail":[{"Nama":"SB","Terima":28.0,"Dijual":0.0,"Sisa":28.400000000000006,"SisaSebelumnya":0.4000000000000057,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Daerah","Terima":0.7000000000000001,"Dijual":0.0,"Sisa":0.86,"SisaSebelumnya":0.15999999999999992,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":1.4000000000000001,"Dijual":0.0,"Sisa":1.72,"SisaSebelumnya":0.31999999999999984,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Kelompok","Terima":8.4,"Dijual":0.0,"Sisa":22.32,"SisaSebelumnya":13.92,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Sofyan","Terima":3.2586206896551726,"Dijual":0.0,"Sisa":3.658620689655173,"SisaSebelumnya":0.40000000000000036,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Dhohir","Terima":1.0862068965517242,"Dijual":0.0,"Sisa":1.8862068965517242,"SisaSebelumnya":0.8,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Dediwanto","Terima":4.344827586206897,"Dijual":0.0,"Sisa":4.544827586206897,"SisaSebelumnya":0.20000000000000018,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Makmur","Terima":5.431034482758621,"Dijual":0.0,"Sisa":7.431034482758621,"SisaSebelumnya":2.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Doddy","Terima":3.2586206896551726,"Dijual":0.0,"Sisa":8.658620689655173,"SisaSebelumnya":5.4,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Nina Herlina","Terima":1.0862068965517242,"Dijual":0.0,"Sisa":1.8862068965517242,"SisaSebelumnya":0.8,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Adi Imam Rusdi","Terima":2.1724137931034484,"Dijual":0.0,"Sisa":5.772413793103448,"SisaSebelumnya":3.6,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Sarah","Terima":4.344827586206897,"Dijual":0.0,"Sisa":11.544827586206896,"SisaSebelumnya":7.2,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Yanti Nuryanti","Terima":6.517241379310345,"Dijual":0.0,"Sisa":17.317241379310346,"SisaSebelumnya":10.8,"Uang":0.0,"DibeliOleh":[]}]}]}'),
	(5, 'qurban-2022', '{"TotalBerat":1139.5,"BeratTanpaSampil":899.5,"TotalBeratBersih":1092.5,"Report":[{"No":"1","Uraian":"Jumlah Sapi","Jumlah":"9","Satuan":"Ekor"},{"No":"2","Uraian":"Jumlah Kambing","Jumlah":"0","Satuan":"Ekor"},{"No":"3","Uraian":"Porsi Jamaah","Jumlah":"358.00","Satuan":"Kg"},{"No":"4","Uraian":"Porsi Apresiasi Jamaah","Jumlah":"66.50","Satuan":"Kg"},{"No":"5","Uraian":"Budi Luhur Sekitar Lingkungan Jamaah","Jumlah":"255.00","Satuan":"Kg"},{"No":"6","Uraian":"Porsi (8 @ 30kg) Sampil Jamaah","Jumlah":"240.00","Satuan":"Ekor"},{"No":"7","Uraian":"Budi Luhur Pejabat","Jumlah":"27.00","Satuan":"Kg"},{"No":"8","Uraian":"Budi Luhur Jamaah","Jumlah":"8.00","Satuan":"Kg"},{"No":"9","Uraian":"Budi Luhur Warga","Jumlah":"65.00","Satuan":"Kg"},{"No":"10","Uraian":"Budi Luhur Keamanan","Jumlah":"9.00","Satuan":"Kg"},{"No":"11","Uraian":"Budi Luhur Desa","Jumlah":"100.00","Satuan":"Kg"},{"No":"12","Uraian":"Budi Luhur Lainnya","Jumlah":"11.00","Satuan":"Kg"}],"Info":{"Id":3,"Tahun":2022,"TglMulai":"2022-07-09T00:00:00","TglSelesai":"2022-07-09T00:00:00","PanitiaUrl":"https://storagemurahaje.blob.core.windows.net/ngaji-online/PanitiaQurban_11_06_2022_PANITIA-2022.png","InfoLainUrl":"https://storagemurahaje.blob.core.windows.net/ngaji-online/InfoLainQurban_11_06_2022_LAIN-2022.png"},"BL":[{"Id":317,"Urut":1,"Nama":"PEJABAT KEL.","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"BU DIDIK, P SATRIA","Tahun":2022,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":318,"Urut":2,"Nama":"PA HERI  PURNOMO","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"KHOIRUL","Tahun":2022,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":319,"Urut":3,"Nama":"PA HAMZAH","BERAT":2.0,"BUNGKUS":2.0,"KP":"E","KETERANGAN":"KHOIRUL","Tahun":2022,"Jenis":1,"SudahSiap":false,"SudahDiterima":false},{"Id":320,"Urut":4,"Nama":"BU AZIZ","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"BU DIDIK","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":321,"Urut":5,"Nama":"BU DANI","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"BU DIDIK","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":322,"Urut":6,"Nama":"BU RANI","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"BU DIDIK","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":323,"Urut":7,"Nama":"TETEH AISYAH","BERAT":1.0,"BUNGKUS":1.0,"KP":"G","KETERANGAN":"BU DIDIK","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":324,"Urut":8,"Nama":"PEJABAT KORAMIL","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":325,"Urut":9,"Nama":"PEJABAT POLSEK","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":326,"Urut":10,"Nama":"PEJABAT BABINSA & BABINMAS","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":327,"Urut":11,"Nama":"SATPAM OSCAR / KANTOR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2022,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":328,"Urut":12,"Nama":"SATPAM BAR","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2022,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":329,"Urut":13,"Nama":"WAWAN","BERAT":1.0,"BUNGKUS":1.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":330,"Urut":14,"Nama":"TRISNO","BERAT":1.0,"BUNGKUS":1.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":331,"Urut":15,"Nama":"GUNARDI","BERAT":1.0,"BUNGKUS":1.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":332,"Urut":16,"Nama":"TUKANG TENDA","BERAT":0.5,"BUNGKUS":4.0,"KP":"H","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":333,"Urut":17,"Nama":"JAGAL","BERAT":1.0,"BUNGKUS":15.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":334,"Urut":18,"Nama":"GALI SUMUR","BERAT":1.0,"BUNGKUS":2.0,"KP":"G","KETERANGAN":"AMBIL SENDIRI","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":335,"Urut":19,"Nama":"DESA BUDI AGUNG1 0.5 Kg","BERAT":0.5,"BUNGKUS":200.0,"KP":"H","KETERANGAN":"KHOIRUL","Tahun":2022,"Jenis":0,"SudahSiap":false,"SudahDiterima":false},{"Id":336,"Urut":20,"Nama":"CADANGAN","BERAT":0.5,"BUNGKUS":20.0,"KP":"H","KETERANGAN":null,"Tahun":2022,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":337,"Urut":21,"Nama":"NINING","BERAT":1.0,"BUNGKUS":2.0,"KP":"G","KETERANGAN":"BU SARAH","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":338,"Urut":22,"Nama":"SATPAM CENGKEH","BERAT":1.5,"BUNGKUS":2.0,"KP":"F","KETERANGAN":"P YUSUP, WIKA","Tahun":2022,"Jenis":3,"SudahSiap":false,"SudahDiterima":false},{"Id":339,"Urut":23,"Nama":"BL SEKITAR OSCAR","BERAT":0.5,"BUNGKUS":40.0,"KP":"H","KETERANGAN":"ALDO, YUSUP, NOVAL","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":340,"Urut":24,"Nama":"RT / RW","BERAT":2.0,"BUNGKUS":6.0,"KP":"E","KETERANGAN":"P SATRIA ","Tahun":2022,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":341,"Urut":25,"Nama":"TAMBAL BAN","BERAT":1.0,"BUNGKUS":1.0,"KP":"G","KETERANGAN":"P YUSUP, WIKA","Tahun":2022,"Jenis":6,"SudahSiap":false,"SudahDiterima":false},{"Id":342,"Urut":26,"Nama":"AIPTU SUDIRMAN","BERAT":2.0,"BUNGKUS":1.0,"KP":"E","KETERANGAN":"SATRIA","Tahun":2022,"Jenis":2,"SudahSiap":false,"SudahDiterima":false},{"Id":343,"Urut":27,"Nama":"RT 03 Dhuafa","BERAT":0.5,"BUNGKUS":20.0,"KP":"H","KETERANGAN":"SATRIA","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false},{"Id":344,"Urut":28,"Nama":"TUKANG LAS","BERAT":0.5,"BUNGKUS":2.0,"KP":"H","KETERANGAN":"ZAM","Tahun":2022,"Jenis":4,"SudahSiap":false,"SudahDiterima":false}],"DataHewanQurban":[{"Id":118,"No":1,"Pemilik":"P DIDIK","Bruto":560.0,"Netto":140.0,"PersenNet":0.25,"KepalaSapi":"P DIDIK","Tahun":2022,"NoUrutPotong":3,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":119,"No":2,"Pemilik":"P EKO","Bruto":600.0,"Netto":150.0,"PersenNet":0.25,"KepalaSapi":"P EKO","Tahun":2022,"NoUrutPotong":1,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":120,"No":3,"Pemilik":"P RUBIYO","Bruto":400.0,"Netto":80.0,"PersenNet":0.2,"KepalaSapi":"P RUBIYO","Tahun":2022,"NoUrutPotong":7,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":121,"No":4,"Pemilik":"KLP GAB LIMO","Bruto":600.0,"Netto":150.0,"PersenNet":0.25,"KepalaSapi":"Bu Sarah","Tahun":2022,"NoUrutPotong":2,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":122,"No":5,"Pemilik":"KLP P BAYU","Bruto":437.0,"Netto":109.25,"PersenNet":0.25,"KepalaSapi":"P BAYU","Tahun":2022,"NoUrutPotong":6,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":123,"No":6,"Pemilik":"KLP PAK PUTRA","Bruto":450.0,"Netto":112.5,"PersenNet":0.25,"KepalaSapi":"P PUTRA","Tahun":2022,"NoUrutPotong":5,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":124,"No":7,"Pemilik":"KLP BER 9","Bruto":515.0,"Netto":128.75,"PersenNet":0.25,"KepalaSapi":"Bu Dewi","Tahun":2022,"NoUrutPotong":4,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":125,"No":8,"Pemilik":"P Hardono","Bruto":370.0,"Netto":111.0,"PersenNet":0.3,"KepalaSapi":"P Hardono","Tahun":2022,"NoUrutPotong":8,"Jenis":0,"Keterangan":null,"DataPembagians":null},{"Id":126,"No":9,"Pemilik":"FADHIL","Bruto":370.0,"Netto":111.0,"PersenNet":0.3,"KepalaSapi":"P Zainal","Tahun":2022,"NoUrutPotong":9,"Jenis":0,"Keterangan":null,"DataPembagians":null}],"Pembagian":[{"Id":2055,"KK":"AKK001","Nama":"Nina Herlina","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2056,"KK":"AKK002","Nama":"Adi Imam Rusdi","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":4.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2057,"KK":"AKK002","Nama":"Ratna Fitria","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2058,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":7.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL7","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2059,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Status":"CUCU","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2060,"KK":"AKK033","Nama":"Icha (Andi)","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2061,"KK":"AKK050","Nama":"Abidzar Anhar","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":1.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL1","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2062,"KK":"BKK009","Nama":"Adine Sainandira Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2063,"KK":"BKK009","Nama":"Bayubadra Megaranda","Status":"KK","Golongan":"5","KP":"E","Pembagian":9.0,"BL":6.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":2,"Kantong":"BL6","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":2064,"KK":"BKK009","Nama":"Calisha Nayundari Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2065,"KK":"BKK009","Nama":"Dian Ary Kusumah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2066,"KK":"BKK009","Nama":"Elfrina Sazradiba Yoshe","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2067,"KK":"BKK010","Nama":"Bima Danu Kusumah","Status":"KK","Golongan":"3","KP":"C","Pembagian":7.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2068,"KK":"BKK010","Nama":"Eka Sri Rahayu","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2069,"KK":"BKK010","Nama":"Arjuna","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2070,"KK":"CKK010","Nama":"Choirul Sufianto","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":4.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2071,"KK":"CKK010","Nama":"Lulu Vivi Nurdina","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2072,"KK":"CKK010","Nama":"Sabia Azza Asyifa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2073,"KK":"CKK010","Nama":"Sahila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2074,"KK":"DKK011","Nama":"Dani Jaya Sukmana","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":4.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2075,"KK":"DKK011","Nama":"Irsyad Pasha Aliza Sukmana","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2076,"KK":"DKK011","Nama":"Mellyza","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2077,"KK":"DKK011","Nama":"Rasyid Pasha Aliza Sukmana","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2078,"KK":"DKK012","Nama":"Aisyah Azzahra","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2079,"KK":"DKK012","Nama":"Aulia Syifa Madani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2080,"KK":"DKK012","Nama":"Didik Susilo Widianto","Status":"KK","Golongan":"7","KP":"E","Pembagian":9.0,"BL":9.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":3,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P DIDIK","HewanQurban":null},{"Id":2081,"KK":"DKK012","Nama":"Nauval Abdurrahman","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2082,"KK":"DKK012","Nama":"Nurul Khodijah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2083,"KK":"DKK012","Nama":"Panji","Status":"KEPONAKAN","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":6,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2084,"KK":"DKK012","Nama":"Yatin","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":7,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2085,"KK":"DKK013","Nama":"Doddy","Status":"KK","Golongan":"3","KP":"C","Pembagian":7.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2086,"KK":"DKK013","Nama":"Risti Diana Putri","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2087,"KK":"DKK013","Nama":"Rizqiana Safa Khaira","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2088,"KK":"DKK014","Nama":"Dewi Trinanda","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":4.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2089,"KK":"DKK014","Nama":"Faizal Abdul Aziz","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2090,"KK":"DKK015","Nama":"Abiyyu Nara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2091,"KK":"DKK015","Nama":"Dyah (Dhea) Pitaloka","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2092,"KK":"DKK015","Nama":"Repal","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":4.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":3,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2093,"KK":"DKK015","Nama":"Adara Naura","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2094,"KK":"DKK016","Nama":"Dediwanto","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2095,"KK":"DKK016","Nama":"Jayyan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2096,"KK":"DKK016","Nama":"Jiah","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2097,"KK":"DKK016","Nama":"Jidan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2098,"KK":"EKK017","Nama":"Eko Nursusanto","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":9.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P EKO","HewanQurban":null},{"Id":2099,"KK":"EKK017","Nama":"Farah Wahyuningtyas","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2100,"KK":"EKK017","Nama":"Mira Ekasari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2101,"KK":"EKK017","Nama":"Zahra Fadhilah","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2102,"KK":"EKK018","Nama":"Euis Hartati","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":8.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"BL8","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":2103,"KK":"DKK017","Nama":"Dimas Daud Probokusumo","Status":"KK","Golongan":"2","KP":"B","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2104,"KK":"DKK017","Nama":"Mia Febyanti","Status":"ISTRI","Golongan":null,"KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2105,"KK":"EKK019","Nama":"Ernanto","Status":"KK","Golongan":"5","KP":"E","Pembagian":9.0,"BL":6.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL6","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2106,"KK":"EKK019","Nama":"Nadine Alika","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2107,"KK":"EKK019","Nama":"Salma Renata","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2108,"KK":"EKK019","Nama":"Sri Wahyuni","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2109,"KK":"EKK019","Nama":"Val Aqsha Dirgantara","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2110,"KK":"HKK021","Nama":"Dina Safita","Status":"ISTRI","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2111,"KK":"HKK021","Nama":"Haryo Radityo","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":4.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2112,"KK":"HKK021","Nama":"Mikail Abdulkarim","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2113,"KK":"HKK021","Nama":"Setyowati","Status":"MERTUA","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2114,"KK":"HKK022","Nama":"Hardono Idris","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":9.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":2115,"KK":"HKK022","Nama":"Siti Hadijah","Status":"ISTRI","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2116,"KK":"HKK023","Nama":"Emir Abdillah Anindra","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2117,"KK":"HKK023","Nama":"Hafiz Abdulaziz Anindra","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2118,"KK":"HKK023","Nama":"Hendro Pritianto","Status":"KK","Golongan":"5","KP":"E","Pembagian":9.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":7.0,"Tahun":2022,"NoUrut":3,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2119,"KK":"HKK023","Nama":"Latifa Nidaul Hayati","Status":"ISTRI","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2120,"KK":"HKK023","Nama":"Ratu Shalicha Anindra","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2121,"KK":"HKK024","Nama":"Heryana","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":4.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2122,"KK":"IKK025","Nama":"Amanda PP ","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2123,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2124,"KK":"IKK025","Nama":"Ibn Fadhil","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":3,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P FADHIL","HewanQurban":null},{"Id":2125,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2126,"KK":"JKK027","Nama":"Aldoni Bagus Akbar","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2127,"KK":"JKK027","Nama":"Alfin Bagus Aris","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2128,"KK":"JKK027","Nama":"Yanti Nuryanti","Status":"KK","Golongan":"3","KP":"C","Pembagian":7.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2129,"KK":"JKK028","Nama":"Ade Darni","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2130,"KK":"JKK028","Nama":"Jodi Mangun Raharjo","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":6.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"BL6","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2131,"KK":"JKK028","Nama":"Shafa Hafizah Jody","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2132,"KK":"JKK028","Nama":"Zalfa Jacinda Jody","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2133,"KK":"MKK030","Nama":"Budi Nuryanto","Status":"SUAMI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2134,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":8.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":2,"Kantong":"BL8","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2135,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2136,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2137,"KK":"MKK031","Nama":"Makmur","Status":"KK","Golongan":"5","KP":"E","Pembagian":9.0,"BL":6.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL6","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2138,"KK":"MKK031","Nama":"Mida","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2139,"KK":"MKK031","Nama":"Muhammad Dzickry","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2140,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2141,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2142,"KK":"MKK032","Nama":"MUDA-MUDI","Status":"KK","Golongan":"5","KP":"E","Pembagian":10.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2143,"KK":"NKK034","Nama":"Naniek Rahmawati (Suherman)","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":2144,"KK":"PKK035","Nama":"Putra Nugraha Satria Utama","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":9.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":2145,"KK":"PKK035","Nama":"Rajaska Rega Yanova","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2146,"KK":"PKK035","Nama":"Rajendra King Malique Ibrahim","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2147,"KK":"PKK035","Nama":"Resi Meitrisuri","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2148,"KK":"RKK036","Nama":"Geenan Radhian az Zahid","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2149,"KK":"RKK036","Nama":"Intan Kusuma Wijaya","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2150,"KK":"RKK036","Nama":"Ramadhan Hidayaturrahman","Status":"KK","Golongan":"6","KP":"E","Pembagian":9.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":3,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2151,"KK":"RKK036","Nama":"Indah","Status":"KEPONAKAN","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2152,"KK":"RKK036","Nama":"Imel","Status":"KEPONAKAN","Golongan":null,"KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2153,"KK":"RKK036","Nama":"Wicak","Status":"KEPONAKAN","Golongan":null,"KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":6,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2154,"KK":"RKK037","Nama":"Rachmat Irawan","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2155,"KK":"RKK037","Nama":"Ulfa Agustiana","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2156,"KK":"RKK038","Nama":"Daksa","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2157,"KK":"RKK038","Nama":"Dhimas Upandyandaru Satrio","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2158,"KK":"RKK038","Nama":"Endang Mufrihati","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2159,"KK":"RKK038","Nama":"Fariha Adellia Virgiandaru","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2160,"KK":"RKK038","Nama":"Fitiandaru Azzalia Nurfarina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2161,"KK":"RKK038","Nama":"Rubiyo","Status":"KK","Golongan":"6","KP":"E","Pembagian":9.0,"BL":9.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":6,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P RUBIYO","HewanQurban":null},{"Id":2162,"KK":"SKK039","Nama":"M Prayoga Aji Nugraha","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2163,"KK":"SKK039","Nama":"Siti Sarah","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":9.0,"KAKI":0.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":2,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2164,"KK":"SKK040","Nama":"M Sakti Putra Manggala","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2165,"KK":"SKK040","Nama":"Ratih Unjunan Sari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2166,"KK":"SKK040","Nama":"Sakha","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2167,"KK":"SKK040","Nama":"Satria Manggala","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":6.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":4,"Kantong":"BL6","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2168,"KK":"SKK041","Nama":"M. Farrel SA","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2169,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":4.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"BL4","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2170,"KK":"SKK042","Nama":"Sheila ","Status":"KK","Golongan":"2","KP":"B","Pembagian":7.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2171,"KK":"SKK042","Nama":"Fulan ","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2172,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2173,"KK":"TKK043","Nama":"Tenny Supartini","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2174,"KK":"WKK044","Nama":"Callysta Fathia Mikaila","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2175,"KK":"WKK044","Nama":"Erlita Purnamasari","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2176,"KK":"WKK044","Nama":"Keyshilla Namira","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2177,"KK":"WKK044","Nama":"Wira Mandrasetia","Status":"KK","Golongan":"6","KP":"E","Pembagian":9.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":2178,"KK":"WKK044","Nama":"Audrei","Status":"ANAK","Golongan":null,"KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2179,"KK":"WKK044","Nama":"Ikhsan","Status":"ANAK","Golongan":null,"KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":6,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2180,"KK":"WKK045","Nama":"Wiwik Hartatik","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":9.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":2181,"KK":"YKK046","Nama":"Fera koes Rahayu","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2182,"KK":"YKK046","Nama":"Kresna Rizki Romadhon","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2183,"KK":"YKK046","Nama":"Oscar Tirta Sugema","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2184,"KK":"YKK046","Nama":"Yogi yogaswara ","Status":"KK","Golongan":"4","KP":"D","Pembagian":8.0,"BL":9.0,"KAKI":1.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":4,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2185,"KK":"YKK047","Nama":"Ilyas Radhian Dzilkayis","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2186,"KK":"YKK047","Nama":"Lely Endah Kumala","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2187,"KK":"YKK047","Nama":"Shabira Zakiya Azrina","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2188,"KK":"YKK047","Nama":"Yaquta Zulfatan Khairan","Status":"ANAK","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2189,"KK":"YKK047","Nama":"Arba Mafaza Kaysan","Status":"ANAK","Golongan":"0","KP":null,"Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2190,"KK":"YKK050","Nama":"Mariana Ulfa","Status":"KK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2191,"KK":"YKK0ZZ","Nama":"WIKA M.","Status":"KK","Golongan":"1","KP":"A","Pembagian":3.0,"BL":1.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":1,"Kantong":"BL1","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2192,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Status":"ISTRI","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2193,"KK":"ZKK048","Nama":"Zaenal Abidin Masse","Status":"KK","Golongan":"2","KP":"B","Pembagian":6.0,"BL":9.0,"KAKI":1.0,"KEPALA":1.0,"TULANG":1.0,"JEROHAN":1.0,"APRESIASI":3.5,"Tahun":2022,"NoUrut":2,"Kantong":"BL9","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":2194,"KK":"ZSIMP20","Nama":"ANDRI (HARDONO)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":2195,"KK":"ZSIMP21","Nama":"Novi (Putri Pak Hardono)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":2196,"KK":"ZSIMP21","Nama":"Fadhilan (Cucu Pak Hardono)","Status":"SIMP","Golongan":"0","KP":"","Pembagian":0.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P HARDONO","HewanQurban":null},{"Id":2197,"KK":"ZSIMP24","Nama":"Aida","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KELOMPOK","HewanQurban":null},{"Id":2198,"KK":"ZSIMP27","Nama":"MAAS","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":2199,"KK":"ZSIMP28","Nama":"ANDRI (WIRA)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":2200,"KK":"ZSIMP30","Nama":"Istatik (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":2201,"KK":"ZSIMP33","Nama":"Rudi Canada","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":2202,"KK":"ZSIMP42","Nama":"Sumantri (Mertua Wira)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP PAK PUTRA","HewanQurban":null},{"Id":2203,"KK":"ZSIMP44","Nama":"Mega Puspita (Bayu)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":2204,"KK":"ZSIMP45","Nama":"Sakinah","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"KLP P BAYU","HewanQurban":null},{"Id":2205,"KK":"ZSIMP46","Nama":"Agam Bhaskoro","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"P ZAINAL","HewanQurban":null},{"Id":2206,"KK":"ZSIMP47","Nama":"Novi Ris Indarti","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2207,"KK":"ZSIMP47","Nama":"Rezha Putra Perdana","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":2,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2208,"KK":"ZSIMP47","Nama":"Arsyla Sahnum Dwi Putri","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":3,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2209,"KK":"ZSIMP47","Nama":"Danil Yoga Bertoni","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":4,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2210,"KK":"ZSIMP47","Nama":"Faditilan Ramadan Putra Perdana","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":5,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2211,"KK":"ZSIMP47","Nama":"Tri Yulia Hartini","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":6,"Kantong":null,"SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2212,"KK":"ZSIMP49","Nama":"Hafidam Haidar","Status":"ANAK","Golongan":"1","KP":"A","Pembagian":4.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":null,"HewanQurban":null},{"Id":2213,"KK":"ZSIMP50","Nama":"Rosa (Anna)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2214,"KK":"ZSIMP51","Nama":"Suyati (Dewi)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null},{"Id":2215,"KK":"ZSIMP52","Nama":"Suganda (Dewi)","Status":"SIMP","Golongan":"1","KP":"A","Pembagian":3.0,"BL":0.0,"KAKI":0.0,"KEPALA":0.0,"TULANG":0.0,"JEROHAN":0.0,"APRESIASI":0.0,"Tahun":2022,"NoUrut":1,"Kantong":"","SudahSiap":false,"SudahDiterima":false,"Sapi":"BER 9","HewanQurban":null}],"QtySampil":8,"BeratSampil":30.0}'),
	(6, 'zakatfitrah-2023', '{"HargaJualBeras":35000,"PembagianDetail":[{"No":1,"TotalPembagian":87.0,"TotalBerasDijual":69.0,"TotalBerasSisa":18.000000000000004,"TotalBerasSisaSebelumnya":0.0,"TotalUang":2760000.0,"Detail":[{"Nama":"SB","Terima":34.800000000000004,"Dijual":34.0,"Sisa":0.8000000000000043,"SisaSebelumnya":0.0,"Uang":1360000.0,"DibeliOleh":[{"Id":8354,"NoUrut":1,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8356,"NoUrut":3,"KK":"AKK003","Nama":"Handika wira ramadhan","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8355,"NoUrut":2,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8357,"NoUrut":1,"KK":"AKK009","Nama":"Adam","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8367,"NoUrut":3,"KK":"BKK010","Nama":"Arjuna Faeza Saquele","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8365,"NoUrut":1,"KK":"BKK010","Nama":"Bima Danu Kusumah","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8366,"NoUrut":2,"KK":"BKK010","Nama":"Eka Sri Rahayu","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8368,"NoUrut":1,"KK":"CKK010","Nama":"Choirul Sufianto","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8352,"NoUrut":2,"KK":"CKK010","Nama":"Lulu Vivi Nurdina","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8351,"NoUrut":3,"KK":"CKK010","Nama":"Sabia Azza Asyifa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8350,"NoUrut":4,"KK":"CKK010","Nama":"Sahila","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8399,"NoUrut":1,"KK":"DKK017","Nama":"Dimas Daud Probokusumo","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8401,"NoUrut":2,"KK":"DKK017","Nama":"Mia F","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8405,"NoUrut":1,"KK":"EKK019","Nama":"Ernanto","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8408,"NoUrut":4,"KK":"EKK019","Nama":"Nadine Alika","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8407,"NoUrut":3,"KK":"EKK019","Nama":"Salma Renata","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8406,"NoUrut":2,"KK":"EKK019","Nama":"Sri Wahyuni","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8392,"NoUrut":5,"KK":"EKK019","Nama":"Val Aqsha Dirgantara","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8376,"NoUrut":5,"KK":"HKK022","Nama":"Arsyla Sahnum Dwi Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8378,"NoUrut":7,"KK":"HKK022","Nama":"Danil Yoga Bertoni","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8375,"NoUrut":4,"KK":"HKK022","Nama":"Fadhilan Ramadan Putra Pratama","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8380,"NoUrut":1,"KK":"HKK022","Nama":"Hardono Idris","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8373,"NoUrut":2,"KK":"HKK022","Nama":"Novi Ris Indarti","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8374,"NoUrut":3,"KK":"HKK022","Nama":"Rezha Putra Perdana","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8377,"NoUrut":6,"KK":"HKK022","Nama":"Tri Yulia Hartini","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8385,"NoUrut":2,"KK":"IKK025","Nama":"Amanda PP ","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8387,"NoUrut":4,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8384,"NoUrut":1,"KK":"IKK025","Nama":"M Ibnu Fadhil","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8386,"NoUrut":3,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8280,"NoUrut":4,"KK":"MKK030","Nama":"Budi Nuryanto","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8277,"NoUrut":1,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8278,"NoUrut":2,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8279,"NoUrut":3,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8281,"NoUrut":1,"KK":"MKK031","Nama":"Makmur","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Daerah","Terima":0.87,"Dijual":0.0,"Sisa":0.87,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":1.74,"Dijual":1.0,"Sisa":0.74,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":8283,"NoUrut":2,"KK":"MKK031","Nama":"Mida","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Kelompok","Terima":10.44,"Dijual":10.0,"Sisa":0.4399999999999995,"SisaSebelumnya":0.0,"Uang":400000.0,"DibeliOleh":[{"Id":8285,"NoUrut":5,"KK":"MKK031","Nama":"Muhammad Dzickry","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8284,"NoUrut":4,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8291,"NoUrut":3,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8271,"NoUrut":1,"KK":"RKK037","Nama":"Rachmat Irawan","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8256,"NoUrut":2,"KK":"RKK037","Nama":"Ulfa Agustiana","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8269,"NoUrut":2,"KK":"SKK041","Nama":"Inez Fajriannisa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8270,"NoUrut":3,"KK":"SKK041","Nama":"M. Farrel SA","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8282,"NoUrut":4,"KK":"SKK041","Nama":"Rizka Dyanira H.","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8268,"NoUrut":1,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8293,"NoUrut":5,"KK":"SKK041","Nama":"Tiara Syahriani Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Sofyan","Terima":4.89375,"Dijual":3.0,"Sisa":1.8937499999999998,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8321,"NoUrut":1,"KK":"SKK043","Nama":"Samsi","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8314,"NoUrut":2,"KK":"SKK044","Nama":"Erza Mohammad Prima Sakti","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8317,"NoUrut":5,"KK":"SKK044","Nama":"Mohammad Falah Akbar","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Siti Sarah","Terima":3.2624999999999997,"Dijual":3.0,"Sisa":0.26249999999999973,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8316,"NoUrut":4,"KK":"SKK044","Nama":"Nachelle Rafaela Artavika Shefala","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8294,"NoUrut":1,"KK":"SKK044","Nama":"Sheilla Kharisma Gemilang","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8315,"NoUrut":3,"KK":"SKK044","Nama":"Yetti","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Dediwanto","Terima":6.5249999999999995,"Dijual":3.0,"Sisa":3.5249999999999995,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8319,"NoUrut":2,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8318,"NoUrut":1,"KK":"TKK043","Nama":"Tenny Supartini","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8328,"NoUrut":2,"KK":"WKK045","Nama":"Agam Bhaskoro","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Makmur","Terima":8.15625,"Dijual":4.0,"Sisa":4.15625,"SisaSebelumnya":0.0,"Uang":160000.0,"DibeliOleh":[{"Id":8327,"NoUrut":1,"KK":"WKK045","Nama":"Wiwik Hartatik","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8312,"NoUrut":2,"KK":"YKK046","Nama":"Fera koes Rahayu","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8310,"NoUrut":4,"KK":"YKK046","Nama":"Kresna Rizki Romadhon","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8295,"NoUrut":5,"KK":"YKK046","Nama":"M Prayoga Aji Nugraha","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Yanti Nuryanti","Terima":4.89375,"Dijual":3.0,"Sisa":1.8937499999999998,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8311,"NoUrut":3,"KK":"YKK046","Nama":"Oscar Tirta Sugema","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8313,"NoUrut":1,"KK":"YKK046","Nama":"Yogi yogaswara ","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8304,"NoUrut":2,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Adam S","Terima":3.2624999999999997,"Dijual":3.0,"Sisa":0.26249999999999973,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8303,"NoUrut":1,"KK":"ZKK048","Nama":"Zainal Abidin Masse","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8305,"NoUrut":1,"KK":"ZSIMP001","Nama":"H Abdullah","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8306,"NoUrut":2,"KK":"ZSIMP002","Nama":"Nurdiah","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Satria Manggala","Terima":6.5249999999999995,"Dijual":4.0,"Sisa":2.5249999999999995,"SisaSebelumnya":0.0,"Uang":160000.0,"DibeliOleh":[{"Id":8307,"NoUrut":3,"KK":"ZSIMP003","Nama":"Hariza Angkasa Wira","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8308,"NoUrut":4,"KK":"ZSIMP004","Nama":"Lony Novita","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8309,"NoUrut":5,"KK":"ZSIMP005","Nama":"Aghitsna Nurfarizah","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023},{"Id":8390,"NoUrut":6,"KK":"ZSIMP006","Nama":"Afkharrilo Angka Wira","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]},{"Nama":"Samsi","Terima":1.6312499999999999,"Dijual":1.0,"Sisa":0.6312499999999999,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":8410,"NoUrut":7,"KK":"ZSIMP007","Nama":"Aldri Nuraisyah Angkasa Wira","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2023}]}]},{"No":2,"TotalPembagian":69.0,"TotalBerasDijual":0.0,"TotalBerasSisa":87.0,"TotalBerasSisaSebelumnya":18.000000000000004,"TotalUang":0.0,"Detail":[{"Nama":"SB","Terima":27.6,"Dijual":0.0,"Sisa":28.400000000000006,"SisaSebelumnya":0.8000000000000043,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Daerah","Terima":0.6900000000000001,"Dijual":0.0,"Sisa":1.56,"SisaSebelumnya":0.87,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":1.3800000000000001,"Dijual":0.0,"Sisa":2.12,"SisaSebelumnya":0.74,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Kelompok","Terima":8.28,"Dijual":0.0,"Sisa":8.719999999999999,"SisaSebelumnya":0.4399999999999995,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Sofyan","Terima":3.88125,"Dijual":0.0,"Sisa":5.775,"SisaSebelumnya":1.8937499999999998,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Siti Sarah","Terima":2.5875,"Dijual":0.0,"Sisa":2.8499999999999996,"SisaSebelumnya":0.26249999999999973,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Dediwanto","Terima":5.175,"Dijual":0.0,"Sisa":8.7,"SisaSebelumnya":3.5249999999999995,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Makmur","Terima":6.46875,"Dijual":0.0,"Sisa":10.625,"SisaSebelumnya":4.15625,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Yanti Nuryanti","Terima":3.88125,"Dijual":0.0,"Sisa":5.775,"SisaSebelumnya":1.8937499999999998,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Adam S","Terima":2.5875,"Dijual":0.0,"Sisa":2.8499999999999996,"SisaSebelumnya":0.26249999999999973,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Satria Manggala","Terima":5.175,"Dijual":0.0,"Sisa":7.699999999999999,"SisaSebelumnya":2.5249999999999995,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Samsi","Terima":1.29375,"Dijual":0.0,"Sisa":1.9249999999999998,"SisaSebelumnya":0.6312499999999999,"Uang":0.0,"DibeliOleh":[]}]}]}'),
	(7, 'zakatfitrah-2024', '{"HargaJualBeras":40000,"PembagianDetail":[{"No":1,"TotalPembagian":87.0,"TotalBerasDijual":69.0,"TotalBerasSisa":18.000000000000004,"TotalBerasSisaSebelumnya":0.0,"TotalUang":2760000.0,"Detail":[{"Nama":"SB","Terima":34.800000000000004,"Dijual":34.0,"Sisa":0.8000000000000043,"SisaSebelumnya":0.0,"Uang":1360000.0,"DibeliOleh":[{"Id":8510,"NoUrut":1,"KK":"AKK003","Nama":"Aisyah Wan Granie, drg.","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8512,"NoUrut":3,"KK":"AKK003","Nama":"Handika wira ramadhan","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8511,"NoUrut":2,"KK":"AKK003","Nama":"Muhammad Akbar Wira Maroso","Posisi":3,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8513,"NoUrut":1,"KK":"AKK009","Nama":"Adam","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8523,"NoUrut":3,"KK":"BKK010","Nama":"Arjuna Faeza Saquele","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8521,"NoUrut":1,"KK":"BKK010","Nama":"Bima Danu Kusumah","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8522,"NoUrut":2,"KK":"BKK010","Nama":"Eka Sri Rahayu","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8524,"NoUrut":1,"KK":"CKK010","Nama":"Choirul Sufianto","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8508,"NoUrut":2,"KK":"CKK010","Nama":"Lulu Vivi Nurdina","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8507,"NoUrut":3,"KK":"CKK010","Nama":"Sabia Azza Asyifa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8506,"NoUrut":4,"KK":"CKK010","Nama":"Sahila","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8555,"NoUrut":1,"KK":"DKK017","Nama":"Dimas Daud Probokusumo","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8557,"NoUrut":2,"KK":"DKK017","Nama":"Mia F","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8561,"NoUrut":1,"KK":"EKK019","Nama":"Ernanto","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8564,"NoUrut":4,"KK":"EKK019","Nama":"Nadine Alika","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8563,"NoUrut":3,"KK":"EKK019","Nama":"Salma Renata","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8562,"NoUrut":2,"KK":"EKK019","Nama":"Sri Wahyuni","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8548,"NoUrut":5,"KK":"EKK019","Nama":"Val Aqsha Dirgantara","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8532,"NoUrut":5,"KK":"HKK022","Nama":"Arsyla Sahnum Dwi Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8534,"NoUrut":7,"KK":"HKK022","Nama":"Danil Yoga Bertoni","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8531,"NoUrut":4,"KK":"HKK022","Nama":"Fadhilan Ramadan Putra Pratama","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8536,"NoUrut":1,"KK":"HKK022","Nama":"Hardono Idris","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8529,"NoUrut":2,"KK":"HKK022","Nama":"Novi Ris Indarti","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8530,"NoUrut":3,"KK":"HKK022","Nama":"Rezha Putra Perdana","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8533,"NoUrut":6,"KK":"HKK022","Nama":"Tri Yulia Hartini","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8541,"NoUrut":2,"KK":"IKK025","Nama":"Amanda PP ","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8543,"NoUrut":4,"KK":"IKK025","Nama":"Ariana Mischa Fadhila","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8540,"NoUrut":1,"KK":"IKK025","Nama":"M Ibnu Fadhil","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8542,"NoUrut":3,"KK":"IKK025","Nama":"Raihana Feyza Jasmine","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8436,"NoUrut":4,"KK":"MKK030","Nama":"Budi Nuryanto","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8433,"NoUrut":1,"KK":"MKK030","Nama":"Mia Rohamiah Husada","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8434,"NoUrut":2,"KK":"MKK030","Nama":"Putri Elfara Zahrani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8435,"NoUrut":3,"KK":"MKK030","Nama":"Syifa Jihannisa Cahyani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8437,"NoUrut":1,"KK":"MKK031","Nama":"Makmur","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Daerah","Terima":0.87,"Dijual":0.0,"Sisa":0.87,"SisaSebelumnya":0.0,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":1.74,"Dijual":1.0,"Sisa":0.74,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":8439,"NoUrut":2,"KK":"MKK031","Nama":"Mida","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Kelompok","Terima":10.44,"Dijual":10.0,"Sisa":0.4399999999999995,"SisaSebelumnya":0.0,"Uang":400000.0,"DibeliOleh":[{"Id":8441,"NoUrut":5,"KK":"MKK031","Nama":"Muhammad Dzickry","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8440,"NoUrut":4,"KK":"MKK031","Nama":"Vicka Septia Ramadani","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8447,"NoUrut":3,"KK":"MKK031","Nama":"Vicky Rahayu Puja Kesuma","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8427,"NoUrut":1,"KK":"RKK037","Nama":"Rachmat Irawan","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8412,"NoUrut":2,"KK":"RKK037","Nama":"Ulfa Agustiana","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8425,"NoUrut":2,"KK":"SKK041","Nama":"Inez Fajriannisa","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8426,"NoUrut":3,"KK":"SKK041","Nama":"M. Farrel SA","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8438,"NoUrut":4,"KK":"SKK041","Nama":"Rizka Dyanira H.","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8424,"NoUrut":1,"KK":"SKK041","Nama":"Sofyan Syah Akbar","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8449,"NoUrut":5,"KK":"SKK041","Nama":"Tiara Syahriani Putri","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Sofyan","Terima":4.05,"Dijual":3.0,"Sisa":1.0499999999999998,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8477,"NoUrut":1,"KK":"SKK043","Nama":"Samsi","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8470,"NoUrut":2,"KK":"SKK044","Nama":"Erza Mohammad Prima Sakti","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8473,"NoUrut":5,"KK":"SKK044","Nama":"Mohammad Falah Akbar","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Siti Sarah","Terima":2.7,"Dijual":2.0,"Sisa":0.7000000000000002,"SisaSebelumnya":0.0,"Uang":80000.0,"DibeliOleh":[{"Id":8472,"NoUrut":4,"KK":"SKK044","Nama":"Nachelle Rafaela Artavika Shefala","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8450,"NoUrut":1,"KK":"SKK044","Nama":"Sheilla Kharisma Gemilang","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Dediwanto","Terima":5.4,"Dijual":3.0,"Sisa":2.4000000000000004,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8471,"NoUrut":3,"KK":"SKK044","Nama":"Yetti","Posisi":4,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8475,"NoUrut":2,"KK":"TKK043","Nama":"Muhammad Mumtaz Farhan","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8474,"NoUrut":1,"KK":"TKK043","Nama":"Tenny Supartini","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Makmur","Terima":6.75,"Dijual":3.0,"Sisa":3.75,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8484,"NoUrut":2,"KK":"WKK045","Nama":"Agam Bhaskoro","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8483,"NoUrut":1,"KK":"WKK045","Nama":"Wiwik Hartatik","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8468,"NoUrut":2,"KK":"YKK046","Nama":"Fera koes Rahayu","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Yanti Nuryanti","Terima":4.05,"Dijual":3.0,"Sisa":1.0499999999999998,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8466,"NoUrut":4,"KK":"YKK046","Nama":"Kresna Rizki Romadhon","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8451,"NoUrut":5,"KK":"YKK046","Nama":"M Prayoga Aji Nugraha","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8467,"NoUrut":3,"KK":"YKK046","Nama":"Oscar Tirta Sugema","Posisi":2,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Adam S","Terima":2.7,"Dijual":2.0,"Sisa":0.7000000000000002,"SisaSebelumnya":0.0,"Uang":80000.0,"DibeliOleh":[{"Id":8469,"NoUrut":1,"KK":"YKK046","Nama":"Yogi yogaswara ","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8460,"NoUrut":2,"KK":"ZKK048","Nama":"Imaria Binti Ramli Rahmany","Posisi":1,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Satria Manggala","Terima":5.4,"Dijual":3.0,"Sisa":2.4000000000000004,"SisaSebelumnya":0.0,"Uang":120000.0,"DibeliOleh":[{"Id":8459,"NoUrut":1,"KK":"ZKK048","Nama":"Zainal Abidin Masse","Posisi":0,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8461,"NoUrut":1,"KK":"ZSIMP001","Nama":"H Abdullah","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8462,"NoUrut":2,"KK":"ZSIMP002","Nama":"Nurdiah","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Samsi","Terima":1.35,"Dijual":1.0,"Sisa":0.3500000000000001,"SisaSebelumnya":0.0,"Uang":40000.0,"DibeliOleh":[{"Id":8463,"NoUrut":3,"KK":"ZSIMP003","Nama":"Hariza Angkasa Wira","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Dody","Terima":4.05,"Dijual":2.0,"Sisa":2.05,"SisaSebelumnya":0.0,"Uang":80000.0,"DibeliOleh":[{"Id":8464,"NoUrut":4,"KK":"ZSIMP004","Nama":"Lony Novita","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8465,"NoUrut":5,"KK":"ZSIMP005","Nama":"Aghitsna Nurfarizah","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]},{"Nama":"Adi Imam","Terima":2.7,"Dijual":2.0,"Sisa":0.7000000000000002,"SisaSebelumnya":0.0,"Uang":80000.0,"DibeliOleh":[{"Id":8546,"NoUrut":6,"KK":"ZSIMP006","Nama":"Afkharrilo Angka Wira","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024},{"Id":8566,"NoUrut":7,"KK":"ZSIMP007","Nama":"Aldri Nuraisyah Angkasa Wira","Posisi":7,"IsMustahik":true,"ZakatBeras":0,"TitipZakat":40000.0,"SelisihBeras":0.0,"SelisihTitipan":0.0,"Amil":null,"DanaTalangan":0.0,"SudahZakat":true,"SudahRealisasi":false,"SudahTercatat":true,"Tahun":2024}]}]},{"No":2,"TotalPembagian":69.0,"TotalBerasDijual":0.0,"TotalBerasSisa":87.00000000000001,"TotalBerasSisaSebelumnya":18.000000000000004,"TotalUang":0.0,"Detail":[{"Nama":"SB","Terima":27.6,"Dijual":0.0,"Sisa":28.400000000000006,"SisaSebelumnya":0.8000000000000043,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Daerah","Terima":0.6900000000000001,"Dijual":0.0,"Sisa":1.56,"SisaSebelumnya":0.87,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Desa","Terima":1.3800000000000001,"Dijual":0.0,"Sisa":2.12,"SisaSebelumnya":0.74,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Kelompok","Terima":8.28,"Dijual":0.0,"Sisa":8.719999999999999,"SisaSebelumnya":0.4399999999999995,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Sofyan","Terima":3.2120689655172416,"Dijual":0.0,"Sisa":4.2620689655172415,"SisaSebelumnya":1.0499999999999998,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Siti Sarah","Terima":2.1413793103448278,"Dijual":0.0,"Sisa":2.841379310344828,"SisaSebelumnya":0.7000000000000002,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Dediwanto","Terima":4.2827586206896555,"Dijual":0.0,"Sisa":6.682758620689656,"SisaSebelumnya":2.4000000000000004,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Makmur","Terima":5.353448275862069,"Dijual":0.0,"Sisa":9.10344827586207,"SisaSebelumnya":3.75,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Yanti Nuryanti","Terima":3.2120689655172416,"Dijual":0.0,"Sisa":4.2620689655172415,"SisaSebelumnya":1.0499999999999998,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Adam S","Terima":2.1413793103448278,"Dijual":0.0,"Sisa":2.841379310344828,"SisaSebelumnya":0.7000000000000002,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Satria Manggala","Terima":4.2827586206896555,"Dijual":0.0,"Sisa":6.682758620689656,"SisaSebelumnya":2.4000000000000004,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Samsi","Terima":1.0706896551724139,"Dijual":0.0,"Sisa":1.420689655172414,"SisaSebelumnya":0.3500000000000001,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Dody","Terima":3.2120689655172416,"Dijual":0.0,"Sisa":5.2620689655172415,"SisaSebelumnya":2.05,"Uang":0.0,"DibeliOleh":[]},{"Nama":"Adi Imam","Terima":2.1413793103448278,"Dijual":0.0,"Sisa":2.841379310344828,"SisaSebelumnya":0.7000000000000002,"Uang":0.0,"DibeliOleh":[]}]}]}');
/*!40000 ALTER TABLE `StateStorages` ENABLE KEYS */;

-- Dumping structure for table moslemdb.TabunganJamaahs
CREATE TABLE IF NOT EXISTS `TabunganJamaahs` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime(6) NOT NULL,
  `AkunTabunganJamaahId` bigint(20) NOT NULL,
  `JamaahId` bigint(20) NOT NULL,
  `NamaJamaah` longtext DEFAULT NULL,
  `Jumlah` double NOT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `DiterimaOleh` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TabunganJamaahs_AkunTabunganJamaahId` (`AkunTabunganJamaahId`),
  KEY `IX_TabunganJamaahs_JamaahId` (`JamaahId`),
  CONSTRAINT `FK_TabunganJamaahs_AkunTabunganJamaahs_AkunTabunganJamaahId` FOREIGN KEY (`AkunTabunganJamaahId`) REFERENCES `AkunTabunganJamaahs` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_TabunganJamaahs_Jamaahs_JamaahId` FOREIGN KEY (`JamaahId`) REFERENCES `Jamaahs` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.TabunganJamaahs: ~0 rows (approximately)
DELETE FROM `TabunganJamaahs`;
/*!40000 ALTER TABLE `TabunganJamaahs` DISABLE KEYS */;
/*!40000 ALTER TABLE `TabunganJamaahs` ENABLE KEYS */;

-- Dumping structure for table moslemdb.TargetPerKelass
CREATE TABLE IF NOT EXISTS `TargetPerKelass` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` int(11) NOT NULL,
  `MateriId` bigint(20) NOT NULL,
  `KelasId` bigint(20) NOT NULL,
  `Semester` int(11) NOT NULL,
  `Tahun` int(11) NOT NULL,
  `TargetNilai` int(11) NOT NULL,
  `TargetDeskripsi` varchar(800) CHARACTER SET utf8mb4 DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TargetPerKelass_KelasId` (`KelasId`),
  KEY `IX_TargetPerKelass_MateriId` (`MateriId`),
  CONSTRAINT `FK_TargetPerKelass_Kelass_KelasId` FOREIGN KEY (`KelasId`) REFERENCES `Kelass` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_TargetPerKelass_Materis_MateriId` FOREIGN KEY (`MateriId`) REFERENCES `Materis` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;

-- Dumping data for table moslemdb.TargetPerKelass: ~206 rows (approximately)
DELETE FROM `TargetPerKelass`;
/*!40000 ALTER TABLE `TargetPerKelass` DISABLE KEYS */;
INSERT INTO `TargetPerKelass` (`Id`, `No`, `MateriId`, `KelasId`, `Semester`, `Tahun`, `TargetNilai`, `TargetDeskripsi`) VALUES
	(7, 1, 21, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(8, 29, 4, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(9, 28, 3, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(10, 27, 2, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(11, 26, 1, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(12, 25, 35, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(13, 24, 33, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(14, 23, 32, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(15, 22, 31, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(16, 21, 30, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(17, 20, 44, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(18, 19, 17, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(19, 18, 16, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(20, 17, 15, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(21, 30, 37, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(22, 16, 14, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(23, 14, 12, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(24, 13, 11, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(25, 12, 10, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(26, 11, 9, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(27, 10, 8, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(28, 9, 51, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(29, 8, 20, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(30, 7, 19, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(31, 6, 18, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(32, 5, 167, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(33, 4, 91, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(34, 3, 90, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(35, 2, 22, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(36, 15, 13, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(37, 31, 262, 1, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(38, 1, 21, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(39, 29, 28, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(40, 30, 30, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(41, 31, 31, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(42, 32, 32, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(43, 33, 33, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(44, 34, 34, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(45, 35, 35, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(46, 36, 96, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(47, 37, 126, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(48, 38, 200, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(49, 39, 298, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(50, 40, 492, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(51, 41, 1, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(52, 42, 2, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(53, 43, 3, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(54, 44, 4, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(55, 45, 42, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(56, 46, 71, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(57, 47, 37, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(58, 48, 100, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(59, 49, 127, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(60, 50, 149, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(61, 51, 174, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(62, 28, 133, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(63, 52, 207, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(64, 27, 107, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(65, 25, 81, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(66, 2, 118, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(67, 3, 147, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(68, 4, 169, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(69, 5, 18, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(70, 6, 19, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(71, 7, 20, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(72, 8, 51, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(73, 9, 52, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(74, 10, 53, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(75, 11, 86, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(76, 12, 87, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(77, 13, 88, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(78, 14, 115, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(79, 15, 116, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(80, 16, 117, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(81, 17, 142, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(82, 18, 143, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(83, 19, 144, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(84, 20, 164, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(85, 21, 10, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(86, 22, 17, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(87, 23, 44, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(88, 24, 45, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(89, 26, 83, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(90, 53, 262, 2, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(91, 1, 56, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(92, 27, 198, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(93, 28, 95, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(94, 29, 96, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(95, 30, 97, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(96, 31, 98, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(97, 32, 99, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(98, 33, 173, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(99, 34, 205, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(100, 35, 5, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(101, 26, 184, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(102, 36, 7, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(103, 38, 40, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(104, 39, 41, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(105, 40, 208, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(106, 41, 171, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(107, 42, 37, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(108, 43, 100, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(109, 44, 127, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(110, 45, 149, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(111, 46, 174, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(112, 37, 39, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(113, 25, 141, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(114, 24, 111, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(115, 23, 110, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(116, 2, 89, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(117, 3, 90, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(118, 4, 91, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(119, 5, 167, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(120, 6, 18, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(121, 7, 19, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(122, 8, 20, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(123, 9, 51, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(124, 10, 52, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(125, 11, 53, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(126, 12, 86, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(127, 13, 87, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(128, 14, 88, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(129, 15, 115, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(130, 16, 116, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(131, 17, 117, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(132, 18, 48, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(133, 19, 49, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(134, 20, 79, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(135, 21, 80, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(136, 22, 108, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(137, 47, 207, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(138, 48, 268, 3, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(139, 1, 145, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(140, 27, 294, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(141, 26, 401, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(142, 25, 207, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(143, 24, 174, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(144, 23, 149, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(145, 22, 127, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(146, 21, 100, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(147, 20, 37, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(148, 19, 234, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(149, 18, 232, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(150, 17, 172, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(151, 16, 208, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(152, 28, 295, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(153, 15, 75, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(154, 13, 205, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(155, 12, 204, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(156, 11, 202, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(157, 10, 201, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(158, 9, 200, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(159, 8, 199, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(160, 7, 284, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(161, 6, 198, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(162, 5, 184, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(163, 4, 148, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(164, 3, 147, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(165, 2, 146, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(166, 14, 206, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(167, 29, 296, 4, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(168, 1, 287, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(169, 20, 294, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(170, 19, 303, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(171, 18, 302, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(172, 17, 301, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(173, 16, 234, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(174, 15, 172, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(175, 14, 387, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(176, 13, 338, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(177, 12, 206, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(178, 11, 311, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(179, 10, 274, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(180, 9, 273, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(181, 8, 272, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(182, 7, 271, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(183, 6, 313, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(184, 5, 312, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(185, 4, 285, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(186, 3, 284, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(187, 2, 320, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(188, 21, 295, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(189, 22, 296, 5, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(190, 1, 407, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(191, 21, 382, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(192, 20, 381, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(193, 19, 380, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(194, 18, 412, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(195, 17, 409, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(196, 16, 404, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(197, 15, 417, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(198, 14, 416, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(199, 13, 415, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(200, 22, 410, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(201, 12, 414, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(202, 10, 419, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(203, 9, 418, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(204, 8, 406, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(205, 7, 405, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(206, 6, 367, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(207, 5, 366, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(208, 4, 491, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(209, 3, 420, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(210, 2, 408, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(211, 11, 413, 6, 1, 2022, 85, 'Materi disampaikan, paham.'),
	(212, 23, 411, 6, 1, 2022, 85, 'Materi disampaikan, paham.');
/*!40000 ALTER TABLE `TargetPerKelass` ENABLE KEYS */;

-- Dumping structure for table moslemdb.TargetPrograms
CREATE TABLE IF NOT EXISTS `TargetPrograms` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProgramRamadanId` bigint(20) DEFAULT NULL,
  `Nama` longtext DEFAULT NULL,
  `Skor` int(11) NOT NULL,
  `Sukses` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_TargetPrograms_ProgramRamadanId` (`ProgramRamadanId`),
  CONSTRAINT `FK_TargetPrograms_ProgramRamadans_ProgramRamadanId` FOREIGN KEY (`ProgramRamadanId`) REFERENCES `ProgramRamadans` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.TargetPrograms: ~14 rows (approximately)
DELETE FROM `TargetPrograms`;
/*!40000 ALTER TABLE `TargetPrograms` DISABLE KEYS */;
INSERT INTO `TargetPrograms` (`Id`, `ProgramRamadanId`, `Nama`, `Skor`, `Sukses`) VALUES
	(29, 5, 'Khataman Quran', 100, 1),
	(30, 5, 'Doa-doa harian', 50, 1),
	(31, 5, 'Doa Bela Diri', 50, 1),
	(32, 5, 'Khatam Kitab Solat', 50, 1),
	(33, 5, 'Khatam Kitab Hukum', 50, 1),
	(34, 5, 'Khatam Kitab Khutbah', 50, 1),
	(35, 5, 'Khatam Kitab Doa', 50, 1),
	(36, 5, 'Khatam Kitab Adab', 50, 1),
	(37, 5, 'Khatam Kitab Surga dan Neraka', 50, 1),
	(38, 5, 'Khatam Kitab Jihad', 50, 1),
	(39, 5, 'Khatam Kitab Shaum', 50, 1),
	(40, 5, 'Bersuci dan solat', 50, 1),
	(41, 5, 'Hafalan surat pendek ', 50, 1),
	(42, 5, 'Baca tilawati 2 halaman sehari per-halaman dibaca 2 kali', 50, 1);
/*!40000 ALTER TABLE `TargetPrograms` ENABLE KEYS */;

-- Dumping structure for table moslemdb.Tims
CREATE TABLE IF NOT EXISTS `Tims` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(250) NOT NULL DEFAULT '0',
  `Tugas` varchar(250) NOT NULL DEFAULT '0',
  `Telepon` varchar(250) DEFAULT '0',
  `Alamat` varchar(500) DEFAULT '0',
  `Urutan` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.Tims: ~0 rows (approximately)
DELETE FROM `Tims`;
/*!40000 ALTER TABLE `Tims` DISABLE KEYS */;
/*!40000 ALTER TABLE `Tims` ENABLE KEYS */;

-- Dumping structure for table moslemdb.UserProfiles
CREATE TABLE IF NOT EXISTS `UserProfiles` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Username` longtext DEFAULT NULL,
  `Password` longtext DEFAULT NULL,
  `FullName` longtext DEFAULT NULL,
  `Phone` longtext DEFAULT NULL,
  `Email` longtext DEFAULT NULL,
  `Alamat` longtext DEFAULT NULL,
  `KTP` longtext DEFAULT NULL,
  `PicUrl` longtext DEFAULT NULL,
  `Aktif` tinyint(1) NOT NULL,
  `Role` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table moslemdb.UserProfiles: ~0 rows (approximately)
DELETE FROM `UserProfiles`;
/*!40000 ALTER TABLE `UserProfiles` DISABLE KEYS */;
INSERT INTO `UserProfiles` (`Id`, `Username`, `Password`, `FullName`, `Phone`, `Email`, `Alamat`, `KTP`, `PicUrl`, `Aktif`, `Role`) VALUES
	(21, 'admin', 'PyudoE0InirdNemJJ4aOSw==', 'admin', '08174810333', 'admin@yahoo.com', 'JL Admin Keren', '111111', NULL, 1, 0);
/*!40000 ALTER TABLE `UserProfiles` ENABLE KEYS */;

-- Dumping structure for table moslemdb.VideoStreams
CREATE TABLE IF NOT EXISTS `VideoStreams` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Nama` longtext DEFAULT NULL,
  `Keterangan` longtext DEFAULT NULL,
  `Tanggal` datetime(6) NOT NULL,
  `EmbedHTML` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table moslemdb.VideoStreams: ~0 rows (approximately)
DELETE FROM `VideoStreams`;
/*!40000 ALTER TABLE `VideoStreams` DISABLE KEYS */;
INSERT INTO `VideoStreams` (`Id`, `Nama`, `Keterangan`, `Tanggal`, `EmbedHTML`) VALUES
	(1, 'Test', 'oke', '2023-05-23 08:34:15.993787', '<>');
/*!40000 ALTER TABLE `VideoStreams` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
